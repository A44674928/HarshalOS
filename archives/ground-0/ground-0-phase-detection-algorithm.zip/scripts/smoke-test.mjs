import { chromium } from 'playwright';
import AxeBuilder from '@axe-core/playwright';
import { mkdir, readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';

const BASE = 'http://localhost:5173';
await mkdir('artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true, reducedMotion: 'reduce' });
const page = await context.newPage();
const errors = [];
const violations = [];
page.on('pageerror', error => errors.push(error.message));

async function axe(target, label) {
  const result = await new AxeBuilder({ page: target }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa']).analyze();
  for (const v of result.violations) violations.push({ label, id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.slice(0, 3).map(n => `${n.target.join(' ')} :: ${(n.failureSummary || '').split('\n').slice(1, 3).join(' ')}`) });
}
const active = target => target.evaluate(() => ({ id: document.activeElement?.id, cls: document.activeElement?.className, label: document.activeElement?.getAttribute('aria-label'), text: document.activeElement?.textContent?.trim().slice(0, 40) }));
const nav = async (target, name) => {
  try { await target.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`) }).click({ timeout: 8000 }); }
  catch (error) {
    await target.screenshot({ path: 'artifacts/nav-failure.png' });
    console.log('NAV DIAGNOSTICS', JSON.stringify(await target.evaluate(() => ({ layout: document.documentElement.dataset.layout, size: getComputedStyle(document.documentElement).fontSize, frameInert: document.querySelector('.app-frame')?.hasAttribute('inert'), sidebarInert: document.querySelector('.sidebar')?.hasAttribute('inert'), sidebarOpen: document.querySelector('.sidebar')?.className, dialogs: Array.from(document.querySelectorAll('[role=dialog]')).map(d => d.getAttribute('aria-label')), navButtons: Array.from(document.querySelectorAll('.nav-link')).map(b => b.textContent) }))));
    throw error;
  }
  await target.waitForTimeout(150);
};

// 1. Overview, skip link, quick-form validation
await page.goto(BASE, { waitUntil: 'networkidle' });
await page.evaluate(() => document.fonts.ready);
assert.equal(await page.title(), 'Ground-0 — Phase Intelligence');
assert.equal(await page.evaluate(() => document.documentElement.dataset.layout), 'desktop');
await page.keyboard.press('Tab');
assert.equal((await active(page)).cls, 'skip-link');
assert.ok(await page.locator('.skip-link').evaluate(el => el.getBoundingClientRect().top >= 0), 'skip link becomes visible on focus');
await page.keyboard.press('Enter');
assert.equal((await active(page)).id, 'main-content');
await page.screenshot({ path: 'artifacts/overview-desktop.png', fullPage: true });
await axe(page, 'overview');
await page.getByRole('button', { name: 'Run automatic audit', exact: true }).click();
assert.ok(await page.locator('#quick-org-error').isVisible());
assert.equal((await active(page)).id, 'quick-org');

// 2. Manual audit: error summary, radios, draft, export
await page.getByRole('button', { name: 'Manual audit', exact: true }).click();
let dialog = page.getByRole('dialog');
assert.equal((await active(page)).id, 'wizard-name');
await dialog.getByLabel(/Entity name/).fill('Demo Advisory Council');
await dialog.getByLabel('Entity identifier').fill('DEMO-001');
await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
const summary = dialog.locator('.error-summary');
assert.equal(await summary.locator('li').count(), 5);
assert.ok(await summary.evaluate(element => element === document.activeElement));
await axe(page, 'manual wizard with errors');
await page.screenshot({ path: 'artifacts/wizard-errors.png' });
await summary.getByRole('button').first().click();
assert.equal((await active(page)).id, 'q-B1-yes');
for (const [index, value] of [false, true, false, true, false].entries()) await dialog.locator('.answer-card').nth(index).getByRole('radio', { name: value ? 'Yes' : 'No' }).check();
assert.equal(await summary.count(), 0);
await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
assert.ok((await dialog.locator('.vector-preview').innerText()).includes('match NAB'));
await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
await dialog.getByRole('button', { name: 'Save draft' }).click();
dialog = page.getByRole('dialog');
assert.ok((await dialog.locator('.detail-title').innerText()).includes('Demo Advisory Council'));
const [download] = await Promise.all([page.waitForEvent('download'), dialog.getByRole('button', { name: 'Export JSON' }).click()]);
await download.saveAs('artifacts/draft-audit.json');
const exported = JSON.parse(await readFile('artifacts/draft-audit.json', 'utf8'));
assert.equal(exported.Detected_Phase, 'NAB');
assert.equal(exported.Confidence_Level, 'NONE');
assert.equal(exported.Provisional_Badge.Filled, '0/5', 'a draft without sources gets a blank badge');
assert.ok((await dialog.locator('.badge-panel .phase-ring svg').getAttribute('aria-label')).startsWith('Blank provisional badge'));
await dialog.getByRole('button', { name: 'Close audit details' }).click();

// 3. Persistence and resuming a draft with evidence
await page.reload({ waitUntil: 'networkidle' });
await page.getByRole('button', { name: 'Demo Advisory Council', exact: true }).click();
await page.getByRole('dialog').getByRole('button', { name: 'Continue audit' }).click();
dialog = page.getByRole('dialog');
assert.equal(await dialog.getByLabel(/Entity name/).inputValue(), 'Demo Advisory Council');
const cutoff = await dialog.getByLabel(/Evidence cutoff/).inputValue();
await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
for (let index = 0; index < 5; index++) {
  const card = dialog.locator('.answer-card').nth(index);
  const toggle = card.locator('.answer-toggle');
  if (await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click();
  await card.getByLabel('Public source URL').fill(`https://example.org/fixture/b${index + 1}`);
  await card.getByLabel('Published or effective date').fill(`${cutoff.slice(0, 4)}-01-01`);
  await card.getByLabel('Claim this artifact supports').fill(`Test fixture for B${index + 1}; not asserted as real evidence.`);
}
await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
await dialog.getByRole('button', { name: 'Save audit' }).click();
assert.ok((await page.getByRole('dialog').locator('.detail-phase').innerText()).includes('High'));
assert.ok((await page.getByRole('dialog').locator('.badge-panel .phase-ring svg').getAttribute('aria-label')).includes('5 of 5'), 'all five segments colour in once every answer has a dated source');
await page.getByRole('dialog').getByRole('button', { name: 'Close audit details' }).click();
assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('ground-0-audits-v1')).length), 1);

// 4. Automatic audit from a name, with live public data
await page.getByRole('textbox', { name: 'Organization name' }).fill('World Health Organization');
await page.getByRole('button', { name: 'Run automatic audit', exact: true }).click();
const auto = page.getByRole('dialog', { name: 'Automatic audit' });
await auto.getByRole('heading', { name: 'Which one do you mean?' }).waitFor({ timeout: 30000 });
assert.ok(await auto.getByRole('radio', { name: /^World Health Organization/ }).first().isChecked());
await axe(page, 'automatic audit candidates');
await auto.getByRole('button', { name: 'Audit this organization' }).click();
assert.ok(await auto.locator('.source-progress li').count() >= 12, 'per-source progress list');
await auto.locator('.auto-result').waitFor({ timeout: 90000 });
await page.waitForTimeout(200);
await page.screenshot({ path: 'artifacts/auto-result.png' });
await axe(page, 'automatic audit result');
console.log('Automatic screening:', await auto.locator('.verdict-row .phase-badge').innerText(), '|', (await auto.locator('.verdict-facts').innerText()).replace(/\n/g, ' '));
console.log('Coverage:', (await auto.locator('.coverage-table tbody tr').allInnerTexts()).map(text => text.split('\t').slice(0, 3).join(' | ')).join(' ;; ').slice(0, 900));
assert.ok(await auto.locator('.auto-question').count() >= 5);
assert.ok(await auto.locator('.coverage-table tbody tr').count() >= 12, 'coverage table lists every source');
assert.ok((await auto.locator('.verdict-grid .phase-ring svg').getAttribute('aria-label')).includes('badge'), 'provisional badge has a text alternative');
const searchedRows = await auto.locator('.coverage-table tbody tr.searched, .coverage-table tbody tr.no-results').count();
assert.ok(searchedRows >= 6, `expected most sources to be searched, got ${searchedRows}`);
const [autoDownload] = await Promise.all([page.waitForEvent('download'), auto.getByRole('button', { name: 'Export JSON' }).click()]);
await autoDownload.saveAs('artifacts/auto-audit.json');
const autoExport = JSON.parse(await readFile('artifacts/auto-audit.json', 'utf8'));
assert.equal(autoExport.Automation.Coverage.length, 12);
assert.ok(autoExport.Automation.Not_Covered.length >= 4);
assert.equal(autoExport.Provisional_Badge.Normative, false);
assert.equal(autoExport.Badge_Status, 'Unissued');
assert.ok(autoExport.Automation.Matched_Statements.every(item => item.Source && item.Link));
assert.ok(await auto.getByText('Human review needed').first().isVisible());
await auto.getByRole('button', { name: 'Save to register' }).click();
dialog = page.getByRole('dialog');
assert.ok((await dialog.innerText()).includes('Automated screening — human review pending'));
await dialog.getByRole('button', { name: 'Review and edit' }).click();
dialog = page.getByRole('dialog');
assert.ok((await dialog.getByRole('heading', { level: 2 }).innerText()).includes('Review the automated screening'));
for (let step = 0; step < 3; step++) await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
await dialog.getByRole('button', { name: /Save (audit|draft)/ }).click();
dialog = page.getByRole('dialog');
assert.ok((await dialog.innerText()).includes('Reviewed by a person'));
await dialog.getByRole('button', { name: 'Close audit details' }).click();

// 5. Accessibility preferences: text size, contrast, readable font, persistence, reset
await page.getByRole('button', { name: 'Accessibility settings' }).click();
dialog = page.getByRole('dialog', { name: 'Accessibility settings' });
await axe(page, 'accessibility settings dialog');
await dialog.getByRole('radio', { name: /Largest/ }).check();
try { await page.waitForFunction(() => getComputedStyle(document.documentElement).fontSize === '24px', null, { timeout: 4000 }); }
catch { throw new Error(`Text size not applied: ${JSON.stringify(await page.evaluate(() => ({ attr: document.documentElement.dataset.textSize, size: getComputedStyle(document.documentElement).fontSize, stored: localStorage.getItem('ground-0-a11y-v1'), checked: document.querySelector('input[name=g0-text-size]:checked')?.value })))}`); }
await dialog.getByRole('radio', { name: 'High contrast' }).check();
await dialog.getByRole('switch', { name: /Readable font/ }).check();
assert.equal(await page.evaluate(() => document.documentElement.dataset.contrast), 'high');
assert.equal(await page.evaluate(() => document.documentElement.dataset.readable), 'true');
await dialog.getByRole('button', { name: 'Done' }).click();
await page.evaluate(() => document.fonts.ready);
assert.equal(await page.evaluate(() => document.documentElement.dataset.layout), 'tablet');
assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
await page.screenshot({ path: 'artifacts/overview-largest-high-contrast.png' });
await axe(page, 'overview at 150% text, high contrast');
await page.reload({ waitUntil: 'networkidle' });
assert.equal(await page.evaluate(() => document.documentElement.dataset.textSize), 'largest');
await page.getByRole('button', { name: 'Accessibility settings' }).click();
await page.getByRole('dialog').getByRole('button', { name: 'Reset to defaults' }).click();
await page.getByRole('dialog').getByRole('button', { name: 'Done' }).click();
await page.waitForFunction(() => getComputedStyle(document.documentElement).fontSize === '16px', null, { timeout: 4000 });

// 6. Every page: focus moves to main content and axe passes
for (const name of ['Phase audits', 'Evidence library', 'Temporal ledger', 'Phase reference', 'Algorithm & logic', 'Specifications', 'Accessibility']) {
  await nav(page, name);
  assert.equal((await active(page)).id, 'main-content', `focus after navigating to ${name}`);
  await axe(page, name);
}
await nav(page, 'Accessibility');
await page.screenshot({ path: 'artifacts/accessibility-page.png', fullPage: true });

// 7. Register search and filter popover (Escape returns focus)
await nav(page, 'Phase audits');
await page.getByRole('searchbox', { name: 'Search audit entities' }).fill('World Health');
assert.equal(await page.locator('.audit-table tbody tr').count(), 2);
await page.getByRole('searchbox', { name: 'Search audit entities' }).fill('');
await page.getByRole('button', { name: /^Filters/ }).click();
await page.getByLabel('Detected phase').selectOption('GSRB');
await page.keyboard.press('Escape');
assert.ok((await active(page)).text.startsWith('Filters'));
const rowPhases = await page.locator('.audit-table tbody tr .phase-badge').allInnerTexts();
assert.ok(rowPhases.length >= 4 && rowPhases.every(text => text.trim() === 'GSRB'));

// 8. Logic sandbox with radio answers
await nav(page, 'Algorithm & logic');
await page.locator('.predicate-presets').getByRole('button', { name: 'GSRB', exact: true }).click();
assert.equal(await page.locator('.logic-result-phase .phase-badge').innerText(), 'GSRB');
await page.locator('.predicate-row').nth(3).getByRole('radio', { name: 'Yes' }).check();
assert.equal(await page.locator('.logic-result-phase .phase-badge').innerText(), 'AMBIGUOUS');
for (const checkbox of await page.locator('.sandbox-constraints input').all()) await checkbox.check();
assert.equal(await page.locator('.logic-result-phase .phase-badge').innerText(), 'NAB-Constrained');

// 9. Specification draft source
await nav(page, 'Specifications');
await page.getByRole('group', { name: 'Algorithm version' }).getByRole('button', { name: /v1\.1/ }).click();
assert.ok((await page.locator('.spec-status').innerText()).includes('not ratified'));
await page.getByRole('button', { name: 'Source text' }).click();
await page.waitForFunction(() => document.querySelector('.source-reader pre')?.textContent?.includes('END SPECIFICATION — v1.1 amendment draft'));

// 10. Evidence form: error summary, then success
await nav(page, 'Evidence library');
await page.getByRole('button', { name: 'Add artifact', exact: true }).click();
dialog = page.getByRole('dialog');
await dialog.getByRole('button', { name: 'Add artifact', exact: true }).click();
assert.equal(await dialog.locator('.error-summary li').count(), 4);
await axe(page, 'evidence form with errors');
await dialog.getByLabel(/Artifact title/).fill('Demonstration policy artifact');
await dialog.getByLabel(/Public source URL/).fill('https://example.org/policy');
await dialog.getByLabel(/Publication or effective date/).fill('2026-09-01');
await dialog.getByLabel(/Observable claim/).fill('Demonstration record only; not asserted as substantive evidence.');
await dialog.getByRole('button', { name: 'B3', exact: true }).click();
await dialog.getByRole('button', { name: 'Add artifact', exact: true }).click();
assert.equal(await page.getByRole('dialog').count(), 0);

// 11. Command palette
await page.keyboard.press('Control+k');
await page.getByRole('searchbox', { name: /Search audits, pages and actions/ }).fill('Quantum');
assert.equal(await page.locator('.command-item').count(), 1);
await page.keyboard.press('Escape');
assert.equal(await page.locator('.command-modal').count(), 0);

// 12. Engine and automatic-rule safeguards
const checks = await page.evaluate(async () => {
  const e = await import('/src/lib/engine.ts');
  const a = await import('/src/lib/autoAudit.ts');
  const input = e.newInput('1.1'); input.name = 'Cryptographic adapter test'; input.identifier = 'ENTITY-001'; input.cutoff = '2026-09-12';
  const header = JSON.parse(e.headerExample);
  const keys = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const sign = async h => { const bytes = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, keys.privateKey, new TextEncoder().encode(e.canonicalHeader(h)))); h['Declaration-Hash'] = btoa(Array.from(bytes, b => String.fromCharCode(b)).join('')).replace(/\+/g, '-').replace(/\//g, '_'); return JSON.stringify(h); };
  input.headerText = await sign(header); input.publicKeyText = JSON.stringify(await crypto.subtle.exportKey('jwk', keys.publicKey));
  const valid = await e.validatePDH(input);
  const stale = await e.validatePDH({ ...input, cutoff: '2027-01-01' });
  const aliases = a.aliasPattern(['World Health Organization', 'WHO'], { generic: true });
  const other = a.analyzeText('In January 2025, President Trump issued an executive order to withdraw the United States from the WHO.', '1.0', 'https://example.org', 2026, aliases).signals.map(s => s.rule);
  const own = a.analyzeText('The WHO issues regulations that member states must implement within two years.', '1.0', 'https://example.org', 2026, aliases).signals.map(s => s.rule);
  const advice = a.analyzeText('Asked by Senator Pell to assess operations and make recommendations, a consultant reviewed the library.', '1.0', 'https://example.org', 2026, aliases).signals.map(s => s.rule);
  const b = await import('/src/lib/badge.ts');
  const custodial = b.provisionalBadge([false, true, false, true, false], [true, true, true, true, true]);
  const partial = b.provisionalBadge([true, null, true, false, null], [true, false, true, true, false]);
  const locAliases = a.aliasPattern(['Library of Congress'], { generic: true });
  const libraryOfCongress = a.matchSentences([{ text: 'The Library of Congress is issuing this final rule to amend its regulations regarding photography on Library premises.', section: 'FR' }], '1.0', locAliases, 2026, false, a.aliasPattern(['Library of Congress'], { generic: false })).map(s => s.rule);
  return { valid: valid.status, stale: stale.status, other, own, advice, custodial: custodial.upheld.length === 5 && custodial.filled === 5, partial: { filled: partial.filled, wrong: partial.provenWrong, upheld: partial.upheld, blank: partial.blank }, libraryOfCongress };
});
assert.equal(checks.custodial, true, 'witness-only answers uphold the presumption on every segment');
// Regression tests for evidence-rule bugs found in live audits
const ruleChecks = await page.evaluate(async () => {
  const a = await import('/src/lib/autoAudit.ts');
  const aliases = a.aliasPattern(['World Health Organization', 'WHO'], { generic: true });
  const rules = text => a.matchSentences([{ text, section: 'test' }], '1.0', aliases, 2026, false, a.aliasPattern(['World Health Organization'], { generic: false })).filter(s => s.kind === 'qualifying').map(s => s.rule);
  return {
    earmark: rules('Voluntary contributions to the WHO will account for $3,015 million, with the remainder tied to particular programmes or objectives.'),
    conditional: rules('The organization made its funding conditional on compliance with reform requirements.'),
    instrument: rules('The WHO Quality of Life Instrument provides guidance for data collection.'),
    advisory: rules('The committee provides advice and guidance to the CDC on the use of vaccines.'),
    judgment: rules('The judgment against the organization remains in force today.'),
    constitution: rules('Its constitution formally came into force on 7 April 1948 and remains in force.'),
  };
});
assert.ok(!ruleChecks.earmark.includes('B1-FUNDING'), 'donor earmarks are not compliance-conditional funding');
assert.ok(ruleChecks.conditional.includes('B1-FUNDING'), 'compliance-conditional funding is detected');
assert.ok(!ruleChecks.instrument.includes('B2-ADVICE'), 'a survey instrument is not an advisory institutional role');
assert.ok(ruleChecks.advisory.includes('B2-ADVICE'), 'advice to an institution is detected');
assert.ok(!ruleChecks.judgment.includes('B5-FORCE'), 'a judgment against the entity persisting is not its own rule persisting');
assert.ok(ruleChecks.constitution.includes('B5-FORCE'), 'a constitution in force is detected');
assert.deepEqual(checks.partial, { filled: 3, wrong: ['B1', 'B3', 'B4'], upheld: [], blank: ['B2', 'B5'] });
assert.ok(!checks.libraryOfCongress.includes('B4-LEGIS'), 'the entity’s own name must not trigger the legislature rule');
assert.equal(checks.valid, 'VALID');
assert.equal(checks.stale, 'INVALID');
assert.ok(!checks.other.includes('B3-RULES'), 'another actor’s order is not the entity’s rule');
assert.ok(checks.own.includes('B3-RULES'), 'the entity’s own rule-making is detected');
assert.ok(!checks.advice.includes('B2-ADVICE'), 'advice by someone else is not counted');

// 13. Mobile: layout, off-canvas navigation, 320px reflow
const mobileContext = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, reducedMotion: 'reduce' });
const mobile = await mobileContext.newPage();
mobile.on('pageerror', error => errors.push(error.message));
await mobile.goto(BASE, { waitUntil: 'networkidle' });
await mobile.evaluate(() => document.fonts.ready);
assert.equal(await mobile.evaluate(() => document.documentElement.dataset.layout), 'mobile');
assert.ok(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
assert.ok(await mobile.evaluate(() => document.querySelector('.sidebar').hasAttribute('inert')));
await mobile.screenshot({ path: 'artifacts/overview-mobile.png', fullPage: true });
await axe(mobile, 'mobile overview');
await mobile.getByRole('button', { name: 'Open menu' }).click();
assert.equal((await active(mobile)).label, 'Close menu');
await nav(mobile, 'Evidence library');
assert.ok(await mobile.getByRole('heading', { name: 'Evidence, not inference.' }).isVisible());
await mobile.setViewportSize({ width: 320, height: 720 });
await mobile.goto(BASE, { waitUntil: 'networkidle' });
assert.ok(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'reflows at 320px');
await mobile.screenshot({ path: 'artifacts/overview-320.png', fullPage: true });

console.log(`Axe: ${violations.length} violation groups`);
for (const v of violations) console.log(`- [${v.impact}] ${v.label} :: ${v.id} — ${v.help}\n    ${v.nodes.join('\n    ')}`);
assert.deepEqual(errors, []);
assert.equal(violations.filter(v => v.impact === 'serious' || v.impact === 'critical').length, 0, 'serious or critical axe violations');
console.log('PASS: manual and automatic audits, keyboard and screen-reader structure, preferences, persistence, mobile reflow and axe checks.');
await browser.close();
