import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { applyPrefs, loadPrefs } from "./lib/a11y";

// Apply saved text size, contrast, motion and layout before the first paint to avoid a flash of the wrong display.
applyPrefs(loadPrefs());

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
