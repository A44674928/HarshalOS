import { useState, type FormEvent, type KeyboardEvent } from 'react';
import Icon from './Icon';
import Modal from './Modal';
import PhaseRing from './PhaseRing';
import { ConfidenceIndicator, ErrorSummary, Field, ListenButton, PhaseBadge, describedBy, entityIcon, plainPhase, spokenPhase, type FieldError } from './ui';
import { exportAudit, formatDate, isPublicUrl, phaseDefinitions, questions, today, type AuditRecord, type Evidence, type Phase } from '../lib/engine';

type DetailTab = 'summary' | 'evidence' | 'record';

export function AuditDetails({ audit, onClose, onToast, onDelete, onResume }: { audit: AuditRecord; onClose: () => void; onToast: (message: string) => void; onDelete: (id: string) => void; onResume: () => void }) {
  const [tab, setTab] = useState<DetailTab>('summary');
  const tabs: { id: DetailTab; label: string }[] = [{ id: 'summary', label: 'Summary' }, { id: 'evidence', label: `Evidence (${audit.evidence.length})` }, { id: 'record', label: 'JSON record' }];
  const onTabKey = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    const targets: Record<string, number> = { ArrowRight: index + 1, ArrowLeft: index - 1, Home: 0, End: tabs.length - 1 };
    if (!(event.key in targets)) return;
    event.preventDefault();
    const next = tabs[(targets[event.key] + tabs.length) % tabs.length];
    setTab(next.id);
    document.getElementById(`audit-tab-${next.id}`)?.focus();
  };
  const canResume = !audit.baseline && !!audit.input && (audit.status === 'Draft' || audit.method === 'automatic');
  const eyebrow = audit.baseline ? 'Source-reported baseline' : audit.method === 'automatic' ? `Automated screening · Ground-0 v${audit.version}` : audit.automation?.reviewed ? `Reviewed screening · Ground-0 v${audit.version}` : `Local audit · Ground-0 v${audit.version}`;
  const speech = `${audit.name}. ${audit.baseline ? 'This is a source-reported baseline, not an independent audit.' : ''} Detected phase: ${spokenPhase[audit.phase]}. ${plainPhase[audit.phase]} Confidence: ${audit.confidence.toLowerCase()}. Badge: ${audit.badge}. ${audit.finding}`;
  const copyRecord = async () => { try { await navigator.clipboard.writeText(JSON.stringify(audit.report, null, 2)); onToast('Audit record copied to the clipboard.'); } catch { onToast('The clipboard is unavailable. Use Export JSON instead.'); } };

  return <Modal label={`Audit details: ${audit.name}`} className="detail-modal" onClose={onClose}>
    <div className="modal-heading">
      <div className="detail-title">
        <span className="entity-avatar large" aria-hidden="true"><Icon name={entityIcon(audit)} size={24}/></span>
        <div><p className="eyebrow">{eyebrow}</p><h2>{audit.name}</h2><p>{audit.identifier} · Updated {formatDate(audit.createdAt)}</p></div>
      </div>
      <button type="button" className="icon-button" onClick={onClose} aria-label="Close audit details"><Icon name="close"/></button>
    </div>
    <div className="detail-tabs" role="tablist" aria-label="Audit details sections">{tabs.map((item, index) => <button key={item.id} type="button" role="tab" id={`audit-tab-${item.id}`} aria-selected={tab === item.id} aria-controls="audit-tabpanel" tabIndex={tab === item.id ? 0 : -1} onClick={() => setTab(item.id)} onKeyDown={event => onTabKey(event, index)}>{item.label}</button>)}</div>
    <div className="modal-body detail-body" role="tabpanel" id="audit-tabpanel" aria-labelledby={`audit-tab-${tab}`} tabIndex={0}>
      {tab === 'summary' && <>
        {audit.baseline && <div className="callout amber"><Icon name="info" size={20}/><p><strong>A source result, not an independent audit.</strong> The v1.0 manuscript reports this classification. Its evidence, audit date, answers and signed declaration are not supplied here.</p></div>}
        {audit.automation && <div className={`callout ${audit.automation.reviewed ? 'subtle' : 'blue'}`}><Icon name="sparkle" size={20}/><div>
          <strong>{audit.automation.reviewed ? 'Reviewed by a person' : 'Automated screening — human review pending'}</strong>
          <p>{audit.automation.reviewed ? 'This record began as an automated screening and was checked and saved in the manual audit flow.' : 'Fixed keyword rules coded these answers from Wikipedia and Wikidata. Check each quote before relying on it.'}</p>
          <ul className="source-list">{audit.automation.sources.map(source => <li key={source.url}><a href={source.url} target="_blank" rel="noreferrer">{source.name}<span className="sr-only"> (opens in a new tab)</span></a><span>Revision {source.revision} · {formatDate(source.published)}</span></li>)}</ul>
          {audit.automation.coverage && <p className="coverage-summary">{audit.automation.coverage.filter(entry => entry.status === 'searched' || entry.status === 'no-results').length} of {audit.automation.coverage.length} record sources searched · {audit.automation.documentsChecked?.toLocaleString() ?? '—'} documents checked{audit.automation.coverage.some(entry => entry.status === 'unavailable') ? ` · unavailable: ${audit.automation.coverage.filter(entry => entry.status === 'unavailable').map(entry => entry.name).join(', ')}` : ''}. The full coverage table is in the JSON record.</p>}
        </div></div>}
        <div className="detail-phase">
          <div><p className="eyebrow">{audit.baseline ? 'Reported detected phase' : 'Detected operational phase'}</p><PhaseBadge phase={audit.phase}/></div>
          <div className="detail-confidence"><ConfidenceIndicator confidence={audit.confidence}/><span>{audit.baseline ? 'Reported by the source' : 'Branch confidence'}</span></div>
        </div>
        <p className="plain-meaning"><strong>What this means:</strong> {plainPhase[audit.phase]}</p>
        {audit.provisionalBadge && <div className="badge-panel"><PhaseRing badge={audit.provisionalBadge}/><p className="badge-note">Formal badge status: <strong>{audit.badge}</strong>. {audit.badge === 'Unissued' ? 'A formal Ground-0 badge needs a valid signed declaration; the provisional badge shows how far the evidence goes.' : audit.badge === 'Confirmed' ? 'A valid declaration matches the evidenced behavior.' : audit.badge === 'Reclassified' ? 'A valid declaration contradicts the evidenced behavior.' : 'No badge can stand on this record.'}</p></div>}
        <p className="result-finding">{audit.finding}</p>
        <ListenButton text={speech} label="Listen to this summary"/>
        <dl className="result-facts">
          <div><dt>Declared phase</dt><dd>{audit.reportedDeclared}</dd></div>
          <div><dt>Declaration status</dt><dd>{audit.pdh.status}</dd></div>
          <div><dt>Badge</dt><dd>{audit.badge}</dd></div>
          <div><dt>Severity</dt><dd>{audit.severity.replace('_', ' ')}</dd></div>
          <div><dt>Evidence cutoff</dt><dd>{formatDate(audit.cutoff)}</dd></div>
          <div><dt>Replication risk</dt><dd>{audit.replicationRisk}</dd></div>
        </dl>
        <h3 className="subsection-title">Behavioral answers</h3>
        <ul className="detail-vector">{questions.map((question, index) => { const value = audit.answers[index]?.value; return <li key={question.code}><span className="question-code">{question.code}</span><strong>{value === null || value === undefined ? (audit.baseline ? 'Not supplied' : 'Not answered') : value ? 'Yes' : 'No'}</strong><span>{question.short}</span></li>; })}</ul>
        <div className="callout subtle"><Icon name="shield" size={20}/><p>{audit.pdh.reason}</p></div>
        {audit.transition && <div className="callout subtle"><Icon name="timeline" size={20}/><p><strong>{audit.transition.from} → {audit.transition.to} · {audit.transition.status.replace(/_/g, ' ')}</strong><br/>{audit.transition.notes}</p></div>}
      </>}
      {tab === 'evidence' && (audit.evidence.length ? <>
        <p className="section-note">Public artifacts attached to this audit. Dates are checked against the evidence cutoff; the claims remain the auditor’s responsibility.</p>
        <ul className="evidence-list">{audit.evidence.map(item => <li className="evidence-detail-card" key={item.id}>
          <h3>{item.title}</h3><p>{item.claim}</p>
          <a href={item.url} target="_blank" rel="noreferrer">{item.url.replace(/#:~:text=.*$/, '')}<Icon name="arrow-up" size={14}/><span className="sr-only"> (opens in a new tab)</span></a>
          <p className="evidence-meta"><span>Published {formatDate(item.published)}</span><span>Retrieved {formatDate(item.retrieved)}</span><span>Supports {item.codes.join(', ')}</span></p>
        </li>)}</ul>
      </> : <div className="empty-state"><span className="empty-icon" aria-hidden="true"><Icon name="folder" size={32}/></span><h3>No public artifacts attached</h3><p>{audit.baseline ? 'The manuscript keeps this result, but its evidence set was not supplied. Do not treat it as a verified finding.' : 'This assessment is provisional. Missing evidence is a disclosed gap, not proof of a negative.'}</p></div>)}
      {tab === 'record' && <>
        <div className="json-toolbar"><p className="eyebrow">Reproducible output</p><button type="button" className="button secondary small" onClick={copyRecord}><Icon name="copy" size={16}/>Copy JSON</button></div>
        <pre className="json-record" tabIndex={0} aria-label="Audit record in JSON format">{JSON.stringify(audit.report, null, 2)}</pre>
      </>}
    </div>
    <div className="modal-footer">
      <div>{!audit.baseline && <button type="button" className="text-button danger" onClick={() => { if (window.confirm('Remove this audit from this browser? This cannot be undone.')) onDelete(audit.id); }}>Remove audit</button>}</div>
      <div className="footer-actions">
        <button type="button" className="button secondary" onClick={() => { exportAudit(audit); onToast('Audit record exported as JSON.'); }}><Icon name="download" size={18}/>Export JSON</button>
        {canResume ? <button type="button" className="button primary" onClick={onResume}>{audit.method === 'automatic' ? 'Review and edit' : 'Continue audit'}<Icon name="arrow" size={18}/></button> : <button type="button" className="button primary" onClick={onClose}>Done</button>}
      </div>
    </div>
  </Modal>;
}

export function PhaseDetails({ phase, onClose, onAlgorithm }: { phase: Phase; onClose: () => void; onAlgorithm: () => void }) {
  const definition = phaseDefinitions.find(item => item.phase === phase)!;
  return <Modal label={`${phase} phase definition`} className="phase-modal" onClose={onClose}>
    <div className="modal-heading">
      <div><p className="eyebrow">Phase reference · v1.0</p><h2>{phase}</h2><p>{definition.name}</p></div>
      <button type="button" className="icon-button" onClick={onClose} aria-label="Close phase definition"><Icon name="close"/></button>
    </div>
    <div className="modal-body">
      <div className={`phase-definition-banner ${definition.color}`}><span className="phase-symbol" aria-hidden="true"><Icon name={definition.icon} size={36}/></span><div><p className="eyebrow">{definition.category}</p><h3>{definition.description}</h3></div></div>
      <p className="plain-meaning"><strong>In plain language:</strong> {plainPhase[phase]}</p>
      <ul className="characteristic-list">{definition.characteristics.map(item => <li key={item}><Icon name="check" size={18}/>{item}</li>)}</ul>
      <h3 className="subsection-title">Declaration header values</h3>
      <dl className="definition-fields">{['Center capability', 'Legitimacy source', 'Refusal semantics', 'Symbolism executability', 'Time authority effect'].map((field, index) => <div key={field}><dt>{field}</dt><dd>{definition.fields[index]}</dd></div>)}</dl>
      <div className="callout subtle"><Icon name="info" size={20}/><p><strong>Examples in the framework:</strong> {definition.examples}</p></div>
      {definition.vector ? <><h3 className="subsection-title">Required answers</h3><ul className="detail-vector">{definition.vector.map((value, index) => <li key={index}><span className="question-code">B{index + 1}</span><strong>{value === null ? 'Either' : value ? 'Yes' : 'No'}</strong><span>{questions[index].short}</span></li>)}</ul></> : <div className="callout amber"><Icon name="shield" size={20}/><p>Only an AMBIGUOUS result with <strong>all four constraint checks demonstrated</strong> becomes NAB-Constrained. A valid signed declaration is still needed for a badge.</p></div>}
    </div>
    <div className="modal-footer"><p className="footer-status">A reference category, not an entity finding.</p><button type="button" className="button primary" onClick={onAlgorithm}>Explore the decision logic<Icon name="arrow" size={18}/></button></div>
  </Modal>;
}

export function AddEvidence({ audits, onClose, onSave }: { audits: AuditRecord[]; onClose: () => void; onSave: (evidence: Evidence) => void }) {
  const [form, setForm] = useState({ title: '', url: '', published: '', retrieved: today(), claim: '', entity: 'Unlinked' });
  const [codes, setCodes] = useState<string[]>([]);
  const [errors, setErrors] = useState<FieldError[]>([]);
  const [attempt, setAttempt] = useState(0);
  const update = (field: keyof typeof form, value: string) => setForm(current => ({ ...current, [field]: value }));
  const errorFor = (field: string) => errors.find(error => error.field === field)?.message;
  const validate = (): FieldError[] => {
    const found: FieldError[] = [];
    if (form.title.trim().length < 3) found.push({ field: 'artifact-title', message: 'Enter an artifact title of at least three characters.' });
    if (!isPublicUrl(form.url)) found.push({ field: 'artifact-url', message: 'Enter a public web address that starts with https:// or http://.' });
    if (!form.published) found.push({ field: 'artifact-published', message: 'Enter the publication or effective date.' });
    if (!form.retrieved) found.push({ field: 'artifact-retrieved', message: 'Enter the date you retrieved the artifact.' });
    if (form.claim.trim().length < 5) found.push({ field: 'artifact-claim', message: 'Describe what the artifact shows, in at least five characters.' });
    return found;
  };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    const found = validate();
    setErrors(found);
    setAttempt(value => value + 1);
    if (!found.length) onSave({ ...form, codes, id: `ART-${Date.now()}` });
  };
  const input = (id: string, field: keyof typeof form, props: Record<string, string> = {}, hint?: string) => <input id={id} className="text-input" value={form[field]} onChange={event => update(field, event.target.value)} aria-invalid={!!errorFor(id) || undefined} aria-describedby={describedBy(id, hint, errorFor(id))} {...props}/>;

  return <Modal className="evidence-modal" label="Add a public evidence artifact" onClose={onClose} initialFocus="#artifact-title">
    <div className="modal-heading">
      <div><p className="eyebrow">Public evidence library</p><h2>Add an artifact, not an assumption</h2><p>Keep the provenance needed for a repeatable audit.</p></div>
      <button type="button" className="icon-button" aria-label="Close evidence form" onClick={onClose}><Icon name="close"/></button>
    </div>
    <form className="modal-form" onSubmit={submit} noValidate>
      <div className="modal-body">
        <ErrorSummary errors={errors} focusKey={attempt} title="There is a problem with this artifact"/>
        <Field id="artifact-title" label="Artifact title" required error={errorFor('artifact-title')}>{input('artifact-title', 'title', { placeholder: 'e.g. Published appeals outcome report' })}</Field>
        <Field id="artifact-url" label="Public source URL" required hint="Paste the full web address of the public document." error={errorFor('artifact-url')}>{input('artifact-url', 'url', { type: 'url', inputMode: 'url', placeholder: 'https://' }, 'hint')}</Field>
        <div className="form-grid">
          <Field id="artifact-published" label="Publication or effective date" required error={errorFor('artifact-published')}>{input('artifact-published', 'published', { type: 'date' })}</Field>
          <Field id="artifact-retrieved" label="Retrieval date" required error={errorFor('artifact-retrieved')}>{input('artifact-retrieved', 'retrieved', { type: 'date' })}</Field>
        </div>
        <Field id="artifact-claim" label="Observable claim it supports" required error={errorFor('artifact-claim')}>
          <textarea id="artifact-claim" className="text-input" rows={3} value={form.claim} onChange={event => update('claim', event.target.value)} aria-invalid={!!errorFor('artifact-claim') || undefined} aria-describedby={describedBy('artifact-claim', undefined, errorFor('artifact-claim'))} placeholder="What does this artifact demonstrate?"/>
        </Field>
        <Field id="artifact-entity" label="Entity">
          <select id="artifact-entity" className="text-input" value={form.entity} onChange={event => update('entity', event.target.value)}><option>Unlinked</option>{Array.from(new Set(audits.map(audit => audit.name))).map(name => <option key={name}>{name}</option>)}</select>
        </Field>
        <fieldset className="code-fieldset"><legend className="field-name">Related audit questions</legend>
          <div className="code-select">{['B1', 'B2', 'B3', 'B4', 'B5', 'C1', 'C2', 'C3', 'C4'].map(code => <button type="button" key={code} aria-pressed={codes.includes(code)} onClick={() => setCodes(codes.includes(code) ? codes.filter(item => item !== code) : [...codes, code])}>{code}</button>)}</div>
        </fieldset>
        <div className="callout subtle"><Icon name="info" size={20}/><p>Library artifacts stay <strong>unscored</strong> until you cite and evaluate them in an audit. Adding one grants no phase credit.</p></div>
      </div>
      <div className="modal-footer">
        <p className="footer-status"><Icon name="lock" size={16}/>Saved in this browser</p>
        <div className="footer-actions"><button type="button" className="button secondary" onClick={onClose}>Cancel</button><button type="submit" className="button primary"><Icon name="plus" size={18}/>Add artifact</button></div>
      </div>
    </form>
  </Modal>;
}
