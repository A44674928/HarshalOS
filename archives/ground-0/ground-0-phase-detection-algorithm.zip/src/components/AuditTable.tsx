import { useCallback, useId, useMemo, useRef, useState } from 'react';
import Icon from './Icon';
import PhaseRing from './PhaseRing';
import { ConfidenceIndicator, PhaseBadge, entityIcon, useDismiss, type DismissReason } from './ui';
import { downloadFile, formatDate, type AuditRecord } from '../lib/engine';

const phaseOptions = ['NAB', 'CWO', 'NAB-Constrained', 'GSRB', 'AMBIGUOUS', 'INCOHERENT'];

export default function AuditTable({ audits, overview = false, onSelect, onViewAll, initialAttention = false, initialHigh = false }: { audits: AuditRecord[]; overview?: boolean; onSelect: (audit: AuditRecord) => void; onViewAll: () => void; initialAttention?: boolean; initialHigh?: boolean }) {
  const id = useId();
  const [tab, setTab] = useState<'all' | 'attention'>(initialAttention ? 'attention' : 'all');
  const [search, setSearch] = useState('');
  const [phase, setPhase] = useState('all');
  const [confidence, setConfidence] = useState(initialHigh ? 'HIGH' : 'all');
  const [sort, setSort] = useState('newest');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const anchor = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const closeFilters = useCallback((reason: DismissReason) => { setFiltersOpen(false); if (reason === 'escape') trigger.current?.focus(); }, []);
  useDismiss(anchor, filtersOpen, closeFilters);

  const attention = audits.filter(audit => audit.status !== 'Complete').length;
  const filtered = useMemo(() => audits
    .filter(audit => (tab === 'all' || audit.status !== 'Complete') && (phase === 'all' || audit.phase === phase) && (confidence === 'all' || audit.confidence === confidence) && `${audit.name} ${audit.identifier} ${audit.phase}`.toLowerCase().includes(search.trim().toLowerCase()))
    .sort((a, b) => sort === 'name' ? a.name.localeCompare(b.name) : sort === 'oldest' ? a.createdAt.localeCompare(b.createdAt) : b.createdAt.localeCompare(a.createdAt)), [audits, tab, search, phase, confidence, sort]);
  const visible = overview ? filtered.slice(0, 5) : filtered;
  const activeFilters = Number(phase !== 'all') + Number(confidence !== 'all');
  const reset = () => { setSearch(''); setPhase('all'); setConfidence('all'); setSort('newest'); setTab('all'); };
  const headingId = `${id}-heading`;

  return <section className="panel audit-panel" aria-labelledby={headingId}>
    <div className="panel-heading">
      <div>
        <h2 id={headingId}>{overview ? 'Recent audits' : 'Audit register'} <span className="count-chip">{audits.length}<span className="sr-only"> records</span></span></h2>
        <p>{overview ? 'Claims and observable behavior, kept side by side.' : 'Source baseline cases and the audits saved in this browser.'}</p>
      </div>
      {overview ? <button type="button" className="text-button" onClick={onViewAll}>View all audits<Icon name="arrow" size={16}/></button> : <span className="local-label"><Icon name="lock" size={16}/>Saved in this browser</span>}
    </div>

    <div className="table-toolbar">
      <div className="filter-tabs" role="group" aria-label="Which audits to show">
        <button type="button" className="filter-tab" aria-pressed={tab === 'all'} onClick={() => setTab('all')}>All audits <span className="count-chip">{audits.length}</span></button>
        <button type="button" className="filter-tab" aria-pressed={tab === 'attention'} onClick={() => setTab('attention')}>Needs review <span className="count-chip">{attention}</span></button>
      </div>
      <div className="table-tools">
        <label className="table-search"><Icon name="search" size={18}/><span className="sr-only">Search audit entities</span><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search entities"/></label>
        <div className="popover-anchor" ref={anchor}>
          <button ref={trigger} type="button" className={`button secondary small ${activeFilters ? 'has-filters' : ''}`} aria-expanded={filtersOpen} aria-controls={`${id}-filters`} onClick={() => setFiltersOpen(open => !open)}>
            <Icon name="filter" size={18}/>Filters{activeFilters > 0 && <span className="count-chip">{activeFilters}<span className="sr-only"> active</span></span>}
          </button>
          {filtersOpen && <div id={`${id}-filters`} className="popover filter-popover" role="group" aria-label="Filter and sort audits">
            <label className="field-label">Detected phase<select className="text-input" value={phase} onChange={event => setPhase(event.target.value)} autoFocus><option value="all">All phases</option>{phaseOptions.map(option => <option key={option}>{option}</option>)}</select></label>
            <label className="field-label">Confidence<select className="text-input" value={confidence} onChange={event => setConfidence(event.target.value)}><option value="all">All confidence levels</option>{['HIGH', 'MEDIUM', 'LOW', 'NONE'].map(option => <option key={option}>{option}</option>)}</select></label>
            <label className="field-label">Order<select className="text-input" value={sort} onChange={event => setSort(event.target.value)}><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="name">Entity A–Z</option></select></label>
            <div className="popover-footer"><button type="button" className="text-button" onClick={reset}>Reset filters</button><button type="button" className="button primary small" onClick={() => closeFilters('escape')}>Done</button></div>
          </div>}
        </div>
        <button type="button" className="button secondary small" onClick={() => downloadFile('ground-0-audit-view.json', JSON.stringify(filtered.map(audit => audit.report), null, 2))}><Icon name="download" size={18}/>Export</button>
      </div>
    </div>
    <p className="sr-only" role="status">{`Showing ${visible.length} of ${filtered.length} audits.`}</p>

    <div className="table-scroll" role="region" aria-labelledby={headingId} tabIndex={0}>
      <table className="audit-table">
        <caption className="sr-only">{overview ? 'The five most recent audits' : 'All audits'}, with declared and detected phases, provisional badge fill, confidence, status and last update. Select an entity name to open its details.</caption>
        <thead><tr><th scope="col">Entity</th><th scope="col">Declared phase</th><th scope="col">Detected phase</th><th scope="col">Badge</th><th scope="col">Confidence</th><th scope="col">Status</th><th scope="col">Updated</th></tr></thead>
        <tbody>{visible.map((audit, index) => <tr key={audit.id} onClick={event => { if (!(event.target as HTMLElement).closest('button, a')) onSelect(audit); }}>
          <td><div className="entity-cell">
            <span className={`entity-avatar entity-color-${index % 5}`} aria-hidden="true"><Icon name={entityIcon(audit)} size={20}/></span>
            <div>
              <button type="button" className="entity-link" onClick={() => onSelect(audit)}>{audit.name}</button>
              <span className="entity-meta">{audit.identifier}{audit.baseline ? ' · Source baseline' : ` · v${audit.version}`}{audit.method === 'automatic' && <span className="method-tag"><Icon name="sparkle" size={12}/>Automated</span>}{audit.automation?.reviewed && <span className="method-tag reviewed"><Icon name="check" size={12}/>Reviewed</span>}</span>
            </div>
          </div></td>
          <td>{audit.reportedDeclared === 'None' ? <span className="declared-phase none">None<span className="sr-only"> declared</span></span> : <span className="declared-phase">{audit.reportedDeclared}</span>}</td>
          <td><PhaseBadge phase={audit.phase} compact/></td>
          <td><span className="badge-cell">{audit.provisionalBadge ? <PhaseRing badge={audit.provisionalBadge} size="compact" caption={false}/> : null}<span className="badge-cell-text">{audit.provisionalBadge ? `${audit.provisionalBadge.filled}/5` : '—'}<span className="sr-only"> segments evidenced</span></span></span></td>
          <td><ConfidenceIndicator confidence={audit.confidence}/></td>
          <td><span className={`status-badge ${audit.status === 'Complete' ? 'complete' : audit.status === 'Draft' ? 'draft' : 'review'}`}><Icon name={audit.status === 'Complete' ? 'check-circle' : audit.status === 'Draft' ? 'file' : 'warning'} size={14}/>{audit.status}</span></td>
          <td className="date-cell">{formatDate(audit.createdAt)}</td>
        </tr>)}</tbody>
      </table>
      {visible.length === 0 && <div className="empty-state compact-empty"><Icon name="search" size={28}/><h3>No audits match this view</h3><p>Try another name, phase or confidence level.</p><button type="button" className="button secondary small" onClick={reset}>Clear filters</button></div>}
    </div>
    <div className="table-footer"><span><Icon name="shield" size={14}/>Public evidence. Transparent logic.</span><span>Showing {visible.length} of {filtered.length}</span></div>
  </section>;
}
