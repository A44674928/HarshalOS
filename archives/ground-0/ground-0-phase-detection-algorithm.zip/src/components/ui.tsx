import { useEffect, useRef, useState, type ReactNode, type RefObject } from 'react';
import Icon from './Icon';
import { phaseDefinitions, type AuditRecord, type Phase, type Version } from '../lib/engine';
import { announce, createRecognition, recognitionSupported, speak, speechSupported, stopSpeaking, type Recognition } from '../lib/a11y';

export type FieldError = { field: string; message: string };
export type DismissReason = 'escape' | 'outside';

/** Plain-language meanings shown next to every technical phase label. */
export const plainPhase: Record<Phase, string> = {
  NAB: 'Refusal-bound. It cannot act on its own, its decisions are optional, and a refusal stops it.',
  CWO: 'Witness-only. It records and preserves, but does not decide or enforce.',
  'NAB-Constrained': 'Accountable power. It acts, but courts, legislatures, appeals and renewal rules demonstrably limit it.',
  GSRB: 'Self-authorizing. It makes and enforces rules, can override refusal, and its authority persists over time.',
  AMBIGUOUS: 'Mixed signals. The answers partly fit a phase pattern, but not completely, so no phase badge is assigned.',
  INCOHERENT: 'No pattern. The answers do not fit any defined phase.',
};

export const spokenPhase: Record<Phase, string> = {
  NAB: 'N A B, Neural Atomic Body',
  CWO: 'C W O, Custodial Witness Orb',
  'NAB-Constrained': 'N A B constrained',
  GSRB: 'G S R B, God-Sovereign Religious Body',
  AMBIGUOUS: 'ambiguous',
  INCOHERENT: 'incoherent',
};

export function PhaseBadge({ phase, compact = false }: { phase: Phase; compact?: boolean }) {
  const definition = phaseDefinitions.find(item => item.phase === phase);
  const color = definition?.color ?? (phase === 'INCOHERENT' ? 'danger' : 'amber');
  return <span className={`phase-badge ${color} ${compact ? 'compact' : ''}`}><Icon name={definition?.icon ?? 'warning'} size={compact ? 14 : 18}/>{phase}</span>;
}

export function ConfidenceIndicator({ confidence }: { confidence: string }) {
  const filled = confidence === 'HIGH' ? 4 : confidence === 'MEDIUM' ? 3 : confidence === 'LOW' ? 2 : 0;
  const label = confidence === 'NONE' ? 'None' : confidence.charAt(0) + confidence.slice(1).toLowerCase();
  return <span className={`confidence confidence-${confidence.toLowerCase()}`}>
    <span className="confidence-bars" aria-hidden="true">{[0, 1, 2, 3].map(index => <i key={index} className={index < filled ? 'filled' : ''}/>)}</span>
    {label}<span className="sr-only"> confidence</span>
  </span>;
}

export function entityIcon(audit: AuditRecord): string {
  if (/library|archive/i.test(audit.name)) return 'book';
  if (/health|world|international|united nations/i.test(audit.name)) return 'globe';
  if (/reserve|bank/i.test(audit.name)) return 'bank';
  if (/platform|meta|google|social/i.test(audit.name)) return 'grid';
  return 'building';
}

export function useDismiss(ref: RefObject<HTMLElement | null>, open: boolean, onClose: (reason: DismissReason) => void): void {
  useEffect(() => {
    if (!open) return;
    const pointer = (event: Event) => { if (ref.current && !ref.current.contains(event.target as Node)) onClose('outside'); };
    const key = (event: KeyboardEvent) => { if (event.key === 'Escape') { event.stopPropagation(); onClose('escape'); } };
    document.addEventListener('mousedown', pointer);
    document.addEventListener('touchstart', pointer);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('mousedown', pointer);
      document.removeEventListener('touchstart', pointer);
      document.removeEventListener('keydown', key);
    };
  }, [open, onClose, ref]);
}

/** Reads text aloud with the browser's built-in speech synthesis. Hidden when unsupported. */
export function ListenButton({ text, label = 'Listen', className = '' }: { text: string; label?: string; className?: string }) {
  const [speaking, setSpeaking] = useState(false);
  useEffect(() => () => stopSpeaking(), []);
  if (!speechSupported()) return null;
  const toggle = () => {
    if (speaking) { stopSpeaking(); setSpeaking(false); return; }
    setSpeaking(speak(text, () => setSpeaking(false)));
  };
  return <button type="button" className={`button secondary small listen-button ${className}`} aria-pressed={speaking} onClick={toggle}>
    <Icon name={speaking ? 'stop' : 'volume'} size={18}/>{speaking ? 'Stop reading' : label}
  </button>;
}

/** Dictation for the organization name. Hidden when the browser has no speech recognition. */
export function VoiceButton({ onResult, label = 'Dictate the organization name', className = '' }: { onResult: (text: string) => void; label?: string; className?: string }) {
  const [listening, setListening] = useState(false);
  const recognition = useRef<Recognition | null>(null);
  useEffect(() => () => recognition.current?.abort(), []);
  if (!recognitionSupported()) return null;
  const toggle = () => {
    if (listening) { recognition.current?.stop(); return; }
    const instance = createRecognition();
    if (!instance) return;
    instance.lang = 'en-US';
    instance.interimResults = false;
    instance.maxAlternatives = 1;
    instance.continuous = false;
    instance.onresult = event => {
      const transcript = event.results[0]?.[0]?.transcript?.trim();
      if (transcript) { onResult(transcript); announce(`Heard: ${transcript}`); }
    };
    instance.onerror = event => announce(event.error === 'not-allowed' || event.error === 'service-not-allowed' ? 'Microphone access was blocked. You can type the name instead.' : 'Voice input stopped. Please try again or type the name.', true);
    instance.onend = () => setListening(false);
    recognition.current = instance;
    try { instance.start(); setListening(true); announce('Listening. Say the organization name.'); } catch { setListening(false); }
  };
  return <button type="button" className={`icon-button mic-button ${listening ? 'listening' : ''} ${className}`} aria-pressed={listening} aria-label={label} title={label} onClick={toggle}>
    <Icon name="mic" size={20}/>
  </button>;
}

/** Native radio buttons styled as a large Yes/No switch; arrow keys work as expected. */
export function BinaryChoice({ name, idPrefix, legend, value, onChange, invalid = false }: { name: string; idPrefix: string; legend: string; value: boolean | null; onChange: (value: boolean) => void; invalid?: boolean }) {
  return <fieldset className={`binary-control ${invalid ? 'invalid' : ''}`}>
    <legend className="sr-only">{legend}</legend>
    {[true, false].map(option => <label key={String(option)} className={`binary-option ${value === option ? 'selected' : ''}`}>
      <input id={`${idPrefix}-${option ? 'yes' : 'no'}`} type="radio" name={name} checked={value === option} onChange={() => onChange(option)} aria-invalid={invalid || undefined}/>
      <span>{option ? 'Yes' : 'No'}</span>
    </label>)}
  </fieldset>;
}

export function focusField(id: string): void {
  const element = document.getElementById(id);
  if (!element) return;
  element.scrollIntoView({ block: 'center' });
  element.focus({ preventScroll: true });
}

/** Error summary pattern: receives focus after a failed submit and links to each problem. */
export function ErrorSummary({ errors, focusKey, title = 'Please fix the following' }: { errors: FieldError[]; focusKey: number; title?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { if (focusKey > 0 && errors.length) ref.current?.focus(); }, [focusKey]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!errors.length) return null;
  return <div className="error-summary" role="alert" tabIndex={-1} ref={ref}>
    <h3><Icon name="warning" size={20}/>{title}</h3>
    <ul>{errors.map(error => <li key={error.field}><button type="button" className="error-link" onClick={() => focusField(error.field)}>{error.message}</button></li>)}</ul>
  </div>;
}

export const describedBy = (id: string, hint?: string, error?: string): string | undefined => [hint ? `${id}-hint` : '', error ? `${id}-error` : ''].filter(Boolean).join(' ') || undefined;

export function Field({ id, label, required = false, hint, error, children }: { id: string; label: string; required?: boolean; hint?: string; error?: string; children: ReactNode }) {
  return <div className={`field ${error ? 'has-error' : ''}`}>
    <label className="field-name" htmlFor={id}>{label}{required && <span className="required"> (required)</span>}</label>
    {hint && <p className="field-hint" id={`${id}-hint`}>{hint}</p>}
    {error && <p className="field-error" id={`${id}-error`}><Icon name="warning" size={16}/>{error}</p>}
    {children}
  </div>;
}

export function VersionSwitch({ version, onChange }: { version: Version; onChange: (version: Version) => void }) {
  return <div className="version-switch" role="group" aria-label="Algorithm version">
    <button type="button" aria-pressed={version === '1.0'} onClick={() => onChange('1.0')}>v1.0 <span>Normative</span></button>
    <button type="button" aria-pressed={version === '1.1'} onClick={() => onChange('1.1')}>v1.1 <span>Amendment draft</span></button>
  </div>;
}
