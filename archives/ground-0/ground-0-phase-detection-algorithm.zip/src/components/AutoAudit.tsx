import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import Icon from './Icon';
import Modal from './Modal';
import PhaseRing from './PhaseRing';
import { ListenButton, PhaseBadge, VoiceButton, plainPhase, spokenPhase } from './ui';
import { constraintQuestions, exportAudit, formatDate, questions, today, type AuditRecord, type CoverageEntry, type Version } from '../lib/engine';
import { LIMITATIONS, isAbort, runAutomaticAudit, searchOrganizations, type AutoOutcome, type Candidate, type Category, type Finding, type ProgressUpdate, type Signal } from '../lib/autoAudit';
import { ADAPTERS, CATEGORY_LABELS, CATEGORY_ORDER, TIER_LABELS } from '../lib/sources';
import { announce } from '../lib/a11y';

type Stage = 'input' | 'searching' | 'choose' | 'running' | 'result' | 'error';
type SourceState = { key: string; name: string; category: Category; status: ProgressUpdate['status'] | 'waiting'; count?: number | null; note?: string };
const clip = (text: string, max = 320) => text.length > max ? `${text.slice(0, max - 1).trimEnd()}…` : text;
const CATEGORY_HELP: Record<Category, string> = { encyclopedic: 'Wikipedia article pinned to the cutoff date (always searched)', official: 'The organization’s own pages, dated by the Wayback Machine', court: 'CourtListener opinions, PACER dockets, Wikidata cases, Internet Archive filings', legislative: 'Federal Register, US Congress bills, UK legislation', news: 'GDELT headlines and Wikinews', archive: 'Wikisource documents and Internet Archive texts' };
const STATUS_TEXT: Record<string, string> = { waiting: 'Waiting', running: 'Searching…', searched: 'Searched', 'no-results': 'No matching records', unavailable: 'Unavailable', skipped: 'Turned off' };

function Quote({ signal }: { signal: Signal }) {
  const external = /^https?:\/\//.test(signal.link);
  return <li>
    <blockquote>{clip(signal.sentence)}</blockquote>
    <p className="quote-meta">
      <span className={`source-chip ${signal.origin.category}`}>{signal.origin.sourceName}</span>
      <span className="quote-rule">{signal.label}</span>
      <span>{signal.origin.title}{signal.date ? ` · ${formatDate(signal.date)} (${signal.origin.dateBasis})` : ''}</span>
      <span className="tier-label">{TIER_LABELS[signal.origin.tier]}</span>
      {external && <a href={signal.link} target="_blank" rel="noreferrer">Open record<Icon name="arrow-up" size={14}/><span className="sr-only"> (opens in a new tab)</span></a>}
    </p>
  </li>;
}

function FindingItem({ finding, title, isConstraint = false }: { finding: Finding; title: string; isConstraint?: boolean }) {
  const yes = isConstraint ? 'Shown' : 'Yes';
  const no = isConstraint ? 'Not shown' : 'No';
  const gap = finding.gap.replace(/^Bounded automated search:[^.]*\.\s*/, '');
  return <li className="auto-question">
    <div className="auto-question-head">
      <span className="question-code">{finding.code}</span>
      <h5 className="auto-question-title">{title}</h5>
      <span className={`answer-pill ${finding.answer ? 'yes' : 'no'}`}><Icon name={finding.answer ? 'check' : 'close'} size={14}/>{finding.answer ? yes : no}</span>
    </div>
    {finding.scored.length > 0 ? <ul className="quote-list">{finding.scored.slice(0, 3).map(signal => <Quote key={`${signal.rule}-${signal.link}-${signal.sentence}`} signal={signal}/>)}</ul> : <p className="auto-gap">{gap}</p>}
    {finding.scored.length > 3 && <p className="auto-more-count">{finding.scored.length - 3} more matching statement{finding.scored.length - 3 === 1 ? '' : 's'} are in the exported record.</p>}
    {finding.contrary.length > 0 && <details className="auto-more"><summary>Conflicting statement{finding.contrary.length > 1 ? 's' : ''} found ({finding.contrary.length})</summary><ul className="quote-list">{finding.contrary.slice(0, 2).map(signal => <Quote key={`${signal.rule}-${signal.link}-${signal.sentence}`} signal={signal}/>)}</ul></details>}
    {finding.candidates.length > 0 && <details className="auto-more"><summary>Related statements not counted ({finding.candidates.length})</summary><ul className="quote-list">{finding.candidates.slice(0, 2).map(signal => <Quote key={`${signal.rule}-${signal.link}-${signal.sentence}`} signal={signal}/>)}</ul></details>}
  </li>;
}

function CoverageTable({ coverage }: { coverage: CoverageEntry[] }) {
  return <div className="table-scroll" role="region" aria-label="Sources searched" tabIndex={0}>
    <table className="coverage-table">
      <caption className="sr-only">Every source searched for this audit, with its status, number of matching records and coverage notes</caption>
      <thead><tr><th scope="col">Source</th><th scope="col">Category</th><th scope="col">Status</th><th scope="col">Records</th><th scope="col">What it covers</th></tr></thead>
      <tbody>{coverage.map(entry => <tr key={entry.key} className={entry.status}>
        <th scope="row">{entry.searchUrl ? <a href={entry.searchUrl} target="_blank" rel="noreferrer">{entry.name}<span className="sr-only"> (opens the search in a new tab)</span></a> : entry.name}</th>
        <td>{CATEGORY_LABELS[entry.category as Category] ?? entry.category}</td>
        <td><span className={`status-badge coverage-${entry.status}`}>{STATUS_TEXT[entry.status]}</span>{entry.note && <span className="coverage-note">{entry.note}</span>}</td>
        <td>{entry.status === 'searched' || entry.status === 'no-results' ? `${entry.total === null ? entry.used : entry.total.toLocaleString()}${entry.total !== null && entry.used < entry.total ? ` (${entry.used} read)` : ''}` : '—'}</td>
        <td>{entry.coverage}</td>
      </tr>)}</tbody>
    </table>
  </div>;
}

function speechSummary(outcome: AutoOutcome): string {
  const record = outcome.record;
  const searched = outcome.coverage.filter(entry => entry.status === 'searched' || entry.status === 'no-results').length;
  return [
    `Automated screening for ${outcome.candidate.title}, evidence up to ${formatDate(outcome.cutoff)}.`,
    `${searched} public record sources were searched and ${outcome.documentsChecked} documents checked.`,
    `Detected phase: ${spokenPhase[record.phase]}. ${plainPhase[record.phase]}`,
    record.provisionalBadge?.summary ?? '',
    ...outcome.findings.map((finding, index) => `Question ${index + 1}. ${questions[index].title} ${finding.answer ? 'Yes' : 'No'}${finding.scored[0] ? `, from ${finding.scored[0].origin.sourceName}` : ''}.`),
    record.status === 'Draft' ? 'Too little evidence was found to assign any confidence.' : `Branch confidence: ${record.confidence.toLowerCase()}.`,
    'No formal badge is issued. This result needs human review before you rely on it.',
  ].join(' ');
}

export default function AutoAudit({ initialQuery = '', version, existing, onClose, onSave, onReview, onManual }: { initialQuery?: string; version: Version; existing: AuditRecord[]; onClose: () => void; onSave: (record: AuditRecord) => void; onReview: (record: AuditRecord) => void; onManual: () => void }) {
  const [query, setQuery] = useState(initialQuery);
  const [auditVersion, setAuditVersion] = useState<Version>(version);
  const [cutoff, setCutoff] = useState(today());
  const [categories, setCategories] = useState<Category[]>(CATEGORY_ORDER);
  const [stage, setStage] = useState<Stage>(initialQuery.trim().length >= 2 ? 'searching' : 'input');
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selected, setSelected] = useState(0);
  const [sourceStates, setSourceStates] = useState<SourceState[]>([]);
  const [identityStep, setIdentityStep] = useState('');
  const [outcome, setOutcome] = useState<AutoOutcome | null>(null);
  const [error, setError] = useState('');
  const [inputError, setInputError] = useState('');
  const controller = useRef<AbortController | null>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const previousStage = useRef<Stage>(stage);
  const sourceSummary = useMemo(() => {
    const done = sourceStates.filter(state => ['searched', 'no-results', 'unavailable', 'skipped'].includes(state.status ?? '')).length;
    return `${done} of ${sourceStates.length || ADAPTERS.length} sources finished`;
  }, [sourceStates]);

  const search = async (text: string) => {
    const trimmed = text.trim();
    if (trimmed.length < 2) { setInputError('Enter at least two characters of the organization’s name.'); setStage('input'); return; }
    if (!cutoff || cutoff > today()) { setInputError('Choose an evidence cutoff date that is today or earlier.'); setStage('input'); return; }
    setInputError('');
    controller.current?.abort();
    const current = new AbortController();
    controller.current = current;
    setStage('searching');
    setError('');
    announce(`Searching for ${trimmed}.`);
    try {
      const found = await searchOrganizations(trimmed, current.signal);
      if (current.signal.aborted) return;
      if (!found.length) { setError(`No Wikipedia article matched “${trimmed}”. Try the organization’s full official name.`); setStage('error'); return; }
      setCandidates(found);
      setSelected(0);
      setStage('choose');
      announce(`${found.length} possible ${found.length === 1 ? 'match' : 'matches'} found. Choose the organization to audit.`);
    } catch (caught) {
      if (isAbort(caught)) return;
      setError(caught instanceof Error ? caught.message : 'The search could not be completed.');
      setStage('error');
    }
  };

  const run = async (candidate: Candidate) => {
    controller.current?.abort();
    const current = new AbortController();
    controller.current = current;
    setStage('running');
    setIdentityStep('Reading the Wikipedia article and Wikidata record');
    setSourceStates(ADAPTERS.map(adapter => ({ key: adapter.key, name: adapter.name, category: adapter.category, status: categories.includes(adapter.category) ? 'waiting' : 'skipped' })));
    setError('');
    announce(`Auditing ${candidate.title}. Searching public records; this usually takes 15 to 40 seconds.`);
    try {
      const result = await runAutomaticAudit({ candidate, version: auditVersion, cutoff, categories, existing, signal: current.signal, onProgress: update => {
        if (current.signal.aborted) return;
        if (update.stage === 'identity') setIdentityStep(`Reading ${update.name}`);
        if (update.stage === 'analysis') setIdentityStep('Matching evidence to the Ground-0 rules');
        if (update.stage === 'search' && update.source) {
          setSourceStates(states => states.map(state => state.key === update.source ? { ...state, status: update.status, count: update.count, note: update.note } : state));
          if (update.status && update.status !== 'running') announce(`${update.name}: ${STATUS_TEXT[update.status]}${update.count ? `, ${update.count.toLocaleString()} records` : ''}.`);
        }
      } });
      if (current.signal.aborted) return;
      setOutcome(result);
      setStage('result');
      announce(`Screening complete. Detected phase: ${spokenPhase[result.record.phase]}. ${result.record.provisionalBadge?.summary ?? ''} Review the evidence below.`);
    } catch (caught) {
      if (isAbort(caught)) return;
      setError(caught instanceof Error ? caught.message : 'The automatic audit could not be completed.');
      setStage('error');
    }
  };

  useEffect(() => {
    if (initialQuery.trim().length >= 2) void search(initialQuery);
    return () => controller.current?.abort();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (previousStage.current === stage) return;
    previousStage.current = stage;
    const timer = window.setTimeout(() => {
      if (stage === 'input') document.getElementById('auto-org')?.focus();
      else if (stage !== 'searching') heading.current?.focus();
    }, 40);
    return () => window.clearTimeout(timer);
  }, [stage]);

  const submitSearch = (event: FormEvent) => { event.preventDefault(); void search(query); };
  const submitChoice = (event: FormEvent) => { event.preventDefault(); if (candidates[selected]) void run(candidates[selected]); };
  const toggleCategory = (category: Category) => setCategories(current => current.includes(category) ? current.filter(item => item !== category) : [...current, category]);
  const record = outcome?.record;
  const searchedCount = outcome ? outcome.coverage.filter(entry => entry.status === 'searched' || entry.status === 'no-results').length + 1 : 0;

  return <Modal label="Automatic audit" className="auto-modal" onClose={onClose} initialFocus={stage === 'input' ? '#auto-org' : undefined}>
    <div className="modal-heading">
      <div><p className="eyebrow"><Icon name="sparkle" size={16}/>Automatic audit</p><h2>Audit an organization by name</h2><p>Court, legislative, news and archive records in. A traceable screening out.</p></div>
      <button type="button" className="icon-button" onClick={onClose} aria-label="Close automatic audit"><Icon name="close"/></button>
    </div>

    <div className="modal-body auto-body" aria-busy={stage === 'searching' || stage === 'running'}>
      {stage === 'input' && <form id="auto-search-form" className="auto-stage" onSubmit={submitSearch} noValidate>
        <h3 className="stage-heading" tabIndex={-1} ref={heading}>Which organization should we audit?</h3>
        <p className="stage-intro">Type or say its name. Ground-0 identifies it on Wikipedia and Wikidata, then searches public court, legislative, news and archive records dated on or before your cutoff, applies the fixed rules, and shows every quote it used.</p>
        <div className={`field ${inputError ? 'has-error' : ''}`}>
          <label className="field-name" htmlFor="auto-org">Organization name</label>
          <p className="field-hint" id="auto-org-hint">Full names work best: “World Health Organization” rather than “WHO”.</p>
          {inputError && <p className="field-error" id="auto-org-error"><Icon name="warning" size={16}/>{inputError}</p>}
          <div className="quick-input-row">
            <input id="auto-org" className="text-input" type="text" value={query} onChange={event => setQuery(event.target.value)} autoComplete="organization" spellCheck={false} aria-invalid={!!inputError || undefined} aria-describedby={inputError ? 'auto-org-hint auto-org-error' : 'auto-org-hint'}/>
            <VoiceButton onResult={setQuery}/>
          </div>
        </div>
        <div className="form-grid">
          <div className="field">
            <label className="field-name" htmlFor="auto-cutoff">Evidence cutoff</label>
            <p className="field-hint" id="auto-cutoff-hint">Only records dated on or before this day count. Choose an earlier date to audit the organization as it was then.</p>
            <input id="auto-cutoff" className="text-input" type="date" value={cutoff} max={today()} onChange={event => setCutoff(event.target.value)} aria-describedby="auto-cutoff-hint"/>
          </div>
          <fieldset className="version-choice">
            <legend className="field-name">Rules to apply</legend>
            <div className="choice-row">{([['1.0', 'v1.0 — normative baseline'], ['1.1', 'v1.1 — amendment draft (stricter)']] as const).map(([id, label]) => <label key={id} className={`choice-pill ${auditVersion === id ? 'selected' : ''}`}><input type="radio" name="auto-version" checked={auditVersion === id} onChange={() => setAuditVersion(id)}/><span>{label}</span></label>)}</div>
          </fieldset>
        </div>
        <fieldset className="source-choice">
          <legend className="field-name">Records to search</legend>
          <p className="field-hint">All sources are searched by default. Turn a group off to speed things up.</p>
          <div className="source-options">{CATEGORY_ORDER.map(category => <label key={category} className={`source-option ${categories.includes(category) ? 'selected' : ''} ${category === 'encyclopedic' ? 'locked' : ''}`}>
            <input type="checkbox" checked={categories.includes(category)} disabled={category === 'encyclopedic'} onChange={() => toggleCategory(category)}/>
            <span className="source-option-text"><strong>{CATEGORY_LABELS[category]}</strong><span>{CATEGORY_HELP[category]}</span></span>
          </label>)}</div>
        </fieldset>
        <div className="callout subtle"><Icon name="info" size={20}/><p>This is a <strong>screening</strong>, not a verdict. Keyword rules can misread context, so you can review and edit every answer afterwards. A provisional badge shows how far the evidence goes; a formal badge still needs a signed declaration.</p></div>
      </form>}

      {stage === 'searching' && <div className="loading-state" role="status"><span className="spinner" aria-hidden="true"/>Searching Wikipedia for “{query.trim()}”…</div>}

      {stage === 'choose' && <form id="auto-choose-form" className="auto-stage" onSubmit={submitChoice}>
        <h3 className="stage-heading" tabIndex={-1} ref={heading}>Which one do you mean?</h3>
        <p className="stage-intro">{candidates.length} {candidates.length === 1 ? 'match' : 'matches'} for “{query.trim()}”. Choose one, then start the audit.</p>
        <fieldset className="candidate-list">
          <legend className="sr-only">Matching Wikipedia articles</legend>
          {candidates.map((candidate, index) => <label key={candidate.title} className={`candidate-option ${selected === index ? 'selected' : ''}`}>
            <input type="radio" name="auto-candidate" checked={selected === index} onChange={() => setSelected(index)}/>
            <span className="candidate-text"><strong>{candidate.title}</strong><span>{candidate.description || 'No short description available'}</span></span>
            {candidate.qid && <span className="candidate-id">{candidate.qid}</span>}
          </label>)}
        </fieldset>
        <p className="field-hint">Evidence cutoff {formatDate(cutoff)} · Ground-0 v{auditVersion} · {categories.length} of {CATEGORY_ORDER.length} record groups</p>
      </form>}

      {stage === 'running' && <div className="auto-stage">
        <h3 className="stage-heading" tabIndex={-1} ref={heading}>Auditing {candidates[selected]?.title}</h3>
        <p className="stage-intro" role="status">{identityStep}. {sourceSummary}.</p>
        <ul className="source-progress" aria-label="Sources">{sourceStates.map(state => <li key={state.key} className={state.status ?? 'waiting'}>
          <span className="progress-icon" aria-hidden="true">{state.status === 'running' ? <span className="spinner small"/> : state.status === 'searched' || state.status === 'no-results' ? <Icon name="check" size={16}/> : state.status === 'unavailable' ? <Icon name="warning" size={16}/> : <span className="progress-dot"/>}</span>
          <span className="source-progress-name">{state.name}<span className="source-progress-category">{CATEGORY_LABELS[state.category]}</span></span>
          <span className="source-progress-status">{STATUS_TEXT[state.status ?? 'waiting']}{state.count ? ` · ${state.count.toLocaleString()} records` : ''}{state.status === 'unavailable' && state.note ? ` — ${state.note}` : ''}</span>
        </li>)}</ul>
      </div>}

      {stage === 'error' && <div className="auto-stage">
        <h3 className="stage-heading" tabIndex={-1} ref={heading}>We couldn’t finish the automatic audit</h3>
        <div className="callout danger" role="alert"><Icon name="warning" size={20}/><p>{error}</p></div>
        <p className="stage-intro">You can try again, check the spelling, or answer the five questions yourself in the manual audit.</p>
      </div>}

      {stage === 'result' && outcome && record && <div className="auto-result">
        <div className={`auto-verdict phase-${record.phase.toLowerCase()}`}>
          <p className="eyebrow">Automated screening · Ground-0 v{record.version}{record.version === '1.1' ? ' (draft rules)' : ''} · evidence to {formatDate(outcome.cutoff)}</p>
          <h3 className="stage-heading" tabIndex={-1} ref={heading}>{outcome.candidate.title}</h3>
          {outcome.candidate.description && <p className="verdict-description">{outcome.candidate.description}</p>}
          <div className="verdict-grid">
            <div>
              <div className="verdict-row"><PhaseBadge phase={record.phase}/><span className="review-flag"><Icon name="warning" size={16}/>Human review needed</span></div>
              <p className="plain-meaning"><strong>What this means:</strong> {plainPhase[record.phase]}</p>
              <dl className="verdict-facts">
                <div><dt>Branch confidence</dt><dd>{record.status === 'Draft' ? 'None — too little evidence' : record.confidence.charAt(0) + record.confidence.slice(1).toLowerCase()}</dd></div>
                <div><dt>Formal badge</dt><dd>Unissued — no signed declaration</dd></div>
                <div><dt>Sources searched</dt><dd>{searchedCount} of {outcome.coverage.length + 1}</dd></div>
                <div><dt>Documents checked</dt><dd>{outcome.documentsChecked.toLocaleString()} ({outcome.sentencesChecked.toLocaleString()} sentences)</dd></div>
              </dl>
            </div>
            {record.provisionalBadge && <PhaseRing badge={record.provisionalBadge}/>}
          </div>
          <p className="verdict-note">Confidence describes how well the five answers fit a phase pattern — not how reliable the automated evidence is. The provisional badge colours in only where a dated public record supports the answer.</p>
          <ListenButton text={speechSummary(outcome)} label="Listen to the summary"/>
        </div>

        {record.status === 'Draft' && <div className="callout amber"><Icon name="info" size={20}/><p><strong>Too little evidence to classify.</strong> The records searched did not contain statements matching the rules. Open the primary pages below, or run a manual audit with the organization’s own policies.</p></div>}
        {outcome.warnings.length > 0 && <div className="callout amber"><Icon name="warning" size={20}/><div><strong>Before you rely on this</strong><ul className="plain-list">{outcome.warnings.map(warning => <li key={warning}>{warning}</li>)}</ul></div></div>}

        <section aria-labelledby="auto-coverage-title">
          <h4 id="auto-coverage-title" className="subsection-title">Where we looked</h4>
          <p className="section-note">Every source, what was asked of it, and how many records came back. Each name opens the same search so you can repeat it.</p>
          <CoverageTable coverage={outcome.coverage}/>
        </section>

        <section aria-labelledby="auto-questions-title">
          <h4 id="auto-questions-title" className="subsection-title">The five questions</h4>
          <ol className="auto-questions">{outcome.findings.map((finding, index) => <FindingItem key={finding.code} finding={finding} title={questions[index].title}/>)}</ol>
        </section>

        {(record.phase === 'AMBIGUOUS' || record.phase === 'NAB-Constrained') && <section aria-labelledby="auto-constraints-title">
          <h4 id="auto-constraints-title" className="subsection-title">Constraint checks (Step 3.5)</h4>
          <p className="section-note">An ambiguous result becomes NAB-Constrained only if all four checks are shown with dated records.</p>
          <ol className="auto-questions">{outcome.constraints.map((finding, index) => <FindingItem key={finding.code} finding={finding} title={constraintQuestions[index].title} isConstraint/>)}</ol>
        </section>}

        {outcome.primaryPages.length > 0 && <section aria-labelledby="auto-pages-title">
          <h4 id="auto-pages-title" className="subsection-title">Primary pages to review</h4>
          <p className="section-note">The organization’s own pages, each dated by its archived capture. A browser cannot read archived page text from another site, so open them yourself and cite the archived copy in a review — the date is already established.</p>
          <ul className="page-list">{outcome.primaryPages.map(page => <li key={page.url}><a href={page.url} target="_blank" rel="noreferrer">{page.original.replace(/^https?:\/\//, '')}<span className="sr-only"> (archived copy, opens in a new tab)</span></a><span>Archived {formatDate(page.date)} · {page.dateBasis}</span></li>)}</ul>
        </section>}

        <section aria-labelledby="auto-sources-title">
          <h4 id="auto-sources-title" className="subsection-title">Identity sources, pinned to exact revisions</h4>
          <ul className="source-list">{outcome.sources.map(source => <li key={source.url}><a href={source.url} target="_blank" rel="noreferrer">{source.name}<span className="sr-only"> (opens in a new tab)</span></a><span>{source.role} · revision {source.revision} · {formatDate(source.published)}</span></li>)}</ul>
          {outcome.facts.length > 0 && <dl className="fact-list">{outcome.facts.map(fact => <div key={fact.label}><dt>{fact.label}</dt><dd>{fact.url ? <a href={fact.url} target="_blank" rel="noreferrer">{fact.value}<span className="sr-only"> (opens in a new tab)</span></a> : fact.value}</dd></div>)}</dl>}
        </section>

        <section aria-labelledby="auto-gaps-title" className="not-covered">
          <h4 id="auto-gaps-title" className="subsection-title">Not covered by this screening</h4>
          <ul className="plain-list">{outcome.notCovered.map(item => <li key={item}>{item}</li>)}</ul>
        </section>
        <details className="auto-more how-it-works"><summary>How this screening works and its limits</summary><ul className="plain-list">{LIMITATIONS.map(item => <li key={item}>{item}</li>)}</ul></details>
        <button type="button" className="text-button" onClick={() => { setOutcome(null); setQuery(''); setStage('input'); }}>Audit another organization<Icon name="arrow" size={16}/></button>
      </div>}
    </div>

    <div className="modal-footer">
      <p className="footer-status">{stage === 'result' ? 'Automated screening · human review needed' : 'Key-free public record sources · nothing leaves your browser except the searches'}</p>
      <div className="footer-actions">
        {stage === 'input' && <><button type="button" className="button secondary" onClick={onClose}>Cancel</button><button type="submit" form="auto-search-form" className="button primary"><Icon name="search" size={18}/>Find organization</button></>}
        {stage === 'searching' && <button type="button" className="button secondary" onClick={() => { controller.current?.abort(); setStage('input'); announce('Search cancelled.'); }}>Cancel search</button>}
        {stage === 'choose' && <><button type="button" className="button secondary" onClick={() => setStage('input')}>Back</button><button type="submit" form="auto-choose-form" className="button primary">Audit this organization<Icon name="arrow" size={18}/></button></>}
        {stage === 'running' && <button type="button" className="button secondary" onClick={() => { controller.current?.abort(); setStage('choose'); announce('Audit cancelled.'); }}>Cancel audit</button>}
        {stage === 'error' && <><button type="button" className="button secondary" onClick={onManual}>Use the manual audit</button><button type="button" className="button primary" onClick={() => setStage('input')}>Try again</button></>}
        {stage === 'result' && record && <><button type="button" className="button secondary" onClick={() => onReview(record)}><Icon name="clipboard" size={18}/>Review and edit</button><button type="button" className="button secondary" onClick={() => exportAudit(record)}><Icon name="download" size={18}/>Export JSON</button><button type="button" className="button primary" onClick={() => onSave(record)}><Icon name="check" size={18}/>Save to register</button></>}
      </div>
    </div>
  </Modal>;
}
