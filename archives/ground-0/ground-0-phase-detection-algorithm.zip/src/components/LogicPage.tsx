import { useState } from 'react';
import Icon from './Icon';
import { BinaryChoice, ConfidenceIndicator, PhaseBadge, VersionSwitch, plainPhase } from './ui';
import { classify, phaseDefinitions, questions, type Phase, type Version } from '../lib/engine';
import { provisionalBadge } from '../lib/badge';
import PhaseRing from './PhaseRing';

const flow: [string, string][] = [['shield', 'Validate the declaration'], ['clipboard', 'Observe behavior'], ['layers', 'Detect the phase'], ['target', 'Compare and classify'], ['timeline', 'Audit over time']];
const constraintLabels = ['External override', 'Functional appeals (50% relief or more)', 'Authority sunset', 'Constraints active now'];

export default function LogicPage({ version, setVersion, onManual, onAuto }: { version: Version; setVersion: (version: Version) => void; onManual: () => void; onAuto: () => void }) {
  const [vector, setVector] = useState([false, true, false, true, false]);
  const [constraints, setConstraints] = useState([false, false, false, false]);
  const result = classify(vector);
  const actual: Phase = result.phase === 'AMBIGUOUS' && constraints.every(Boolean) ? 'NAB-Constrained' : result.phase;
  const confidence = actual === 'NAB-Constrained' ? 'HIGH' : result.confidence;
  return <>
    <div className="page-heading">
      <div><p className="eyebrow">Transparent by design</p><h1>No black box. Just the branches.</h1><p>See how five yes-or-no observations become a phase classification.</p></div>
      <div className="heading-actions"><button type="button" className="button secondary" onClick={onManual}><Icon name="clipboard" size={18}/>Manual audit</button><button type="button" className="button primary" onClick={onAuto}><Icon name="sparkle" size={18}/>Automatic audit</button></div>
    </div>
    <div className="logic-version-row"><VersionSwitch version={version} onChange={setVersion}/><span className="local-label"><Icon name="code" size={16}/>Rules sandbox — no evidence credit</span></div>
    <ol className="logic-flow" aria-label="Algorithm steps">{flow.map(([icon, title], index) => <li key={title} className="logic-step"><span className="logic-step-number">Step {index + 1}</span><Icon name={icon} size={24}/><strong>{title}</strong></li>)}</ol>
    <div className="logic-grid">
      <section className="panel predicate-card" aria-labelledby="sandbox-title">
        <p className="eyebrow">Interactive decision tree</p>
        <h2 id="sandbox-title" className="panel-title">Change the observations</h2>
        <p className="panel-intro">Choose Yes or No for each question. The result updates straight away.</p>
        <div className="predicate-list">{questions.map((question, index) => <div className="predicate-row" key={question.code}>
          <span className="question-code" aria-hidden="true">{question.code}</span>
          <div className="predicate-text"><strong>{question.title}</strong><span>{question.variable}</span></div>
          <BinaryChoice name={`sandbox-${question.code}`} idPrefix={`sandbox-${question.code}`} legend={`${question.code}: ${question.title}`} value={vector[index]} onChange={value => setVector(vector.map((item, position) => position === index ? value : item))}/>
        </div>)}</div>
        <div className="predicate-presets"><span>Load a pattern:</span>{phaseDefinitions.filter(item => item.vector).map(item => <button type="button" key={item.phase} className="button secondary small" onClick={() => { setVector(item.vector!.map(value => value === true)); setConstraints([false, false, false, false]); }}>{item.phase}</button>)}</div>
      </section>
      <section className="panel logic-result" aria-labelledby="sandbox-result-title">
        <p className="eyebrow" id="sandbox-result-title">The rules return</p>
        <p className="sr-only" role="status">{`Result: ${actual}, ${confidence.toLowerCase()} confidence.`}</p>
        <div className="logic-result-phase"><PhaseBadge phase={actual}/><ConfidenceIndicator confidence={confidence}/></div>
        <p className="plain-meaning">{plainPhase[actual]}</p>
        <div className="badge-panel sandbox-badge"><PhaseRing badge={provisionalBadge(vector, [true, true, true, true, true])}/><p className="badge-note">In the sandbox every answer counts as evidenced, so all five segments colour in. Blue segments agree with the CWO presumption; hatched segments prove it wrong.</p></div>
        <h3 className="subsection-title">Branch matches</h3>
        <ul className="branch-matches">{['NAB', 'CWO', 'GSRB'].map((phase, index) => { const total = index === 1 ? 4 : 5; return <li key={phase}><div><strong>{phase}</strong><span>{result.matches[index]} of {total} conditions</span></div><div className="branch-bar" aria-hidden="true"><i style={{ width: `${(result.matches[index] / total) * 100}%` }}/></div></li>; })}</ul>
        {result.phase === 'AMBIGUOUS' ? <fieldset className="sandbox-constraints">
          <legend>Step 3.5 — all four must pass</legend>
          {constraintLabels.map((label, index) => <label className="checkbox-label" key={label}><input type="checkbox" checked={constraints[index]} onChange={event => setConstraints(constraints.map((item, position) => position === index ? event.target.checked : item))}/>C{index + 1} · {label}</label>)}
          <p>{actual === 'NAB-Constrained' ? 'All four constraints are met. This is a rules result, not a verified badge.' : 'Any unmet constraint keeps the result AMBIGUOUS. There is no automatic escalation to GSRB.'}</p>
        </fieldset> : <p className="logic-explanation">{actual === 'CWO' ? 'All four CWO conditions match. B4 is not part of the CWO branch.' : `Every required ${actual} condition matches. The first complete branch wins.`}</p>}
        <p className="sandbox-disclaimer"><Icon name="info" size={16}/>This sandbox tests the decision rules only. Real audits need public evidence and a validated declaration.</p>
      </section>
    </div>
    <div className="callout subtle implementation-note"><Icon name="code" size={20}/><p><strong>An implementation boundary, not an amendment.</strong> NAB and GSRB require opposite answers, so every complete set of five answers matches at least three conditions of one branch. INCOHERENT stays in the specification but cannot occur for a complete set of answers. {version === '1.0' ? 'The undefined optional escalation in v1.0 is not automated.' : 'The v1.1 draft keeps AMBIGUOUS when any constraint fails.'}</p></div>
    <details className="panel truth-table">
      <summary><span><Icon name="grid" size={20}/>The complete truth table (32 combinations)</span><Icon name="down" size={18}/></summary>
      <div className="table-scroll" role="region" aria-label="Truth table" tabIndex={0}>
        <table className="spec-table">
          <caption className="sr-only">Every combination of the five answers and the Step 3 result</caption>
          <thead><tr>{['B1', 'B2', 'B3', 'B4', 'B5', 'Step 3 phase', 'Confidence'].map(header => <th scope="col" key={header}>{header}</th>)}</tr></thead>
          <tbody>{Array.from({ length: 32 }, (_, number) => { const answers = Array.from({ length: 5 }, (_, bit) => Boolean(number & (1 << (4 - bit)))); const row = classify(answers); return <tr key={number}>{answers.map((answer, index) => <td key={index} className={answer ? 'positive' : ''}>{answer ? 'Yes' : 'No'}</td>)}<td><PhaseBadge phase={row.phase} compact/></td><td>{row.confidence}</td></tr>; })}</tbody>
        </table>
      </div>
    </details>
  </>;
}
