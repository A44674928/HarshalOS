import Icon from './Icon';
import Modal from './Modal';
import { ListenButton } from './ui';
import { defaultPrefs, recognitionSupported, speechSupported, type A11yPrefs, type TextSize } from '../lib/a11y';

const sizes: { id: TextSize; label: string; scale: string; sample: string }[] = [
  { id: 'default', label: 'Default', scale: '100%', sample: '1rem' },
  { id: 'large', label: 'Large', scale: '112%', sample: '1.2rem' },
  { id: 'larger', label: 'Larger', scale: '125%', sample: '1.4rem' },
  { id: 'largest', label: 'Largest', scale: '150%', sample: '1.65rem' },
];

export function AccessibilitySettings({ prefs, onChange }: { prefs: A11yPrefs; onChange: (prefs: A11yPrefs) => void }) {
  const set = <K extends keyof A11yPrefs>(key: K, value: A11yPrefs[K]) => onChange({ ...prefs, [key]: value });
  return <div className="a11y-settings">
    <fieldset className="setting-group">
      <legend><Icon name="type" size={20}/>Text size</legend>
      <p className="setting-help">Scales text and spacing across the workspace, like zoom. The layout reflows to fit.</p>
      <div className="option-grid">{sizes.map(size => <label key={size.id} className={`option-card ${prefs.textSize === size.id ? 'selected' : ''}`}>
        <input type="radio" name="g0-text-size" value={size.id} checked={prefs.textSize === size.id} onChange={() => set('textSize', size.id)}/>
        <span className="option-sample" aria-hidden="true" style={{ fontSize: size.sample }}>Aa</span>
        <span className="option-label">{size.label}</span>
        <span className="option-meta">{size.scale}</span>
      </label>)}</div>
    </fieldset>

    <fieldset className="setting-group">
      <legend><Icon name="contrast" size={20}/>Contrast</legend>
      <p className="setting-help">High contrast uses black text, stronger borders and underlined links.</p>
      <div className="choice-row">{([['system', 'Match my device'], ['standard', 'Standard'], ['high', 'High contrast']] as const).map(([id, label]) => <label key={id} className={`choice-pill ${prefs.contrast === id ? 'selected' : ''}`}>
        <input type="radio" name="g0-contrast" value={id} checked={prefs.contrast === id} onChange={() => set('contrast', id)}/><span>{label}</span>
      </label>)}</div>
    </fieldset>

    <fieldset className="setting-group">
      <legend><Icon name="pause" size={20}/>Motion</legend>
      <p className="setting-help">Reduce motion turns off animated transitions and spinners.</p>
      <div className="choice-row">{([['system', 'Match my device'], ['reduce', 'Reduce motion']] as const).map(([id, label]) => <label key={id} className={`choice-pill ${prefs.motion === id ? 'selected' : ''}`}>
        <input type="radio" name="g0-motion" value={id} checked={prefs.motion === id} onChange={() => set('motion', id)}/><span>{label}</span>
      </label>)}</div>
    </fieldset>

    <div className="setting-group" role="group" aria-labelledby="reading-setting-title">
      <h3 className="setting-title" id="reading-setting-title"><Icon name="eye" size={20}/>Reading</h3>
      <label className="switch-row">
        <input type="checkbox" role="switch" checked={prefs.readable} onChange={event => set('readable', event.target.checked)}/>
        <span className="switch-track" aria-hidden="true"><span/></span>
        <span className="switch-text"><strong>Readable font and spacing</strong><span>Atkinson Hyperlegible, designed for low-vision readers, with wider letter, word and line spacing.</span></span>
      </label>
      <label className="switch-row">
        <input type="checkbox" role="switch" checked={prefs.underline} onChange={event => set('underline', event.target.checked)}/>
        <span className="switch-track" aria-hidden="true"><span/></span>
        <span className="switch-text"><strong>Underline all links and link-style buttons</strong><span>Makes links recognizable without relying on color.</span></span>
      </label>
    </div>

    {speechSupported() && <fieldset className="setting-group">
      <legend><Icon name="volume" size={20}/>Read-aloud speed</legend>
      <p className="setting-help">Used by every “Listen” button. Speech uses your device’s built-in voice.</p>
      <div className="choice-row">{([[0.8, 'Slower'], [1, 'Normal'], [1.25, 'Faster']] as const).map(([rate, label]) => <label key={label} className={`choice-pill ${prefs.speechRate === rate ? 'selected' : ''}`}>
        <input type="radio" name="g0-speech-rate" value={rate} checked={prefs.speechRate === rate} onChange={() => set('speechRate', rate)}/><span>{label}</span>
      </label>)}</div>
      <ListenButton text="This is how Ground-0 reads findings aloud. You can stop at any time." label="Test the voice"/>
    </fieldset>}

    <div className="settings-footer">
      <p><Icon name="lock" size={16}/>Saved in this browser only.{recognitionSupported() ? ' Voice input is available in the automatic audit.' : ''}</p>
      <button type="button" className="button secondary" onClick={() => onChange({ ...defaultPrefs })}><Icon name="refresh" size={18}/>Reset to defaults</button>
    </div>
  </div>;
}

export function AccessibilityDialog({ prefs, onChange, onClose, onOpenPage }: { prefs: A11yPrefs; onChange: (prefs: A11yPrefs) => void; onClose: () => void; onOpenPage: () => void }) {
  return <Modal label="Accessibility settings" className="a11y-modal" onClose={onClose}>
    <div className="modal-heading">
      <div><p className="eyebrow">Accessibility</p><h2>Make Ground-0 comfortable for you</h2><p>Changes apply immediately.</p></div>
      <button type="button" className="icon-button" onClick={onClose} aria-label="Close accessibility settings"><Icon name="close"/></button>
    </div>
    <div className="modal-body"><AccessibilitySettings prefs={prefs} onChange={onChange}/></div>
    <div className="modal-footer">
      <button type="button" className="text-button" onClick={onOpenPage}>Keyboard shortcuts and accessibility statement<Icon name="arrow" size={16}/></button>
      <button type="button" className="button primary" onClick={onClose}>Done</button>
    </div>
  </Modal>;
}

const shortcuts: [string[], string][] = [
  [['Tab'], 'Move to the next control'],
  [['Shift', 'Tab'], 'Move to the previous control'],
  [['←', '→'], 'Change a Yes/No answer or switch between tabs'],
  [['Enter'], 'Activate a button or open an audit'],
  [['Space'], 'Select a choice or toggle a switch'],
  [['Ctrl', 'K'], 'Search the workspace (⌘ K on Mac)'],
  [['Esc'], 'Close a dialog, menu or search'],
];

export function AccessibilityPage({ prefs, onChange, onAuto, onManual }: { prefs: A11yPrefs; onChange: (prefs: A11yPrefs) => void; onAuto: () => void; onManual: () => void }) {
  return <>
    <div className="page-heading"><div><p className="eyebrow">Accessibility</p><h1>Built to work the way you do.</h1><p>Adjust the display, use voice input and read-aloud, and find every keyboard shortcut.</p></div></div>
    <div className="a11y-layout">
      <section className="panel" aria-labelledby="display-settings-title">
        <h2 id="display-settings-title" className="panel-title">Display and reading</h2>
        <AccessibilitySettings prefs={prefs} onChange={onChange}/>
      </section>
      <div className="a11y-side">
        <section className="panel" aria-labelledby="audit-ways-title">
          <h2 id="audit-ways-title" className="panel-title">Choose the effort that suits you</h2>
          <ul className="feature-list">
            <li><Icon name="sparkle" size={20}/><span><strong>Automatic audit.</strong> Type or say an organization’s name. Ground-0 searches court, legislative, news and archive records, applies the rules and reads the result aloud if you like.</span></li>
            <li><Icon name="clipboard" size={20}/><span><strong>Manual audit.</strong> Answer five Yes/No questions at your own pace. Drafts save in this browser, so you can stop and return.</span></li>
          </ul>
          <div className="button-row"><button type="button" className="button primary" onClick={onAuto}><Icon name="sparkle" size={18}/>Automatic audit</button><button type="button" className="button secondary" onClick={onManual}>Manual audit</button></div>
        </section>
        <section className="panel" aria-labelledby="shortcuts-title">
          <h2 id="shortcuts-title" className="panel-title"><Icon name="keyboard" size={22}/>Keyboard shortcuts</h2>
          <table className="shortcut-table">
            <caption className="sr-only">Keyboard shortcuts available throughout Ground-0</caption>
            <thead><tr><th scope="col">Keys</th><th scope="col">What it does</th></tr></thead>
            <tbody>{shortcuts.map(([keys, action]) => <tr key={action}><td>{keys.map((key, index) => <span key={key}>{index > 0 && <span aria-hidden="true"> + </span>}<kbd>{key}</kbd></span>)}</td><td>{action}</td></tr>)}</tbody>
          </table>
        </section>
      </div>
    </div>
    <section className="panel statement" aria-labelledby="statement-title">
      <h2 id="statement-title" className="panel-title">Accessibility statement</h2>
      <p>Ground-0 is designed to meet the Web Content Accessibility Guidelines (WCAG) 2.2 at Level AA. Automated axe-core checks run during development. The workspace has not been independently audited or certified.</p>
      <h3>What is built in</h3>
      <ul className="statement-list">
        <li>Complete keyboard access, a “Skip to main content” link, visible focus indicators and focus returned after every dialog closes.</li>
        <li>Screen reader landmarks, a logical heading order, labelled controls, announced page changes and live status updates.</li>
        <li>Text and controls that meet contrast minimums, an optional high-contrast mode, and a layout that reflows to a single column at 320 CSS pixels.</li>
        <li>Text sizes up to 150%, a readable font option with wider spacing, reduced motion and underlined links.</li>
        <li>Plain-language explanations beside technical phase names, read-aloud summaries and voice input where your browser supports them.</li>
        <li>Forms that explain what went wrong, link straight to each problem and keep your answers. There are no time limits.</li>
      </ul>
      <h3>Known limitations</h3>
      <ul className="statement-list">
        <li>Automatic audits depend on public record services being reachable from your browser (Wikipedia, Wikidata, CourtListener, the Federal Register, GovTrack, legislation.gov.uk, GDELT, the Internet Archive). Unavailable sources are reported, and every result needs human review.</li>
        <li>Voice input and read-aloud depend on your browser. When they are unavailable, typing and your own screen reader still work.</li>
        <li>Wide data tables scroll sideways on small screens. Each table is a labelled region you can scroll with the keyboard.</li>
        <li>JSON exports are technical files intended for archiving and replication, not for reading.</li>
      </ul>
    </section>
  </>;
}
