import { useEffect, useRef, useState, type ReactNode } from 'react';
import Icon from './Icon';
import Modal from './Modal';
import PhaseRing from './PhaseRing';
import { BinaryChoice, ErrorSummary, Field, describedBy, type FieldError } from './ui';
import { announce } from '../lib/a11y';
import { b4Qualifies, classify, constraintQuestions, createAudit, formatDate, headerExample, newInput, questions, scoredVector, validatePDH, type Answer, type AuditInput, type AuditRecord, type PDHResult, type Version } from '../lib/engine';

const steps = ['Entity and declaration', 'Behavioral audit', 'Constraints and history', 'Review and classify'];
type ReliefKey = 'numerator' | 'denominator' | 'complete' | 'start' | 'end';

function AnswerCard({ code, title, description, answer, onChange, open, onToggle, cutoff, invalid, children }: { code: string; title: string; description: string; answer: Answer; onChange: (answer: Answer) => void; open: boolean; onToggle: () => void; cutoff: string; invalid: boolean; children?: ReactNode }) {
  const bodyId = `card-${code}-body`;
  return <section className={`answer-card ${open ? 'expanded' : ''} ${invalid ? 'invalid' : ''}`} aria-labelledby={`card-${code}-title`}>
    <div className="answer-card-top">
      <h4 className="answer-heading" id={`card-${code}-title`}><span className="question-code">{code}</span><span>{title}</span></h4>
      <BinaryChoice name={`wizard-${code}`} idPrefix={`q-${code}`} legend={`${code}: ${title}`} value={answer.value} onChange={value => onChange({ ...answer, value })} invalid={invalid}/>
    </div>
    {invalid && <p className="field-error card-error"><Icon name="warning" size={16}/>Choose Yes or No for {code}.</p>}
    <button type="button" className="answer-toggle" aria-expanded={open} aria-controls={bodyId} onClick={onToggle}>
      <Icon name="down" size={16} className={open ? 'rotated' : ''}/>{open ? 'Hide description and evidence' : 'Show description and add evidence'}
      {answer.source && <span className="evidence-flag"><Icon name="link" size={14}/>Source added</span>}
    </button>
    <div id={bodyId} className="answer-card-body" hidden={!open}>
      <p className="answer-description">{description}</p>
      <div className="form-grid source-grid">
        <label className="field-label">Public source URL<input className="text-input" type="url" inputMode="url" placeholder="https://" value={answer.source} onChange={event => onChange({ ...answer, source: event.target.value })}/></label>
        <label className="field-label">Published or effective date<input className="text-input" type="date" value={answer.date} max={cutoff} onChange={event => onChange({ ...answer, date: event.target.value })}/></label>
      </div>
      <label className="field-label">Claim this artifact supports<textarea className="text-input" rows={3} placeholder="Describe the observable evidence, not an interpretation." value={answer.notes} onChange={event => onChange({ ...answer, notes: event.target.value })}/></label>
      {answer.value === false && <label className="field-label">Evidence gap or bounded search<textarea className="text-input" rows={3} placeholder="If there is no contrary artifact, say what you searched, over what period, and what was not shown." value={answer.gap} onChange={event => onChange({ ...answer, gap: event.target.value })}/></label>}
      {children}
    </div>
  </section>;
}

function ReliefFields({ numerator, denominator, complete, start, end, onChange, cutoff }: { numerator: string; denominator: string; complete: boolean; start: string; end: string; onChange: (key: ReliefKey, value: string | boolean) => void; cutoff: string }) {
  const rate = denominator && Number(denominator) > 0 ? Math.round(Number(numerator) / Number(denominator) * 100) : null;
  return <div className="relief-fields">
    <div className="form-grid">
      <label className="field-label">Cases granting relief<input className="text-input" type="number" min="0" inputMode="numeric" value={numerator} onChange={event => onChange('numerator', event.target.value)}/></label>
      <label className="field-label">All resolved cases<input className="text-input" type="number" min="1" inputMode="numeric" value={denominator} onChange={event => onChange('denominator', event.target.value)}/></label>
      <label className="field-label">Period begins<input className="text-input" type="date" value={start} max={cutoff} onChange={event => onChange('start', event.target.value)}/></label>
      <label className="field-label">Period ends<input className="text-input" type="date" value={end} max={cutoff} onChange={event => onChange('end', event.target.value)}/></label>
    </div>
    <label className="checkbox-label"><input type="checkbox" checked={complete} onChange={event => onChange('complete', event.target.checked)}/>This is the complete, published set of resolved cases for the period.</label>
    {rate !== null && <p className={`inline-rate ${rate >= 50 ? 'positive' : ''}`}>{rate}% relief — at least 50% is required.</p>}
  </div>;
}

export default function AuditWizard({ initialVersion, initialInput, mode = 'new', existing, onClose, onSave }: { initialVersion: Version; initialInput?: AuditInput; mode?: 'new' | 'draft' | 'review'; existing: AuditRecord[]; onClose: () => void; onSave: (record: AuditRecord) => void }) {
  const [input, setInput] = useState<AuditInput>(() => initialInput ? JSON.parse(JSON.stringify(initialInput)) as AuditInput : newInput(initialVersion));
  const [step, setStep] = useState(0);
  const [activeQuestion, setActiveQuestion] = useState(mode === 'review' ? -1 : 0);
  const [activeConstraint, setActiveConstraint] = useState(-1);
  const [pdh, setPdh] = useState<PDHResult | null>(null);
  const [checking, setChecking] = useState(false);
  const [preview, setPreview] = useState<AuditRecord | null>(null);
  const [error, setError] = useState('');
  const [errors, setErrors] = useState<FieldError[]>([]);
  const [attempt, setAttempt] = useState(0);
  const stepHeading = useRef<HTMLHeadingElement>(null);
  const previousStep = useRef(step);
  const vector = scoredVector(input);
  const detected = classify(vector);
  const prior = existing.filter(audit => !audit.baseline && (input.identifier ? audit.identifier === input.identifier : audit.name.toLowerCase() === input.name.toLowerCase()));
  const update = <K extends keyof AuditInput>(key: K, value: AuditInput[K]) => { setInput(current => ({ ...current, [key]: value })); setPdh(null); };
  const updateAnswer = (index: number, answer: Answer, constraint = false) => setInput(current => constraint ? { ...current, constraints: current.constraints.map((item, position) => position === index ? answer : item) } : { ...current, answers: current.answers.map((item, position) => position === index ? answer : item) });
  const errorFor = (field: string) => errors.find(item => item.field === field)?.message;

  const validate = (target: number, data: AuditInput): FieldError[] => {
    if (target === 0) return [
      ...(data.name.trim().length < 2 ? [{ field: 'wizard-name', message: 'Enter the entity’s name, at least two characters.' }] : []),
      ...(!data.cutoff ? [{ field: 'wizard-cutoff', message: 'Choose an evidence cutoff date.' }] : []),
    ];
    if (target === 1) return data.answers.flatMap((answer, index) => answer.value === null ? [{ field: `q-${questions[index].code}-yes`, message: `Answer ${questions[index].code}: ${questions[index].title}` }] : []);
    if (target === 2 && classify(scoredVector(data)).phase === 'AMBIGUOUS') return data.constraints.flatMap((answer, index) => answer.value === null ? [{ field: `q-${constraintQuestions[index].code}-yes`, message: `Answer ${constraintQuestions[index].code}: ${constraintQuestions[index].title}` }] : []);
    return [];
  };

  useEffect(() => { if (errors.length) setErrors(validate(step, input)); }, [input]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (step !== 3) return;
    let cancelled = false;
    setPreview(null);
    createAudit(input, existing).then(record => { if (!cancelled) setPreview(record); }).catch(() => { if (!cancelled) setError('The record could not be generated. Check the declaration header and try again.'); });
    return () => { cancelled = true; };
  }, [step, input, existing]);

  useEffect(() => {
    if (previousStep.current === step) return;
    previousStep.current = step;
    stepHeading.current?.focus();
    announce(`Step ${step + 1} of 4: ${steps[step]}.`);
  }, [step]);

  const next = () => {
    if (step === 3) { if (preview) onSave(preview); return; }
    const found = validate(step, input);
    setErrors(found);
    setAttempt(value => value + 1);
    if (found.length) return;
    setError('');
    setStep(step + 1);
  };
  const back = () => { setErrors([]); setStep(step - 1); };
  const checkHeader = async () => { setChecking(true); const result = await validatePDH(input); setPdh(result); setChecking(false); announce(`Declaration check: ${result.status === 'VALID' ? 'valid' : 'not valid'}. ${result.reason}`); };
  const title = mode === 'review' ? 'Review the automated screening' : mode === 'draft' ? 'Continue your audit' : 'Start with what you can observe';
  const subtitle = mode === 'review' ? 'Check each answer and quote, correct anything that is wrong, then save.' : mode === 'draft' ? 'Your earlier answers are filled in.' : 'Evidence in. Accountability out.';

  return <Modal className="audit-wizard" label={title} onClose={onClose} initialFocus={mode === 'new' ? '#wizard-name' : undefined}>
    <div className="modal-heading">
      <div><p className="eyebrow"><Icon name="clipboard" size={16}/>{mode === 'review' ? 'Human review' : 'Manual audit'}</p><h2>{title}</h2><p>{subtitle}</p></div>
      <button type="button" className="icon-button" onClick={onClose} aria-label="Close the audit"><Icon name="close"/></button>
    </div>
    <div className="wizard-layout">
      <nav className="wizard-steps" aria-label="Audit steps">
        <ol>{steps.map((label, index) => <li key={label}><button type="button" className={`wizard-step ${step === index ? 'current' : ''} ${step > index ? 'finished' : ''}`} aria-current={step === index ? 'step' : undefined} onClick={() => { if (index < step) { setErrors([]); setStep(index); } }} disabled={index > step}>
          <span className="wizard-step-number" aria-hidden="true">{step > index ? <Icon name="check" size={14}/> : index + 1}</span>
          <span>{label}{step > index && <span className="sr-only"> (completed)</span>}</span>
        </button></li>)}</ol>
        <p className="wizard-privacy"><Icon name="lock" size={16}/>Saved only in this browser.</p>
      </nav>
      <div className="wizard-content" key={step}>
        <div className="step-heading"><p className="step-kicker">Step {step + 1} of 4</p><h3 tabIndex={-1} ref={stepHeading}>{steps[step]}</h3></div>
        <ErrorSummary errors={errors} focusKey={attempt} title="Before you continue"/>

        {step === 0 && <>
          <p className="step-intro">Give this assessment a stable name and an inclusive evidence cutoff.</p>
          <div className="form-grid">
            <Field id="wizard-name" label="Entity name" required error={errorFor('wizard-name')}><input id="wizard-name" className="text-input" autoComplete="organization" value={input.name} onChange={event => update('name', event.target.value)} aria-invalid={!!errorFor('wizard-name') || undefined} aria-describedby={describedBy('wizard-name', undefined, errorFor('wizard-name'))} placeholder="e.g. Research Advisory Council"/></Field>
            <Field id="wizard-id" label="Entity identifier" hint="Use the same ID for later audits of this entity."><input id="wizard-id" className="text-input" value={input.identifier} onChange={event => update('identifier', event.target.value)} aria-describedby="wizard-id-hint" placeholder="e.g. RAC-001"/></Field>
            <Field id="wizard-cutoff" label="Evidence cutoff" required hint="Inclusive, through the end of the day (UTC)." error={errorFor('wizard-cutoff')}><input id="wizard-cutoff" className="text-input" type="date" value={input.cutoff} onChange={event => update('cutoff', event.target.value)} aria-invalid={!!errorFor('wizard-cutoff') || undefined} aria-describedby={describedBy('wizard-cutoff', 'hint', errorFor('wizard-cutoff'))}/></Field>
            <Field id="wizard-version" label="Algorithm version" hint="The chosen rules are recorded in the output."><select id="wizard-version" className="text-input" value={input.version} onChange={event => update('version', event.target.value as Version)} aria-describedby="wizard-version-hint"><option value="1.0">v1.0 — normative baseline</option><option value="1.1">v1.1 — amendment draft</option></select></Field>
          </div>
          {input.version === '1.1' && <div className="callout amber"><Icon name="info" size={20}/><p><strong>Proposed, not ratified.</strong> The v1.1 amendment is pending author adoption and does not replace v1.0.</p></div>}
          <details className="pdh-details">
            <summary><span><Icon name="file" size={20}/>Add a Phase Declaration Header (optional)</span><Icon name="down" size={18}/></summary>
            <div className="pdh-content">
              <p>Without a valid signed header, behavior can still be classified, but no phase badge is issued.</p>
              <div className="field">
                <div className="field-name-row"><label className="field-name" htmlFor="wizard-pdh">Declaration header (JSON)</label><button type="button" className="text-button" onClick={() => { update('headerText', headerExample); if (!input.identifier) update('identifier', 'ENTITY-001'); }}>Insert the format template</button></div>
                <textarea id="wizard-pdh" className="text-input code-input" rows={8} value={input.headerText} onChange={event => update('headerText', event.target.value)} placeholder="Paste the 11 required fields as a JSON object."/>
              </div>
              <label className="field-label">Trusted Center-Origin<input className="text-input" value={input.trustedOrigin} onChange={event => update('trustedOrigin', event.target.value)}/></label>
              <label className="field-label">Trusted origin public key (JWK)<textarea className="text-input code-input" rows={3} value={input.publicKeyText} onChange={event => update('publicKeyText', event.target.value)} placeholder='{"kty":"EC","crv":"P-256","x":"…","y":"…"}'/></label>
              <p className="field-hint">Workspace adapter: ECDSA P-256 with SHA-256 over the sorted JSON of the ten fields other than Declaration-Hash. You must establish trust in the origin key yourself; other signature formats are not verified here.</p>
              <button type="button" className="button secondary small" disabled={checking} onClick={checkHeader}><Icon name="shield" size={18}/>{checking ? 'Checking…' : 'Check the header'}</button>
              {pdh && <div className={`pdh-result ${pdh.status === 'VALID' ? 'valid' : ''}`} role="status">
                <ul className="validation-checks">{([['Complete', pdh.structural], ['Signed', pdh.signature], ['Fresh', pdh.freshness], ['Consistent', pdh.consistency]] as const).map(([label, valid]) => <li key={label} className={valid ? 'valid' : ''}><Icon name={valid ? 'check-circle' : 'close'} size={16}/>{label}: {valid ? 'yes' : 'no'}</li>)}</ul>
                <p>{pdh.reason}</p>
              </div>}
            </div>
          </details>
          <div className="callout subtle"><Icon name="globe" size={20}/><p><strong>Public artifacts only.</strong> Policy documents, audit records and observable enforcement — not inferred intent.</p></div>
        </>}

        {step === 1 && <>
          <p className="step-intro">Answer all five questions. Open a question to read its full description and attach public evidence.</p>
          <div className="question-progress"><span>{input.answers.filter(answer => answer.value !== null).length} of 5 answered</span><span className="progress-track" aria-hidden="true">{input.answers.map((answer, index) => <i key={index} className={answer.value !== null ? 'filled' : ''}/>)}</span></div>
          {questions.map((question, index) => <AnswerCard key={question.code} code={question.code} title={question.title} description={`${question.description} ${question.examples}`} answer={input.answers[index]} onChange={answer => updateAnswer(index, answer)} open={activeQuestion === index} onToggle={() => setActiveQuestion(activeQuestion === index ? -1 : index)} cutoff={input.cutoff} invalid={!!errorFor(`q-${question.code}-yes`)}>
            {index === 3 && input.version === '1.1' && <div className="b4-record">
              <h5><Icon name="users" size={18}/>Separate the actor from the event</h5>
              <div className="form-grid">
                <label className="field-label">Who refused or appealed<input className="text-input" value={input.b4.actor} onChange={event => update('b4', { ...input.b4, actor: event.target.value })} placeholder="Affected party or entity"/></label>
                <label className="field-label">Which action it would stop<input className="text-input" value={input.b4.action} onChange={event => update('b4', { ...input.b4, action: event.target.value })}/></label>
              </div>
              <label className="field-label">Procedure and documented result<input className="text-input" value={input.b4.procedure} onChange={event => update('b4', { ...input.b4, procedure: event.target.value })}/></label>
              <label className="field-label">Evidence basis<select className="text-input" value={input.b4.basis} onChange={event => update('b4', { ...input.b4, basis: event.target.value })}><option value="NOT_DEMONSTRATED">Not demonstrated</option><option value="TERMINAL_RULE">Binding terminal refusal or automatic stay</option><option value="RESOLVED_APPEALS">Complete resolved appeal set (50% relief or more)</option><option value="NO_PENALTY_EXIT">Binding no-penalty exit ends the action</option><option value="EXTERNAL_ORDER_ONLY">External order only (does not count as Yes)</option></select></label>
              {input.b4.basis === 'RESOLVED_APPEALS' && <ReliefFields {...input.b4} cutoff={input.cutoff} onChange={(key, value) => update('b4', { ...input.b4, [key]: value })}/>}
              <p className="field-hint">{b4Qualifies(input) ? 'A qualifying rule or outcome record is documented.' : 'An external order, or complying with it, does not show that an affected party’s refusal is terminal.'}</p>
            </div>}
          </AnswerCard>)}
          <div className="callout subtle"><Icon name="info" size={20}/><p>You can save incomplete evidence as a <strong>draft</strong>. Drafts get no badge. Under v1.1, a Yes without a qualifying source is scored as No and disclosed.</p></div>
        </>}

        {step === 2 && <>
          <p className="step-intro">Constraints must be demonstrated, not just described.</p>
          <div className={`vector-preview ${detected.phase === 'AMBIGUOUS' ? 'ambiguous' : ''}`} role="status"><Icon name={detected.phase === 'AMBIGUOUS' ? 'warning' : 'check-circle'} size={24}/><div><strong>{detected.phase === 'AMBIGUOUS' ? 'Your scored answers are ambiguous' : `Your scored answers match ${detected.phase}`}</strong><p>{detected.phase === 'AMBIGUOUS' ? 'All four checks, C1 to C4, must pass for NAB-Constrained. Otherwise the result stays unresolved.' : 'The Step 3.5 constraint checks are not needed for a complete match.'}</p></div></div>
          {detected.phase === 'AMBIGUOUS' && constraintQuestions.map((question, index) => <AnswerCard key={question.code} code={question.code} title={question.title} description={question.description} answer={input.constraints[index]} onChange={answer => updateAnswer(index, answer, true)} open={activeConstraint === index} onToggle={() => setActiveConstraint(activeConstraint === index ? -1 : index)} cutoff={input.cutoff} invalid={!!errorFor(`q-${question.code}-yes`)}>
            {index === 1 && input.version === '1.1' && <div className="b4-record">
              <label className="checkbox-label"><input type="checkbox" checked={input.c2.route} onChange={event => update('c2', { ...input.c2, route: event.target.checked })}/>A published, accessible appeal route with decision criteria</label>
              <label className="checkbox-label"><input type="checkbox" checked={input.c2.invoked} onChange={event => update('c2', { ...input.c2, invoked: event.target.checked })}/>Invoked cases with published, resolved outcomes</label>
              <ReliefFields {...input.c2} cutoff={input.cutoff} onChange={(key, value) => update('c2', { ...input.c2, [key]: value })}/>
            </div>}
          </AnswerCard>)}
          <details className="pdh-details">
            <summary><span><Icon name="shield" size={20}/>External constraint record (descriptive)</span><Icon name="down" size={18}/></summary>
            <div className="pdh-content">
              <p>Existence and use are separate. An unused (latent) authority earns no phase credit.</p>
              <label className="checkbox-label"><input type="checkbox" checked={input.external.exists} onChange={event => update('external', { ...input.external, exists: event.target.checked, exercised: event.target.checked ? input.external.exercised : false })}/>A public or legal artifact shows an external authority exists</label>
              <label className="checkbox-label"><input type="checkbox" checked={input.external.exercised} disabled={!input.external.exists} onChange={event => update('external', { ...input.external, exercised: event.target.checked })}/>The authority was used against this entity or decision</label>
              {input.external.exists && <div className="form-grid">
                <label className="field-label">Authority holder<input className="text-input" value={input.external.holder} onChange={event => update('external', { ...input.external, holder: event.target.value })}/></label>
                <label className="field-label">Scope or affected decision<input className="text-input" value={input.external.scope} onChange={event => update('external', { ...input.external, scope: event.target.value })}/></label>
                <label className="field-label">Public artifact URL<input className="text-input" type="url" value={input.external.source} onChange={event => update('external', { ...input.external, source: event.target.value })}/></label>
                <label className="field-label">Artifact date<input className="text-input" type="date" max={input.cutoff} value={input.external.date} onChange={event => update('external', { ...input.external, date: event.target.value })}/></label>
              </div>}
            </div>
          </details>
          {input.version === '1.1' && <details className="pdh-details">
            <summary><span><Icon name="timeline" size={20}/>Constraint decrement (temporal)</span><Icon name="down" size={18}/></summary>
            <div className="pdh-content">
              <label className="checkbox-label"><input type="checkbox" checked={input.decrement.enabled} onChange={event => update('decrement', { ...input.decrement, enabled: event.target.checked })}/>Primary texts show a binding obligation became explicitly nonbinding</label>
              {input.decrement.enabled && <>
                <div className="form-grid">
                  <label className="field-label">Old binding source URL<input className="text-input" type="url" value={input.decrement.oldSource} onChange={event => update('decrement', { ...input.decrement, oldSource: event.target.value })}/></label>
                  <label className="field-label">New nonbinding source URL<input className="text-input" type="url" value={input.decrement.newSource} onChange={event => update('decrement', { ...input.decrement, newSource: event.target.value })}/></label>
                  <label className="field-label">Old effective date<input className="text-input" type="date" max={input.cutoff} value={input.decrement.oldDate} onChange={event => update('decrement', { ...input.decrement, oldDate: event.target.value })}/></label>
                  <label className="field-label">New effective date<input className="text-input" type="date" max={input.cutoff} value={input.decrement.newDate} onChange={event => update('decrement', { ...input.decrement, newDate: event.target.value })}/></label>
                </div>
                <label className="field-label">Binding to discretionary wording<textarea className="text-input" rows={2} value={input.decrement.notes} onChange={event => update('decrement', { ...input.decrement, notes: event.target.value })}/></label>
                <p className="field-hint">This flag records drift. It does not change the answers or the phase on its own.</p>
              </>}
            </div>
          </details>}
          <div className="history-notice"><Icon name="clock" size={20}/><div><strong>{prior.length ? `${prior.length} earlier audit${prior.length > 1 ? 's' : ''} found` : 'A first point on the timeline'}</strong><p>{prior.length ? `Most recent: ${prior[prior.length - 1].phase}, ${formatDate(prior[prior.length - 1].cutoff)}. Transition rules need valid declarations at both points.` : 'Later audits with the same entity ID are linked automatically. Baseline examples are not used for timelines.'}</p></div></div>
        </>}

        {step === 3 && <>
          <p className="step-intro">Review the finding and evidence record before saving.</p>
          {!preview ? <div className="loading-state" role="status"><span className="spinner" aria-hidden="true"/>Applying the Ground-0 rules…</div> : <>
            <div className={`result-banner phase-${preview.phase.toLowerCase()}`}>
              <p className="eyebrow">Detected operational phase</p>
              <p className="result-phase">{preview.phase}</p>
              <p className="result-meta"><span>{preview.confidence === 'NONE' ? 'Evidence incomplete' : `${preview.confidence.charAt(0)}${preview.confidence.slice(1).toLowerCase()} confidence`}</span><span>Ground-0 v{preview.version}{preview.version === '1.1' ? ' (draft rules)' : ''}</span></p>
            </div>
            <p className="result-finding">{preview.finding}</p>
            {preview.provisionalBadge && <div className="badge-panel"><PhaseRing badge={preview.provisionalBadge}/><p className="badge-note">Segments colour in only when an answer has a dated public source. Formal badge status: <strong>{preview.badge}</strong>.</p></div>}
            <dl className="result-facts">
              <div><dt>Declaration status</dt><dd>{preview.pdh.status}</dd></div>
              <div><dt>Compliance</dt><dd>{preview.compliance}</dd></div>
              <div><dt>Badge</dt><dd>{preview.badge}</dd></div>
              <div><dt>Severity</dt><dd>{preview.severity.replace('_', ' ')}</dd></div>
            </dl>
            <h4 className="subsection-title">Scored answers</h4>
            <ul className="review-vector">{questions.map((question, index) => <li key={question.code}><span className="question-code">{question.code}</span><span>{question.short}</span><strong className={vector[index] ? 'positive' : ''}>{vector[index] ? 'Yes' : 'No'}</strong>{input.answers[index].value === true && !vector[index] && <span className="gap-tag">Yes not supported by a qualifying source</span>}</li>)}</ul>
            <p className="review-meta"><span><Icon name="calendar" size={16}/>Cutoff: {formatDate(preview.cutoff)}</span><span><Icon name="link" size={16}/>{preview.evidence.length} public artifact{preview.evidence.length !== 1 ? 's' : ''}</span></p>
            {preview.status === 'Draft' && <div className="callout amber"><Icon name="warning" size={20}/><p><strong>This will be saved as a draft.</strong> Evidence or provenance is incomplete, so confidence is None and no badge is issued. Saving does not verify the evidence.</p></div>}
          </>}
        </>}
        {error && <div className="callout danger" role="alert"><Icon name="warning" size={20}/><p>{error}</p></div>}
      </div>
    </div>
    <div className="modal-footer wizard-footer">
      <p className="footer-status">Step {step + 1} of 4 · Ground-0 v{input.version}</p>
      <div className="footer-actions">
        {step > 0 ? <button type="button" className="button secondary" onClick={back}>Back</button> : <button type="button" className="button secondary" onClick={onClose}>Cancel</button>}
        <button type="button" className="button primary" disabled={step === 3 && !preview} onClick={next}>{step === 3 ? <><Icon name="check" size={18}/>{preview?.status === 'Draft' ? 'Save draft' : 'Save audit'}</> : <>Continue<Icon name="arrow" size={18}/></>}</button>
      </div>
    </div>
  </Modal>;
}
