import { useId } from 'react';
import type { ProvisionalBadge } from '../lib/badge';

const RADIUS = 40;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
const GAP = 5;
const SEGMENT = CIRCUMFERENCE / 5 - GAP;

/**
 * The provisional badge: five segments, one per question, coloured in as
 * evidence arrives. Authority segments use a hatch pattern as well as a colour
 * so the meaning does not depend on colour alone.
 */
export default function PhaseRing({ badge, size = 'large', caption = true }: { badge: ProvisionalBadge; size?: 'large' | 'compact'; caption?: boolean }) {
  const id = useId().replace(/:/g, '');
  const dimension = size === 'compact' ? 30 : 128;
  return <div className={`phase-ring ${size}`}>
    <svg viewBox="0 0 100 100" width={dimension} height={dimension} role="img" aria-label={badge.summary} focusable="false">
      <defs>
        <pattern id={`hatch-${id}`} patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
          <rect width="6" height="6" className="ring-hatch-bg"/>
          <line x1="0" y1="0" x2="0" y2="6" className="ring-hatch-line"/>
        </pattern>
      </defs>
      {badge.segments.map((segment, index) => <circle key={segment.code} cx="50" cy="50" r={RADIUS} fill="none" className={`ring-segment ${segment.state}`} strokeWidth={size === 'compact' ? 16 : 13} strokeDasharray={`${SEGMENT} ${CIRCUMFERENCE - SEGMENT}`} transform={`rotate(${-90 + index * 72} 50 50)`} stroke={segment.state === 'authority' ? `url(#hatch-${id})` : undefined}/>)}
      {size === 'large' && <>
        <text x="50" y="47" textAnchor="middle" className="ring-count">{badge.filled}<tspan className="ring-count-total">/5</tspan></text>
        <text x="50" y="62" textAnchor="middle" className="ring-label">coloured in</text>
      </>}
    </svg>
    {caption && size === 'large' && <div className="ring-caption">
      <p className="ring-title">Provisional badge <span className="ring-presumption">Presumes {badge.presumption}</span></p>
      <ul className="ring-segments" aria-hidden="true">{badge.segments.map(segment => <li key={segment.code} className={segment.state}><span className="ring-swatch"/><span>{segment.code}</span><span className="ring-segment-state">{segment.state === 'blank' ? 'blank' : segment.state === 'custodial' ? 'consistent' : 'proven wrong'}</span></li>)}</ul>
      <ul className="ring-legend" aria-hidden="true"><li><span className="ring-swatch custodial"/>Consistent with CWO</li><li><span className="ring-swatch authority"/>Authority shown</li><li><span className="ring-swatch blank"/>No evidence yet</li></ul>
    </div>}
  </div>;
}
