import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import Icon from './components/Icon';
import Orbit from './components/Orbit';
import Modal from './components/Modal';
import AuditWizard from './components/AuditWizard';
import AutoAudit from './components/AutoAudit';
import AuditTable from './components/AuditTable';
import Specification from './components/Specification';
import LogicPage from './components/LogicPage';
import { AccessibilityDialog, AccessibilityPage } from './components/AccessibilitySettings';
import { AddEvidence, AuditDetails, PhaseDetails } from './components/Dialogs';
import { PhaseBadge, VoiceButton, entityIcon, plainPhase, useDismiss, type DismissReason } from './components/ui';
import { baselineAudits, downloadFile, formatDate, phaseDefinitions, type AuditRecord, type Evidence, type Phase, type Version } from './lib/engine';
import { announce, applyPrefs, loadPrefs, savePrefs, watchEnvironment, type A11yPrefs, type LayoutMode } from './lib/a11y';

type Page = 'overview' | 'audits' | 'evidence' | 'temporal' | 'phases' | 'algorithm' | 'specifications' | 'accessibility';
type Group = 'workspace' | 'framework' | 'support';
const pages: { id: Page; title: string; icon: string; group: Group }[] = [
  { id: 'overview', title: 'Overview', icon: 'grid', group: 'workspace' },
  { id: 'audits', title: 'Phase audits', icon: 'clipboard', group: 'workspace' },
  { id: 'evidence', title: 'Evidence library', icon: 'folder', group: 'workspace' },
  { id: 'temporal', title: 'Temporal ledger', icon: 'timeline', group: 'workspace' },
  { id: 'phases', title: 'Phase reference', icon: 'layers', group: 'framework' },
  { id: 'algorithm', title: 'Algorithm & logic', icon: 'flow', group: 'framework' },
  { id: 'specifications', title: 'Specifications', icon: 'file', group: 'framework' },
  { id: 'accessibility', title: 'Accessibility', icon: 'accessibility', group: 'support' },
];
const groupLabels: Record<Group, string> = { workspace: 'Workspace', framework: 'The framework', support: 'Support' };
const baseline = baselineAudits();
const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform);

function readStorage<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback; } catch { return fallback; }
}

function BrandMark() {
  return <svg width="38" height="38" viewBox="0 0 40 40" fill="none" aria-hidden="true" focusable="false"><circle cx="19" cy="21" r="13" stroke="currentColor" strokeWidth="1.6"/><ellipse cx="19" cy="21" rx="18" ry="7" transform="rotate(-35 19 21)" stroke="currentColor" strokeWidth="1.6"/><path d="m19 14 6 3.5v7L19 28l-6-3.5v-7Z" fill="currentColor"/><path d="m13 17.5 6 3.5 6-3.5M19 21v7" stroke="#EFF1E8" strokeWidth=".8"/><circle cx="30" cy="9" r="3" fill="#A87524" stroke="#F9FAF6" strokeWidth="1.5"/></svg>;
}

export default function App() {
  const [page, setPage] = useState<Page>('overview');
  const [users, setUsers] = useState<AuditRecord[]>(() => readStorage('ground-0-audits-v1', []));
  const [extraEvidence, setExtraEvidence] = useState<Evidence[]>(() => readStorage('ground-0-evidence-v1', []));
  const [version, setVersion] = useState<Version>('1.0');
  const [prefs, setPrefs] = useState<A11yPrefs>(loadPrefs);
  const [layout, setLayout] = useState<LayoutMode>(() => (document.documentElement.dataset.layout as LayoutMode) || 'desktop');
  const [wizardOpen, setWizardOpen] = useState(false);
  const [editingAudit, setEditingAudit] = useState<AuditRecord | null>(null);
  const [autoQuery, setAutoQuery] = useState<string | null>(null);
  const [selectedAudit, setSelectedAudit] = useState<AuditRecord | null>(null);
  const [selectedPhase, setSelectedPhase] = useState<Phase | null>(null);
  const [addEvidence, setAddEvidence] = useState(false);
  const [a11yOpen, setA11yOpen] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [commandSearch, setCommandSearch] = useState('');
  const [headerPopover, setHeaderPopover] = useState<'notifications' | 'profile' | null>(null);
  const [toast, setToast] = useState<{ message: string; key: number } | null>(null);
  const [toastPaused, setToastPaused] = useState(false);
  const [auditView, setAuditView] = useState<'all' | 'attention' | 'high'>('all');
  const [evidenceSearch, setEvidenceSearch] = useState('');
  const [evidenceTab, setEvidenceTab] = useState<'all' | 'public' | 'framework'>('all');
  const [quickQuery, setQuickQuery] = useState('');
  const [quickError, setQuickError] = useState('');
  const menuButton = useRef<HTMLButtonElement>(null);
  const sidebar = useRef<HTMLElement>(null);
  const notificationsAnchor = useRef<HTMLDivElement>(null);
  const profileAnchor = useRef<HTMLDivElement>(null);
  const prefsRef = useRef(prefs);
  const previousPage = useRef<Page>(page);
  prefsRef.current = prefs;

  const audits = useMemo(() => [...users].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).concat(baseline), [users]);
  const allEvidence = useMemo(() => [...extraEvidence, ...users.flatMap(audit => audit.evidence)].filter((item, index, list) => list.findIndex(other => other.id === item.id) === index), [extraEvidence, users]);
  const transitions = users.filter(audit => audit.transition).sort((a, b) => b.cutoff.localeCompare(a.cutoff));
  const activePage = pages.find(item => item.id === page)!;
  const compact = layout !== 'desktop';
  const otherModal = wizardOpen || !!selectedAudit || !!selectedPhase || addEvidence || a11yOpen || autoQuery !== null;
  const modalOpen = otherModal || commandOpen;
  const otherModalRef = useRef(otherModal);
  otherModalRef.current = otherModal;
  const wizardHistory = useMemo(() => editingAudit ? audits.filter(audit => audit.id !== editingAudit.id) : audits, [audits, editingAudit]);

  const notify = useCallback((message: string) => { setToast({ message, key: Date.now() }); announce(message); }, []);
  const closeWizard = useCallback(() => { setWizardOpen(false); setEditingAudit(null); }, []);
  const closeAudit = useCallback(() => setSelectedAudit(null), []);
  const closePhase = useCallback(() => setSelectedPhase(null), []);
  const closeEvidence = useCallback(() => setAddEvidence(false), []);
  const closeCommand = useCallback(() => { setCommandOpen(false); setCommandSearch(''); }, []);
  const closeAccessibility = useCallback(() => setA11yOpen(false), []);
  const closeAuto = useCallback(() => setAutoQuery(null), []);
  const closeHeader = useCallback((reason: DismissReason) => {
    setHeaderPopover(current => { if (reason === 'escape' && current) window.setTimeout(() => document.getElementById(`${current}-trigger`)?.focus(), 0); return null; });
  }, []);
  useDismiss(notificationsAnchor, headerPopover === 'notifications', closeHeader);
  useDismiss(profileAnchor, headerPopover === 'profile', closeHeader);

  useEffect(() => { applyPrefs(prefs); savePrefs(prefs); }, [prefs]);
  useEffect(() => watchEnvironment(() => prefsRef.current), []);
  useEffect(() => {
    const sync = () => setLayout((document.documentElement.dataset.layout as LayoutMode) || 'desktop');
    window.addEventListener('g0-layout', sync);
    sync();
    return () => window.removeEventListener('g0-layout', sync);
  }, []);
  useEffect(() => { if (!compact) setMobileNav(false); }, [compact]);
  useEffect(() => { if (mobileNav) sidebar.current?.querySelector<HTMLElement>('.sidebar-close')?.focus(); }, [mobileNav]);
  useEffect(() => { try { localStorage.setItem('ground-0-audits-v1', JSON.stringify(users)); } catch { notify('Browser storage is unavailable or full. Export your audits to keep a copy.'); } }, [users, notify]);
  useEffect(() => { try { localStorage.setItem('ground-0-evidence-v1', JSON.stringify(extraEvidence)); } catch { notify('Browser storage is unavailable or full. Export your evidence to keep a copy.'); } }, [extraEvidence, notify]);
  // Visual confirmations wait until dialogs close so they never cover dialog actions; screen readers hear them immediately.
  useEffect(() => { if (!toast || toastPaused || modalOpen) return; const timer = window.setTimeout(() => setToast(null), 9000); return () => window.clearTimeout(timer); }, [toast, toastPaused, modalOpen]);
  // A confirmation never hides the focused control: it closes when focus lands on anything beneath it.
  useEffect(() => {
    if (!toast || modalOpen) return;
    const onFocus = (event: FocusEvent) => {
      const toastElement = document.querySelector('.toast');
      const target = event.target;
      if (!toastElement || !(target instanceof Element) || toastElement.contains(target)) return;
      const a = toastElement.getBoundingClientRect();
      const b = target.getBoundingClientRect();
      if (a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top) setToast(null);
    };
    document.addEventListener('focusin', onFocus);
    return () => document.removeEventListener('focusin', onFocus);
  }, [toast, modalOpen]);
  useEffect(() => {
    document.title = page === 'overview' ? 'Ground-0 — Phase Intelligence' : `${activePage.title} — Ground-0`;
    if (previousPage.current === page) return;
    previousPage.current = page;
    window.scrollTo({ top: 0 });
    document.getElementById('main-content')?.focus({ preventScroll: true });
    announce(`${activePage.title} page`);
  }, [page]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setCommandOpen(open => open ? false : !otherModalRef.current);
      }
      if (event.key === 'Escape' && !otherModalRef.current) setToast(null);
      if (event.key === 'Escape' && mobileNav && !otherModalRef.current) { setMobileNav(false); menuButton.current?.focus(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [mobileNav]);

  const navigate = (next: Page) => {
    const wasMobile = mobileNav;
    setPage(next);
    setMobileNav(false);
    setHeaderPopover(null);
    if (next === 'audits') setAuditView('all');
    if (wasMobile && next === page) menuButton.current?.focus();
  };
  const goSpecs = (next: Version = version) => { setVersion(next); navigate('specifications'); };
  const openAudits = (view: 'all' | 'attention' | 'high' = 'all') => { navigate('audits'); setAuditView(view); };
  const openManual = () => { setEditingAudit(null); setHeaderPopover(null); setWizardOpen(true); };
  const startAuto = (query = '') => { setHeaderPopover(null); setMobileNav(false); setAutoQuery(query); };
  const closeNav = () => { setMobileNav(false); menuButton.current?.focus(); };
  const submitQuick = (event: FormEvent) => {
    event.preventDefault();
    if (quickQuery.trim().length < 2) { setQuickError('Enter an organization name, at least two characters.'); document.getElementById('quick-org')?.focus(); return; }
    setQuickError('');
    startAuto(quickQuery.trim());
  };
  const saveAudit = (audit: AuditRecord) => {
    const source = editingAudit;
    let saved: AuditRecord = source ? { ...audit, id: source.id } : audit;
    saved = source?.method === 'automatic'
      ? { ...saved, method: 'manual', automation: source.automation ? { ...source.automation, reviewed: true } : undefined, report: { ...saved.report, Audit_Method: 'MANUAL_REVIEW_OF_AUTOMATED_SCREENING', Human_Review: 'COMPLETED', Automation_Origin: { Rule_Set: source.automation?.ruleSet, Sources: source.automation?.sources } } }
      : { ...saved, method: 'manual', automation: source?.automation };
    setUsers(current => [saved, ...current.filter(item => item.id !== saved.id)]);
    setEditingAudit(null);
    setWizardOpen(false);
    setSelectedAudit(saved);
    notify(saved.status === 'Draft' ? 'Draft saved. No phase badge has been issued.' : source?.method === 'automatic' ? 'Review saved. The record is now marked as checked by a person.' : 'Audit saved. Your traceable record is ready to export.');
  };
  const saveAutomatic = (record: AuditRecord) => {
    setUsers(current => [record, ...current.filter(item => item.id !== record.id)]);
    setAutoQuery(null);
    setSelectedAudit(record);
    notify(`Automated screening for ${record.name} saved. Review it before relying on it.`);
  };
  const reviewAutomatic = (record: AuditRecord) => { setAutoQuery(null); setEditingAudit(record); setVersion(record.version); setWizardOpen(true); };
  const resumeAudit = () => { if (!selectedAudit) return; setEditingAudit(selectedAudit); setVersion(selectedAudit.version); setSelectedAudit(null); setWizardOpen(true); };

  const stats = [
    { label: 'Total audits', value: audits.length, icon: 'clipboard', color: 'sage', note: 'Across this workspace', action: () => openAudits() },
    { label: 'High confidence', value: audits.filter(audit => audit.confidence === 'HIGH').length, icon: 'target', color: 'sage', note: 'Complete phase patterns', action: () => openAudits('high') },
    { label: 'Needs review', value: audits.filter(audit => audit.status !== 'Complete').length, icon: 'warning', color: 'amber', note: 'Drafts and automated screenings', action: () => openAudits('attention') },
    { label: 'Valid declarations', value: users.filter(audit => audit.pdh.status === 'VALID').length, icon: 'shield', color: 'blue', note: 'Signed, fresh and consistent', action: () => { openAudits(); notify('A valid declaration needs all 11 fields and a verified signature bound to its origin.'); } },
  ];
  const filteredEvidence = allEvidence.filter(item => `${item.title} ${item.claim} ${item.entity} ${item.codes.join(' ')}`.toLowerCase().includes(evidenceSearch.toLowerCase()));
  const filteredSources = (['1.0', '1.1'] as Version[]).filter(item => `ground-0 phase detection algorithm ${item} ${item === '1.0' ? 'normative final' : 'amendment draft'}`.includes(evidenceSearch.toLowerCase()));
  const commandText = commandSearch.toLowerCase();
  const commandActions = [
    { label: 'Start an automatic audit', icon: 'sparkle', run: () => { closeCommand(); startAuto(''); } },
    { label: 'Start a manual audit', icon: 'clipboard', run: () => { closeCommand(); openManual(); } },
    { label: 'Accessibility settings', icon: 'accessibility', run: () => { closeCommand(); setA11yOpen(true); } },
  ].filter(item => item.label.toLowerCase().includes(commandText));
  const commandPages = pages.filter(item => item.title.toLowerCase().includes(commandText));
  const commandAudits = audits.filter(audit => `${audit.name} ${audit.identifier} ${audit.phase}`.toLowerCase().includes(commandText)).slice(0, 6);

  const HeadingActions = () => <div className="heading-actions"><button type="button" className="button secondary" onClick={openManual}><Icon name="clipboard" size={18}/>Manual audit</button><button type="button" className="button primary" onClick={() => startAuto('')}><Icon name="sparkle" size={18}/>Automatic audit</button></div>;

  return <>
    <a className="skip-link" href="#main-content" onClick={event => { event.preventDefault(); document.getElementById('main-content')?.focus(); }}>Skip to main content</a>
    <div className="app-frame" inert={modalOpen || undefined}>
      {compact && mobileNav && <div className="mobile-backdrop" aria-hidden="true" onClick={closeNav}/>}
      <aside ref={sidebar} className={`sidebar ${mobileNav ? 'open' : ''}`} aria-label="Main menu" inert={(compact && !mobileNav) || undefined}>
        <div className="sidebar-top">
          <button type="button" className="brand" onClick={() => navigate('overview')} aria-label="Ground-0 Phase Intelligence, go to overview"><BrandMark/><span className="brand-text"><strong>GROUND–0</strong><small>Phase intelligence</small></span></button>
          <button type="button" className="icon-button sidebar-close" onClick={closeNav} aria-label="Close menu"><Icon name="close"/></button>
        </div>
        <p className="workspace-label"><span className="workspace-dot" aria-hidden="true"/>Audit workspace</p>
        <nav aria-label="Main">{(['workspace', 'framework', 'support'] as Group[]).map(group => <div className="nav-group" key={group}>
          <h2 className="nav-group-label" id={`nav-${group}`}>{groupLabels[group]}</h2>
          <ul className="nav-list" aria-labelledby={`nav-${group}`}>{pages.filter(item => item.group === group).map(item => <li key={item.id}>
            <button type="button" className="nav-link" onClick={() => navigate(item.id)} aria-current={page === item.id ? 'page' : undefined}>
              <Icon name={item.icon} size={20}/><span className="nav-text">{item.title}</span>
              {item.id === 'audits' && <span className="nav-count">{audits.length}<span className="sr-only"> audits</span></span>}
              {item.id === 'specifications' && <span className="nav-count">v1.0</span>}
            </button>
          </li>)}</ul>
        </div>)}</nav>
        <div className="sidebar-bottom">
          <div className="baseline-card"><strong><Icon name="shield" size={18}/>Grounded in a standard</strong><p>v1.0 is the normative baseline.</p><button type="button" className="text-button" onClick={() => goSpecs('1.1')}>Read the v1.1 amendment draft</button></div>
          <div className="author-profile"><span className="avatar" aria-hidden="true">HP</span><span className="author-text"><strong>Harshal P. Patel</strong><span>Framework author</span></span></div>
          <p className="sidebar-footnote"><Icon name="lock" size={14}/>Private, local workspace</p>
        </div>
      </aside>

      <div className="main-shell" inert={(compact && mobileNav) || undefined}>
        <header className="topbar">
          <div className="topbar-left">
            <button ref={menuButton} type="button" className="icon-button mobile-menu" aria-label="Open menu" aria-expanded={mobileNav} onClick={() => setMobileNav(true)}><Icon name="menu"/></button>
            <nav className="breadcrumb" aria-label="Breadcrumb"><ol><li>Workspace</li><li aria-current="page">{activePage.title}</li></ol></nav>
          </div>
          <div className="topbar-right">
            <button type="button" className="global-search" onClick={() => setCommandOpen(true)} aria-keyshortcuts="Control+K Meta+K" aria-label="Search the workspace"><Icon name="search" size={18}/><span className="global-search-label">Search</span><kbd>{isMac ? '⌘ K' : 'Ctrl K'}</kbd></button>
            <button type="button" className="button secondary small a11y-button" onClick={() => setA11yOpen(true)} aria-label="Accessibility settings"><Icon name="accessibility" size={20}/><span className="a11y-button-label">Accessibility</span></button>
            <div className="popover-anchor" ref={notificationsAnchor}>
              <button id="notifications-trigger" type="button" className="icon-button notification-button" aria-label="Workspace updates, 2 items" aria-expanded={headerPopover === 'notifications'} aria-controls="notifications-popover" onClick={() => setHeaderPopover(current => current === 'notifications' ? null : 'notifications')}><Icon name="bell" size={20}/><i className="notification-dot" aria-hidden="true"/></button>
              {headerPopover === 'notifications' && <div id="notifications-popover" className="popover notification-popover" role="group" aria-label="Workspace updates">
                <h2 className="popover-title">Workspace updates</h2>
                <button type="button" className="update-item" onClick={() => goSpecs('1.0')}><span className="update-icon sage" aria-hidden="true"><Icon name="shield" size={18}/></span><span><strong>v1.0 is your baseline</strong><small>Finalized normative source · Sep 12, 2026</small></span></button>
                <button type="button" className="update-item" onClick={() => goSpecs('1.1')}><span className="update-icon amber" aria-hidden="true"><Icon name="file" size={18}/></span><span><strong>Five proposed clarifications</strong><small>v1.1 remains an unratified draft</small></span></button>
                <p className="popover-note">Source-reported baseline cases are not independently verified.</p>
              </div>}
            </div>
            <div className="popover-anchor" ref={profileAnchor}>
              <button id="profile-trigger" type="button" className="avatar topbar-avatar" aria-label="About the framework author" aria-expanded={headerPopover === 'profile'} aria-controls="profile-popover" onClick={() => setHeaderPopover(current => current === 'profile' ? null : 'profile')}>HP</button>
              {headerPopover === 'profile' && <div id="profile-popover" className="popover profile-popover" role="group" aria-label="About the framework author">
                <div className="profile-head"><span className="avatar" aria-hidden="true">HP</span><span><strong>Harshal Priyavadan Patel</strong><small>Source framework author · A44674928</small></span></div>
                <p>Harshal’s Systems (AGS++)<br/>Orb Communicator Model</p>
                <p className="profile-origin">Center Origin 0•000•000•0000</p>
                <p className="popover-note"><Icon name="lock" size={16}/>Your audits are stored in this browser. No account or server is connected.</p>
              </div>}
            </div>
          </div>
        </header>

        <main id="main-content" className="main-content" tabIndex={-1}>
          {page === 'overview' && <>
            <div className="page-heading">
              <div><p className="eyebrow"><span className="live-dot" aria-hidden="true"/>Your accountability workspace</p><h1>Clarity, from the ground up.</h1><p>Observe behavior. Identify the phase. Make accountability visible.</p></div>
              <HeadingActions/>
            </div>
            <div className="feature-grid">
              <section className="hero-card" aria-labelledby="quick-title">
                <div className="hero-copy">
                  <p className="hero-eyebrow"><Icon name="sparkle" size={16}/>Automatic audit</p>
                  <h2 id="quick-title">Audit any organization by name.</h2>
                  <p className="hero-text">Type or say a name. Ground-0 searches court, legislative, news and archive records, dates every artifact, applies the rules, and shows every quote it used.</p>
                  <form className="quick-form" onSubmit={submitQuick} noValidate>
                    <label className="quick-label" htmlFor="quick-org">Organization name</label>
                    {quickError && <p className="field-error" id="quick-org-error"><Icon name="warning" size={16}/>{quickError}</p>}
                    <div className="quick-input-row">
                      <input id="quick-org" className="text-input" type="text" value={quickQuery} onChange={event => setQuickQuery(event.target.value)} autoComplete="organization" spellCheck={false} placeholder="e.g. World Health Organization" aria-invalid={!!quickError || undefined} aria-describedby={quickError ? 'quick-org-hint quick-org-error' : 'quick-org-hint'}/>
                      <VoiceButton onResult={text => { setQuickQuery(text); setQuickError(''); }}/>
                      <button type="submit" className="button hero-button">Run automatic audit<Icon name="arrow" size={18}/></button>
                    </div>
                    <p className="quick-hint" id="quick-org-hint">An automated screening — you can review every answer before relying on it.</p>
                  </form>
                  <button type="button" className="hero-link" onClick={openManual}>Prefer to answer the questions yourself? Start a manual audit<Icon name="arrow" size={16}/></button>
                </div>
                <Orbit/>
              </section>
              <section className="panel paths-card" aria-labelledby="paths-title">
                <p className="eyebrow">Choose your path</p>
                <h2 id="paths-title" className="panel-title">Two ways to audit</h2>
                <ul className="path-list">
                  <li><button type="button" className="path-option" onClick={() => document.getElementById('quick-org')?.focus()}><span className="path-icon" aria-hidden="true"><Icon name="sparkle" size={20}/></span><span className="path-text"><strong>Automatic</strong><span>Enter a name. Twelve public record sources are searched and scored for you.</span></span></button></li>
                  <li><button type="button" className="path-option" onClick={openManual}><span className="path-icon" aria-hidden="true"><Icon name="clipboard" size={20}/></span><span className="path-text"><strong>Manual</strong><span>Answer five Yes/No questions with your own public sources.</span></span></button></li>
                  <li><button type="button" className="path-option" onClick={() => setA11yOpen(true)}><span className="path-icon" aria-hidden="true"><Icon name="accessibility" size={20}/></span><span className="path-text"><strong>Make it comfortable</strong><span>Larger text, high contrast, a readable font and read-aloud.</span></span></button></li>
                </ul>
                <p className="card-footnote"><Icon name="check-circle" size={16}/>Both paths use the same Ground-0 rules.</p>
              </section>
            </div>
            <ul className="stats-grid" aria-label="Workspace summary">{stats.map(stat => <li key={stat.label}><button type="button" className="stat-card" onClick={stat.action}>
              <span className="stat-card-top"><span>{stat.label}</span><span className={`stat-icon ${stat.color}`} aria-hidden="true"><Icon name={stat.icon} size={18}/></span></span>
              <span className="stat-value">{stat.value}</span>
              <span className="stat-note">{stat.note}<Icon name="arrow" size={14}/></span>
            </button></li>)}</ul>
            <AuditTable audits={audits} overview onSelect={setSelectedAudit} onViewAll={() => openAudits()}/>
            <p className="baseline-disclaimer"><Icon name="info" size={16}/>Includes six source-reported v1.0 baseline cases, which are not independently verified audits.</p>
            <section className="phase-spectrum" aria-labelledby="spectrum-title">
              <div className="section-heading"><div><h2 id="spectrum-title">The phase spectrum</h2><p>Four phases, each with a plain-language meaning.</p></div><button type="button" className="text-button" onClick={() => navigate('phases')}>Explore phase definitions<Icon name="arrow" size={16}/></button></div>
              <ul className="phase-mini-grid">{phaseDefinitions.map(definition => <li key={definition.phase}><button type="button" className={`phase-mini ${definition.color}`} onClick={() => setSelectedPhase(definition.phase)}>
                <span className="phase-mini-icon" aria-hidden="true"><Icon name={definition.icon} size={22}/></span>
                <span className="phase-mini-name">{definition.phase}</span>
                <span className="phase-mini-category">{definition.category}</span>
                <span className="phase-mini-plain">{plainPhase[definition.phase]}</span>
              </button></li>)}</ul>
            </section>
          </>}

          {page === 'audits' && <>
            <div className="page-heading"><div><p className="eyebrow">The audit register</p><h1>Every audit leaves a trail.</h1><p>Claims, behavior and evidence — kept together, never conflated.</p></div><HeadingActions/></div>
            <ul className="register-summary" aria-label="Register summary"><li><strong>{audits.length}</strong> total records</li><li><strong>{users.length}</strong> saved in this browser</li><li><strong>{users.filter(audit => audit.method === 'automatic').length}</strong> automated screenings</li><li><strong>6</strong> source baseline cases</li></ul>
            <AuditTable key={auditView} audits={audits} onSelect={setSelectedAudit} onViewAll={() => openAudits()} initialAttention={auditView === 'attention'} initialHigh={auditView === 'high'}/>
            <div className="callout subtle page-note"><Icon name="info" size={20}/><p>Baseline phases and confidence come from Section XII of the v1.0 manuscript. Implicit declarations are not valid headers. Only new, documented assessments are scored by this workspace. <button type="button" className="text-button" onClick={() => downloadFile('ground-0-all-audits.json', JSON.stringify(audits.map(audit => audit.report), null, 2))}>Export the full register</button></p></div>
          </>}

          {page === 'evidence' && <>
            <div className="page-heading"><div><p className="eyebrow">The public record</p><h1>Evidence, not inference.</h1><p>Keep the artifacts behind every answer.</p></div><div className="heading-actions"><button type="button" className="button secondary" onClick={() => { downloadFile('ground-0-evidence-library.json', JSON.stringify(allEvidence, null, 2)); notify('Evidence library exported.'); }}><Icon name="download" size={18}/>Export library</button><button type="button" className="button primary" onClick={() => setAddEvidence(true)}><Icon name="plus" size={18}/>Add artifact</button></div></div>
            <ul className="evidence-stats" aria-label="Evidence summary"><li><Icon name="link" size={22}/><strong>{allEvidence.length}</strong><span>Public artifacts</span></li><li><Icon name="file" size={22}/><strong>2</strong><span>Framework sources</span></li><li><Icon name="clipboard" size={22}/><strong>{users.filter(audit => audit.evidence.length).length}</strong><span>Audits with evidence</span></li></ul>
            <div className="library-toolbar">
              <div className="segmented" role="group" aria-label="Show">{([['all', 'All'], ['public', 'Public artifacts'], ['framework', 'Framework sources']] as const).map(([id, label]) => <button type="button" key={id} aria-pressed={evidenceTab === id} onClick={() => setEvidenceTab(id)}>{label}</button>)}</div>
              <label className="table-search library-search"><Icon name="search" size={18}/><span className="sr-only">Search the evidence library</span><input type="search" value={evidenceSearch} onChange={event => setEvidenceSearch(event.target.value)} placeholder="Search titles, claims or entities"/></label>
            </div>
            {evidenceTab !== 'public' && filteredSources.length > 0 && <section aria-labelledby="framework-sources-title">
              <div className="small-section-heading"><h2 id="framework-sources-title">Framework source documents</h2><span>Provided sources · not scored evidence</span></div>
              <ul className="source-document-grid">{filteredSources.map(item => <li key={item}><button type="button" className={`source-document ${item === '1.1' ? 'amendment-document' : ''}`} onClick={() => goSpecs(item)}>
                <span className="source-document-top"><span className="source-document-icon" aria-hidden="true"><Icon name="file" size={26}/></span><span className={`source-status ${item === '1.0' ? 'normative' : 'draft'}`}>{item === '1.0' ? 'Normative' : 'Amendment draft'}</span></span>
                <span className="source-document-title">Ground-0 Phase Detection Algorithm v{item}</span>
                <span className="source-document-text">{item === '1.0' ? 'The finalized baseline, as supplied by the source author.' : 'Five proposed clarifications for reproducible coding and reporting.'}</span>
                <span className="source-document-footer"><span>{item === '1.0' ? 'Finalized Sep 12, 2026' : 'Pending author adoption'}</span><span>Read the source<Icon name="arrow" size={16}/></span></span>
              </button></li>)}</ul>
            </section>}
            {evidenceTab !== 'framework' && <section aria-labelledby="artifacts-title">
              <div className="small-section-heading"><h2 id="artifacts-title">Public evidence artifacts</h2><span role="status">{filteredEvidence.length} artifact{filteredEvidence.length !== 1 ? 's' : ''}</span></div>
              {filteredEvidence.length ? <ul className="artifact-grid">{filteredEvidence.map(item => <li className="artifact-card" key={item.id}>
                <div className="artifact-top"><span className="source-icon" aria-hidden="true"><Icon name="link" size={18}/></span><span className="artifact-entity">{item.entity}</span>{extraEvidence.some(extra => extra.id === item.id) && <button type="button" className="icon-button small" aria-label={`Remove ${item.title}`} onClick={() => { if (window.confirm('Remove this unscored library artifact?')) { setExtraEvidence(current => current.filter(extra => extra.id !== item.id)); notify('Artifact removed from the library.'); } }}><Icon name="close" size={16}/></button>}</div>
                <h3>{item.title}</h3><p>{item.claim}</p>
                <a href={item.url} target="_blank" rel="noreferrer">{(() => { try { return new URL(item.url).hostname; } catch { return 'Public source'; } })()}<Icon name="arrow-up" size={14}/><span className="sr-only"> (opens in a new tab)</span></a>
                <p className="artifact-codes">{item.codes.map(code => <span key={code}>{code}</span>)}{extraEvidence.some(extra => extra.id === item.id) && <span className="unscored-tag">Unscored</span>}</p>
                <p className="artifact-footer"><span>Published {formatDate(item.published)}</span><span>Retrieved {formatDate(item.retrieved)}</span></p>
              </li>)}</ul> : <div className="empty-state panel"><span className="empty-icon" aria-hidden="true"><Icon name={evidenceSearch ? 'search' : 'folder'} size={32}/></span><h3>{evidenceSearch ? 'No matching artifacts' : 'Build a record worth replicating'}</h3><p>{evidenceSearch ? 'Try a different title, entity or question code.' : 'Add a public artifact, run an automatic audit, or cite sources in a manual audit. The library grows with every documented assessment.'}</p><button type="button" className="button secondary" onClick={() => evidenceSearch ? setEvidenceSearch('') : setAddEvidence(true)}>{evidenceSearch ? 'Clear the search' : 'Add your first artifact'}</button></div>}
            </section>}
          </>}

          {page === 'temporal' && <>
            <div className="page-heading"><div><p className="eyebrow">The temporal record</p><h1>Accountability, over time.</h1><p>A declaration is a point. A transition reveals a pattern.</p></div><HeadingActions/></div>
            <ul className="transition-rule-grid" aria-label="Transition rules">
              <li className="transition-rule reversible"><p className="eyebrow">Reversible</p><p className="transition-phases"><PhaseBadge phase="NAB"/><span aria-hidden="true">↔</span><span className="sr-only">to and from</span><PhaseBadge phase="CWO"/></p><p>Needs a clear declaration of the destination phase.</p></li>
              <li className="transition-rule one-way"><p className="eyebrow">One-way escalation</p><p className="transition-phases"><span className="phase-badge sage">NAB or CWO</span><Icon name="arrow" size={18}/><span className="sr-only">to</span><PhaseBadge phase="GSRB"/></p><p>Every sovereignty assumption must be declared.</p></li>
              <li className="transition-rule forbidden"><p className="eyebrow">Forbidden reversion</p><p className="transition-phases"><PhaseBadge phase="GSRB"/><span aria-hidden="true">↛</span><span className="sr-only">cannot return to</span><span className="phase-badge sage">NAB or CWO</span></p><p>Except through complete structural collapse and rebuild.</p></li>
            </ul>
            <section className="panel temporal-panel" aria-labelledby="ledger-title">
              <div className="panel-heading"><div><h2 id="ledger-title">Transition ledger <span className="count-chip">{transitions.length}</span></h2><p>Assessments linked by the same entity identifier.</p></div><button type="button" className="button secondary small" disabled={!transitions.length} onClick={() => { downloadFile('ground-0-temporal-ledger.json', JSON.stringify(transitions.map(audit => audit.transition), null, 2)); notify('Temporal ledger exported.'); }}><Icon name="download" size={18}/>Export ledger</button></div>
              {transitions.length ? <ul className="transition-list">{transitions.map(audit => <li key={audit.id}><button type="button" className="transition-entry" onClick={() => setSelectedAudit(audit)}>
                <span className="transition-dot" aria-hidden="true"/>
                <span className="transition-name"><strong>{audit.name}</strong><span>{formatDate(audit.transition!.fromDate)} to {formatDate(audit.transition!.toDate)}</span></span>
                <span className="transition-phases"><PhaseBadge phase={audit.transition!.from} compact/><Icon name="arrow" size={16}/><span className="sr-only">to</span><PhaseBadge phase={audit.transition!.to} compact/></span>
                <span className={`transition-status ${audit.transition!.status === 'FORBIDDEN' ? 'danger' : ''}`}>{audit.transition!.status.replace(/_/g, ' ')}</span>
              </button></li>)}</ul> : <div className="empty-state"><span className="empty-icon" aria-hidden="true"><Icon name="timeline" size={32}/></span><h3>A timeline needs more than one point</h3><p>Audit an entity, then audit it again later with the same identifier. Ground-0 links the records and checks the transition rules.</p><button type="button" className="button primary" onClick={() => startAuto('')}>{users.length ? 'Audit an entity again' : 'Create your first assessment'}<Icon name="arrow" size={18}/></button></div>}
            </section>
            <ul className="temporal-note-grid">{([['refresh', 'Oscillation', 'Rapid back-and-forth changes. The source defines no numeric window, so no automatic oscillation finding is made.'], ['arrow-up', 'Drift', 'Gradual authority escalation — or, in v1.1, a documented change from a binding constraint to a nonbinding goal.'], ['file', 'Rebranding', 'The declared phase changes while documented behavior stays the same.']] as const).map(([icon, title, text]) => <li className="panel note-card" key={title}><Icon name={icon} size={22}/><h2>{title}</h2><p>{text}</p></li>)}</ul>
          </>}

          {page === 'phases' && <>
            <div className="page-heading"><div><p className="eyebrow">The phase spectrum</p><h1>Four phases. One observable standard.</h1><p>A vocabulary for what a system does — not what it says it is.</p></div><button type="button" className="button secondary" onClick={() => navigate('algorithm')}>Explore the logic<Icon name="arrow" size={18}/></button></div>
            <ul className="phase-reference-grid">{phaseDefinitions.map(definition => <li className={`phase-reference-card ${definition.color}`} key={definition.phase}>
              <div className="phase-reference-head"><span className="phase-reference-icon" aria-hidden="true"><Icon name={definition.icon} size={28}/></span><p className="eyebrow">{definition.category}</p></div>
              <h2>{definition.phase}</h2><p className="phase-reference-name">{definition.name}</p>
              <p className="plain-meaning"><strong>In plain language:</strong> {plainPhase[definition.phase]}</p>
              <ul className="characteristic-list">{definition.characteristics.map(item => <li key={item}><Icon name="check" size={16}/>{item}</li>)}</ul>
              <div className="phase-reference-footer"><span>Framework badge: <span aria-hidden="true">{definition.symbol}</span><span className="sr-only">{definition.phase === 'CWO' ? 'water drop' : definition.phase === 'GSRB' ? 'gas cloud' : definition.phase === 'NAB' ? 'ice block' : 'ice block with plus'}</span></span><button type="button" className="text-button" onClick={() => setSelectedPhase(definition.phase)}>Inspect {definition.phase}<Icon name="arrow" size={16}/></button></div>
            </li>)}</ul>
            <div className="callout subtle page-note"><Icon name="info" size={20}/><p>These are the supplied framework’s operational categories, not legal or scientific determinations. A phase label does not by itself establish badge validity, compliance or the truth of submitted evidence.</p></div>
          </>}

          {page === 'algorithm' && <LogicPage version={version} setVersion={setVersion} onManual={openManual} onAuto={() => startAuto('')}/>}
          {page === 'specifications' && <Specification version={version} onVersionChange={setVersion} onToast={notify}/>}
          {page === 'accessibility' && <AccessibilityPage prefs={prefs} onChange={setPrefs} onAuto={() => startAuto('')} onManual={openManual}/>}
        </main>
        <footer className="app-footer"><span>GROUND–0 · Harshal’s Systems (AGS++) · OCM</span><span>v1.0 normative · Evidence before authority · <button type="button" className="text-button" onClick={() => navigate('accessibility')}>Accessibility</button></span></footer>
      </div>
    </div>

    <div id="g0-live-polite" className="sr-only" aria-live="polite" aria-atomic="true"/>
    <div id="g0-live-assertive" className="sr-only" aria-live="assertive" aria-atomic="true"/>

    {autoQuery !== null && <AutoAudit initialQuery={autoQuery} version={version} existing={audits} onClose={closeAuto} onSave={saveAutomatic} onReview={reviewAutomatic} onManual={() => { setAutoQuery(null); openManual(); }}/>}
    {wizardOpen && <AuditWizard initialVersion={version} initialInput={editingAudit?.input} mode={editingAudit?.method === 'automatic' ? 'review' : editingAudit ? 'draft' : 'new'} existing={wizardHistory} onClose={closeWizard} onSave={saveAudit}/>}
    {selectedAudit && <AuditDetails audit={selectedAudit} onClose={closeAudit} onToast={notify} onResume={resumeAudit} onDelete={id => { setUsers(current => current.filter(audit => audit.id !== id)); setSelectedAudit(null); notify('Audit removed from this browser.'); }}/>}
    {selectedPhase && <PhaseDetails phase={selectedPhase} onClose={closePhase} onAlgorithm={() => { setSelectedPhase(null); navigate('algorithm'); }}/>}
    {addEvidence && <AddEvidence audits={audits} onClose={closeEvidence} onSave={evidence => { setExtraEvidence(current => [evidence, ...current]); setAddEvidence(false); notify('Artifact saved. It stays unscored until you cite it in an audit.'); }}/>}
    {a11yOpen && <AccessibilityDialog prefs={prefs} onChange={setPrefs} onClose={closeAccessibility} onOpenPage={() => { setA11yOpen(false); navigate('accessibility'); }}/>}
    {commandOpen && <Modal className="command-modal" label="Search the workspace" onClose={closeCommand} initialFocus="#command-input">
      <div className="command-input"><Icon name="search" size={22}/><label htmlFor="command-input" className="sr-only">Search audits, pages and actions</label><input id="command-input" type="search" placeholder="Search audits, pages and actions" value={commandSearch} onChange={event => setCommandSearch(event.target.value)}/><button type="button" className="button secondary small" onClick={closeCommand}>Close</button></div>
      <div className="command-results">
        {commandActions.length > 0 && <><h2 className="command-group-label">Actions</h2><ul>{commandActions.map(action => <li key={action.label}><button type="button" className="command-item" onClick={action.run}><Icon name={action.icon} size={20}/><span>{action.label}</span></button></li>)}</ul></>}
        {commandPages.length > 0 && <><h2 className="command-group-label">Pages</h2><ul>{commandPages.map(item => <li key={item.id}><button type="button" className="command-item" onClick={() => { closeCommand(); navigate(item.id); }}><Icon name={item.icon} size={20}/><span>{item.title}</span></button></li>)}</ul></>}
        {commandAudits.length > 0 && <><h2 className="command-group-label">Audits</h2><ul>{commandAudits.map(audit => <li key={audit.id}><button type="button" className="command-item" onClick={() => { closeCommand(); setSelectedAudit(audit); }}><Icon name={entityIcon(audit)} size={20}/><span>{audit.name}<small>{audit.baseline ? 'Source baseline' : audit.method === 'automatic' ? 'Automated screening' : 'Saved audit'}</small></span><PhaseBadge phase={audit.phase} compact/></button></li>)}</ul></>}
        {!commandActions.length && !commandPages.length && !commandAudits.length && <div className="empty-state compact-empty" role="status"><h3>No results for “{commandSearch}”</h3><p>Try an organization name or a page title.</p></div>}
      </div>
      <p className="command-footer"><Icon name="lock" size={14}/>Searches this workspace only · Esc closes</p>
    </Modal>}

    {toast && !modalOpen && <div className="toast" key={toast.key} onMouseEnter={() => setToastPaused(true)} onMouseLeave={() => setToastPaused(false)} onFocus={() => setToastPaused(true)} onBlur={() => setToastPaused(false)}>
      <Icon name="check-circle" size={20}/><p>{toast.message}</p><button type="button" className="icon-button small" aria-label="Dismiss notification" onClick={() => setToast(null)}><Icon name="close" size={16}/></button>
    </div>}
  </>;
}
