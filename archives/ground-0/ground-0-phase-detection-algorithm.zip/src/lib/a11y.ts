export type TextSize = 'default' | 'large' | 'larger' | 'largest';
export type ContrastPref = 'system' | 'standard' | 'high';
export type MotionPref = 'system' | 'reduce';
export type LayoutMode = 'desktop' | 'tablet' | 'mobile';
export type A11yPrefs = { textSize: TextSize; contrast: ContrastPref; motion: MotionPref; readable: boolean; underline: boolean; speechRate: number };

export const defaultPrefs: A11yPrefs = { textSize: 'default', contrast: 'system', motion: 'system', readable: false, underline: false, speechRate: 1 };
const STORAGE_KEY = 'ground-0-a11y-v1';
const matches = (query: string): boolean => typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia(query).matches;

export function loadPrefs(): A11yPrefs {
  try { return { ...defaultPrefs, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') as Partial<A11yPrefs> }; }
  catch { return { ...defaultPrefs }; }
}

export function savePrefs(prefs: A11yPrefs): void {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs)); } catch { /* Storage can be unavailable in private modes. */ }
}

/** Writes the effective preferences to <html> so CSS can respond before React renders. */
export function applyPrefs(prefs: A11yPrefs): void {
  const root = document.documentElement;
  root.dataset.textSize = prefs.textSize;
  root.dataset.contrast = prefs.contrast === 'high' || (prefs.contrast === 'system' && matches('(prefers-contrast: more)')) ? 'high' : 'standard';
  root.dataset.motion = prefs.motion === 'reduce' || matches('(prefers-reduced-motion: reduce)') ? 'reduce' : 'full';
  root.dataset.readable = String(prefs.readable);
  root.dataset.underline = String(prefs.underline);
  applyLayout();
  // Re-check after styles settle, in case anything was still transitioning.
  window.requestAnimationFrame(() => applyLayout());
}

/** Layout is chosen from the width available at the current text size, so larger text reflows like zoom. */
export function computeLayout(): LayoutMode {
  const rootSize = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
  const effectiveWidth = window.innerWidth * 16 / rootSize;
  return effectiveWidth >= 1100 ? 'desktop' : effectiveWidth >= 720 ? 'tablet' : 'mobile';
}

export function applyLayout(): void {
  const mode = computeLayout();
  if (document.documentElement.dataset.layout !== mode) {
    document.documentElement.dataset.layout = mode;
    window.dispatchEvent(new CustomEvent('g0-layout'));
  }
}

export function watchEnvironment(getPrefs: () => A11yPrefs): () => void {
  const onResize = () => applyLayout();
  const onPreference = () => applyPrefs(getPrefs());
  const queries = typeof window.matchMedia === 'function' ? ['(prefers-contrast: more)', '(prefers-reduced-motion: reduce)'].map(query => window.matchMedia(query)) : [];
  window.addEventListener('resize', onResize);
  queries.forEach(query => query.addEventListener?.('change', onPreference));
  return () => {
    window.removeEventListener('resize', onResize);
    queries.forEach(query => query.removeEventListener?.('change', onPreference));
  };
}

/** Sends a message to the persistent live regions rendered by the app shell. */
export function announce(message: string, assertive = false): void {
  const region = document.getElementById(assertive ? 'g0-live-assertive' : 'g0-live-polite');
  if (!region) return;
  region.textContent = '';
  window.setTimeout(() => { region.textContent = message; }, 90);
}

export const speechSupported = (): boolean => typeof window !== 'undefined' && 'speechSynthesis' in window && typeof window.SpeechSynthesisUtterance === 'function';

export function speak(text: string, onEnd?: () => void): boolean {
  if (!speechSupported()) return false;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = loadPrefs().speechRate || 1;
  utterance.lang = 'en-US';
  utterance.onend = () => onEnd?.();
  utterance.onerror = () => onEnd?.();
  window.speechSynthesis.speak(utterance);
  return true;
}

export function stopSpeaking(): void {
  if (speechSupported()) window.speechSynthesis.cancel();
}

type RecognitionEvent = { results: ArrayLike<ArrayLike<{ transcript: string }>> };
export type Recognition = {
  lang: string; interimResults: boolean; maxAlternatives: number; continuous: boolean;
  start: () => void; stop: () => void; abort: () => void;
  onresult: ((event: RecognitionEvent) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
};
type RecognitionConstructor = new () => Recognition;

function recognitionConstructor(): RecognitionConstructor | undefined {
  if (typeof window === 'undefined') return undefined;
  const speechWindow = window as unknown as { SpeechRecognition?: RecognitionConstructor; webkitSpeechRecognition?: RecognitionConstructor };
  return speechWindow.SpeechRecognition || speechWindow.webkitSpeechRecognition;
}

export const recognitionSupported = (): boolean => !!recognitionConstructor();

export function createRecognition(): Recognition | null {
  const Constructor = recognitionConstructor();
  return Constructor ? new Constructor() : null;
}
