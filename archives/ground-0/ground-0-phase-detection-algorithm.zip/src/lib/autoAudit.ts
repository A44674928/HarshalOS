import { createAudit, newInput, today, type Answer, type AuditRecord, type CoverageEntry, type ReviewPage, type Version } from './engine';
import { ABOUT_PAGE, ADAPTERS, CATEGORY_LABELS, POLICY_PAGE, aliasPattern, buildUrl, getJson, isAbort, type Category, type Doc, type SearchContext, type SourceKey, type Tier } from './sources';

export { isAbort, aliasPattern } from './sources';
export type { Category } from './sources';
export const RULE_SET = 'G0-AUTO-2.0';
const WIKIPEDIA_API = 'https://en.wikipedia.org/w/api.php';
const WIKIDATA_API = 'https://www.wikidata.org/w/api.php';

export type Candidate = { title: string; description: string; qid: string; url: string; rank: number };
export type SignalKind = 'qualifying' | 'contrary' | 'candidate';
export type SignalOrigin = { source: SourceKey; sourceName: string; category: Category; tier: Tier; title: string; dateBasis: string };
export type Signal = { rule: string; question: string; kind: SignalKind; label: string; sentence: string; section: string; year: number | null; date: string | null; link: string; basis?: 'TERMINAL_RULE' | 'NO_PENALTY_EXIT'; origin: SignalOrigin };
export type SourceRecord = { name: string; url: string; revision: string; published: string; retrieved: string; role: string };
export type Fact = { label: string; value: string; url?: string };
export type Finding = { code: string; answer: boolean; scored: Signal[]; contrary: Signal[]; candidates: Signal[]; gap: string };
export type ProgressUpdate = { stage: 'identity' | 'search' | 'analysis' | 'done'; source?: SourceKey; name?: string; category?: Category; status?: CoverageEntry['status'] | 'running'; count?: number | null; note?: string };
export type AutoOutcome = { record: AuditRecord; candidate: Candidate; findings: Finding[]; constraints: Finding[]; sources: SourceRecord[]; coverage: CoverageEntry[]; primaryPages: ReviewPage[]; notCovered: string[]; facts: Fact[]; warnings: string[]; sentencesChecked: number; documentsChecked: number; cutoff: string };

export const LIMITATIONS = [
  'Fixed keyword rules read case captions, snippets, titles, abstracts and encyclopedic text. They can misread negation, historical events, or statements about other organizations.',
  'Court, legislative and archive searches return record metadata and short excerpts, not full documents. Open the linked record before relying on it.',
  'Wikipedia and Wikinews are tertiary or volunteer sources. Confirm quotes against the primary documents they cite.',
  'A “No” records an evidence gap in the sources searched. It is not proof that the behavior is absent.',
  'Organizations rarely publish a signed Phase Declaration Header, so an automated screening never issues a formal badge. The provisional badge shows how far the evidence goes.',
];
export const NOT_COVERED = [
  'Courts outside CourtListener (US federal and state opinions, PACER dockets) and Wikidata: most non-US courts, tribunals and arbitration bodies.',
  'Legislation and regulation outside the US Federal Register, the US Congress (GovTrack) and UK legislation.gov.uk — including EU, state, provincial and municipal law.',
  'News behind paywalls or outside GDELT (from 2017) and Wikinews. GDELT rate-limits requests and is sometimes unavailable.',
  'The organization’s own web pages and PDFs: dated through the Wayback Machine and listed for review, but their text cannot be read by a browser from another site.',
  'Full opinion, docket and rule texts. Only captions, highlighted snippets, titles and abstracts are searched.',
];

type Code = 'B1' | 'B2' | 'B3' | 'B4' | 'B5' | 'C2' | 'C3';
type Rule = { id: string; q: Code; kind: 'qualifying' | 'contrary'; label: string; re: RegExp; exclude?: RegExp; only?: Version; basis?: 'TERMINAL_RULE' | 'NO_PENALTY_EXIT'; actor?: boolean; alias?: boolean; subject?: RegExp; stripAlias?: boolean; requireSubject?: boolean };
const RULE_SUBJECT = /\b(?:rules?|regulations?|decisions?|orders?|polic(?:y|ies)|standards?|guidelines?|constitution|charter|mandate|measures?|sanctions?|directives?|resolutions?|requirements?|programs?|programmes?|tools?|bans?|restrictions?|designations?|acts?|statutes?|laws?|treat(?:y|ies)|conventions?|agreements?)\b/i;
/** Court records routinely describe *some* order being vacated or reversed. These rules only score there when the entity's own decision is clearly the object. */
const COURT_CONTEXT_RULES = new Set(['B2-CHALLENGE', 'B4-COURT', 'B4-LEGIS', 'B4-APPEAL', 'B5-FORCE', 'B5-PERMANENT', 'B5-PRECEDENT']);

const TARGET_VOICE = /\b(?:was|were|been|being|is|are)\s+(?:\w+\s+){0,2}(?:fined|sanctioned|penali[sz]ed|banned|suspended|expelled|sued|charged|prosecuted|investigated|regulated|supervised|overseen|licensed)\b/i;
const NEGATED_POWER = /\b(?:no|not|without|lacks?|lacking|cannot|can't|unable to|never|limited)\b[^.;]{0,30}\b(?:enforc|power|powers|authority)/i;
const SUNSET = /\b(?:sunset (?:clauses?|provisions?|dates?)|expir(?:e|es|ed|ation|y) (?:unless|after|every|at the end|automatically|on)|must be (?:renewed|reauthori[sz]ed|re-?approved|re-?ratified)|reauthori[sz]\w*|temporary (?:body|measure|mandate|authority|agency|committee|rule|order)|time-limited|term limits?|(?:annual|yearly) (?:appropriations?|budget approvals?|renewals?))\b/i;
const OTHER_ACTOR = /\b(?:president|prime minister|congress|parliament|senate|senators?|court|courts|judges?|justices|lawmakers|legislators?|legislature|governments?|member states|countries|critics|regulators?|prosecutors?|police|ministers?|ministry|commission|attorneys? general|the united states|the european union|the eu|state of|officials|plaintiffs?|appellants?)\b/i;
const OVERRIDE_VERB = /\b(?:enjoin(?:s|ed|ing)?|vacat(?:e|es|ed|ing|ur)|struck down|strik(?:e|es|ing) down|overturn(?:s|ed|ing)?|revers(?:e|es|ed|ing|al)|set aside|invalidat(?:e|es|ed|ing)|held unlawful|declared unlawful)\b/i;
const OVERRIDE_RULES = ['B4-COURT', 'B4-LEGIS', 'B2-CHALLENGE'];
const TIER_RANK: Record<Tier, number> = { primary: 0, secondary: 1, tertiary: 2 };

/** Transparent, versioned rule set. Every rule is disclosed in the exported record. */
export const RULES: Rule[] = [
  { id: 'B1-FINE', actor: true, q: 'B1', kind: 'qualifying', label: 'Imposes fines, penalties or sanctions', re: /\b(?:impos(?:e|es|ed|ing)|lev(?:y|ies|ied|ying)|issu(?:e|es|ed|ing)|assess(?:es|ed|ing)?|hand(?:s|ed)? down)\b[^.;]{0,60}\b(?:fines?|penalt(?:y|ies)|sanctions|civil money penalt(?:y|ies))\b/i, exclude: TARGET_VOICE },
  { id: 'B1-REVOKE', actor: true, q: 'B1', kind: 'qualifying', label: 'Revokes or suspends licences, membership or access', re: /\b(?:revok(?:e|es|ed|ing)|suspend(?:s|ed|ing)?|terminat(?:e|es|ed|ing)|expel(?:s|led|ling)?|strip(?:s|ped|ping)?|debar(?:s|red|ring)?)\b[^.;]{0,50}\b(?:licen[cs]es?|charters?|accreditation|membership|voting (?:rights|privileges)|access|accounts?|registrations?|permits?|certification)\b/i, exclude: TARGET_VOICE },
  { id: 'B1-ENFORCE', actor: true, q: 'B1', kind: 'qualifying', label: 'Documented enforcement actions or powers', re: /\b(?:enforcement (?:actions?|powers?|authority|proceedings|mechanisms?|orders?)|cease[- ]and[- ]desist|consent orders?|enforc(?:es|ed|ing)\b[^.;]{0,40}\b(?:rules?|regulations?|laws?|standards?|compliance|polic(?:y|ies)|decisions?|sanctions?|orders?))/i, exclude: NEGATED_POWER },
  { id: 'B1-POWER', actor: true, q: 'B1', kind: 'qualifying', label: 'Holds power to compel, sanction or ban', re: /\b(?:power|powers|authority|authori[sz]ed|empowered)\b[^.;]{0,25}\bto\s+(?:fine|sanction|penali[sz]e|enforce|revoke|compel|ban|prohibit|prosecute|seize|suspend|expel|close)\b/i, exclude: NEGATED_POWER },
  { id: 'B1-ACCESS', actor: true, q: 'B1', kind: 'qualifying', label: 'Removes users or content for rule violations', re: /\b(?:ban(?:s|ned|ning)?|block(?:s|ed|ing)?|suspend(?:s|ed|ing)?|remov(?:e|es|ed|ing)|deplatform\w*|terminat(?:e|es|ed|ing))\b[^.;]{0,40}\b(?:users?|accounts?|content|posts?|members?|channels?|pages?|sellers?|apps?|developers?)\b[^.;]{0,60}\b(?:violat\w*|breach\w*|terms|polic(?:y|ies)|rules|guidelines|standards)\b/i, exclude: TARGET_VOICE },
  { id: 'B1-FUNDING', actor: true, q: 'B1', kind: 'qualifying', label: 'Makes funding conditional on compliance', re: /\b(?:fund(?:s|ing)?|grants?|aid|loans?|payments?|disbursements?|lending)\b[^.;]{0,40}\b(?:conditional (?:on|upon)|conditioned (?:on|upon)|contingent (?:on|upon)|tied to)\b[^.;]{0,50}\b(?:complian\w*|adherence|conditions?|requirements?|reforms?|performance|implementation|cooperation|meeting)\b/i },
  { id: 'B1-EMPLOY', actor: true, q: 'B1', kind: 'qualifying', label: 'Terminates employment for non-adherence', re: /\b(?:fired|dismiss(?:ed|es|al)|terminat(?:ed|es|ion)|sack(?:ed|s)?|disciplin(?:ed|es|ary))\b[^.;]{0,40}\bfor (?:violating|breaching|refusing|not following|failing to comply|non-?compliance)\b/i },

  { id: 'B2-ADVISORY', alias: true, q: 'B2', kind: 'qualifying', label: 'Decisions described as advisory, voluntary or non-binding', re: /\b(?:non-?binding|not (?:legally )?binding|no binding (?:force|authority|power)|(?:purely|only|strictly) advisory|advisory (?:body|role|capacity|opinions?|function|status|in nature|only)|voluntary (?:basis|compliance|guidelines?|standards?|codes?|commitments?|frameworks?)|(?:can|may) only (?:recommend|advise|urge)|merely (?:recommends?|advises?))\b/i },
  { id: 'B2-ADVICE', actor: true, alias: true, q: 'B2', kind: 'qualifying', label: 'Role framed as advice, guidance or recommendations', re: /\b(?:advis(?:es|ing) (?:the|on)\b|makes? recommendations\b|issues? recommendations\b|recommendations (?:to|for) (?:the )?(?:director|secretary|minister|government|agency|department|president|board|commission)|provides? (?:advice|guidance|recommendations)(?:,? and (?:advice|guidance|recommendations))? (?:to|for) (?:the )?(?:[A-Z]|governments?|countries|member|states?\b|ministers?|policymakers|regulators?|clinicians|physicians|hospitals|providers))/ },
  { id: 'B2-NOENFORCE', q: 'B2', kind: 'qualifying', label: 'No power or mechanism to enforce its decisions', re: /\b(?:no|not|without|lacks?|lacking|cannot|can't|unable to|never)\b[^.;]{0,30}\b(?:enforc\w*|power to (?:compel|enforce|sanction|punish)|binding (?:authority|power)|means to compel)\b/i, exclude: /\bnot only\b/i },
  { id: 'B2-IGNORED', q: 'B2', kind: 'qualifying', label: 'Non-compliance without penalty', re: /\b(?:ignored|disregarded|flouted|not complied with|failed to comply|did not comply|non-?compliance)\b[^.;]{0,60}\b(?:without (?:penalty|penalties|consequences?|sanctions?|repercussions?)|no (?:penalty|penalties|consequences?|sanctions?|repercussions?))\b/i },
  { id: 'B2-CHALLENGE', q: 'B2', kind: 'qualifying', label: 'Decisions can be legally challenged or overturned', re: /\b(?:overturn(?:s|ed|ing)?|struck down|strike down|vacat(?:e|ed|es|ing)|annul(?:s|led|ling)?|set aside|invalidat(?:e|es|ed|ing)|revers(?:e|ed|es|ing))\b[^.;]{0,40}\b(?:decisions?|rulings?|orders?|regulations?|rules?|polic(?:y|ies)|laws?|resolutions?|sanctions?|bans?|fines?|judge?ments?|verdicts?|approvals?|designations?|determinations?)\b|\b(?:challenged in court|legal challenges? to|subject to judicial review)\b/i },
  { id: 'B2-BINDING', q: 'B2', kind: 'contrary', label: 'Decisions described as binding or mandatory', re: /\b(?:legally binding|binding (?:on|upon)|mandatory|compulsory|required by law|must comply|obliged to comply|obligated to comply|obligatory)\b/i, exclude: /\b(?:non-?binding|not (?:legally )?binding)\b/i },

  { id: 'B3-ADOPTED', q: 'B3', kind: 'qualifying', label: 'Guidance adopted or implemented by others', re: /\b(?:adopted|implemented|used|followed|incorporated|applied|enforced|ratified)\b[^.;]{0,25}\bby\b[^.;]{0,60}\b(?:countries|states|governments|nations|member states|members|agencies|companies|hospitals|banks|courts|jurisdictions|organi[sz]ations|regulators|industr(?:y|ies)|manufacturers|schools|universities|director|secretary|ministers?|ministries|departments|insurers|physicians|clinicians|health systems|legislatures|parliaments)\b/i },
  { id: 'B3-BECOMES', q: 'B3', kind: 'qualifying', label: 'Guidance becomes binding policy downstream', re: /\b(?:becomes?|became) (?:official |federal |national |legally binding )?(?:policy|policies|law|laws|regulations?|binding|mandatory|standard practice)\b/i },
  { id: 'B3-RULES', actor: true, q: 'B3', kind: 'qualifying', label: 'Issues regulations, rules, orders or binding decisions', re: /\b(?:issu(?:e|es|ed|ing)|adopt(?:s|ed|ing)?|enact(?:s|ed|ing)?|promulgat\w*|decree[sd]?|impos(?:e|es|ed|ing))\b[^.;]{0,30}\b(?:regulations?|rules|directives?|orders?|decrees?|laws|legislation|binding resolutions?|rulings?|sanctions|requirements|standards|final rules?)\b/i, exclude: TARGET_VOICE },
  { id: 'B3-POLICY', q: 'B3', kind: 'qualifying', label: 'Sets policy that moves markets, access or speech', re: /\b(?:monetary policy|interest rates?|policy rates?|money supply|reserve requirements?|content moderation|moderat(?:es|ed|ing) content|community (?:standards|guidelines)|terms of (?:service|use)|sets? (?:the )?(?:standards?|prices?|rates?|quotas?|tariffs?|norms))\b/i },
  { id: 'B3-REGULATE', actor: true, q: 'B3', kind: 'qualifying', label: 'Regulates, supervises or licenses other entities', re: /\b(?:regulat(?:e|es|ed|ing)|supervis(?:e|es|ed|ing)|oversee(?:s|ing)?|licens(?:e|es|ed|ing)|certif(?:y|ies|ied|ying))\b[^.;]{0,40}\b(?:banks?|financial institutions|institutions|firms|companies|industr(?:y|ies)|markets?|providers|operators|professions?|practitioners|broadcasters?|utilities|products|drugs|medicines|devices|airlines)\b/i, exclude: TARGET_VOICE },
  { id: 'B3-INERT', q: 'B3', kind: 'contrary', label: 'Described as lacking rule-making or executive power', re: /\b(?:no (?:executive|regulatory|legislative|rule-making|enforcement) (?:power|powers|authority|role)|purely (?:ceremonial|symbolic|archival|custodial)|does not (?:make|set|issue|enforce) (?:policy|policies|rules|regulations|laws))\b/i },

  { id: 'B4-APPEAL', q: 'B4', kind: 'qualifying', only: '1.0', label: 'Formal appeal or review process exists', re: /\b(?:right (?:of|to) appeal|appeals? (?:process|procedure|board|body|tribunal|panel|mechanism|committee|chamber)|(?:can|may) (?:be )?appeal(?:ed)?|judicial review|administrative review|ombuds(?:man|person))\b/i },
  { id: 'B4-COURT', stripAlias: true, q: 'B4', kind: 'qualifying', only: '1.0', label: 'Courts can overturn or halt its decisions', re: /\b(?:courts?|tribunals?|judges?|judiciary|justices)\b[^.;]{0,60}\b(?:overturn(?:s|ed|ing)?|struck down|strike down|vacat(?:e|ed|es|ing)|annul(?:s|led|ling)?|set aside|invalidat(?:e|es|ed|ing)|block(?:s|ed|ing)?|enjoin(?:s|ed|ing)?|halt(?:s|ed|ing)?|revers(?:e|ed|es|ing))\b/i },
  { id: 'B4-LEGIS', stripAlias: true, q: 'B4', kind: 'qualifying', only: '1.0', label: 'Legislature can override, amend or repeal', re: /\b(?:congress|parliament|legislature|legislative|senate|national assembly|lawmakers|bundestag)\b[^.;]{0,60}\b(?:overrid(?:e|es|den|ing)|overrul(?:e|es|ed|ing)|repeal(?:s|ed|ing)?|abolish(?:es|ed|ing)?|revok(?:e|es|ed|ing)|amend(?:s|ed|ing)?|revers(?:e|es|ed|ing)|dissolv(?:e|es|ed|ing)|curtail(?:s|ed|ing)?)\b/i },
  { id: 'B4-EXIT', q: 'B4', kind: 'qualifying', only: '1.0', label: 'Members or users can leave', re: /\b(?:withdr(?:aw|aws|ew|awn|awal|awing)|leav(?:e|es|ing)|left|exit(?:ed|s|ing)?|opt(?:ed|s)?[- ]out|resign(?:ed|s)?)\b[^.;]{0,40}\b(?:membership|from the (?:organi[sz]ation|union|treaty|agreement|alliance|body|association|convention|platform|service))\b/i },
  { id: 'B4-STAY', q: 'B4', kind: 'qualifying', basis: 'TERMINAL_RULE', label: 'Binding stay or consent rule stops the action', re: /\b(?:automatic(?:ally)? stay\w*|stay(?:ed|s)? (?:pending|during) (?:an |the )?appeal|(?:cannot|may not|can not) (?:act|proceed|be implemented|be enforced)[^.;]{0,30}without (?:the )?(?:consent|approval|agreement)|requires? (?:the )?(?:unanimous |prior )?consent of|right to refuse)\b/i },
  { id: 'B4-FREEEXIT', q: 'B4', kind: 'qualifying', basis: 'NO_PENALTY_EXIT', label: 'Penalty-free exit ends participation', re: /\b(?:withdr\w*|leave|exit|opt[- ]out|cancel\w*|terminat\w*)\b[^.;]{0,40}\b(?:at any time|without (?:penalty|penalties|consequences?|cost|charge|sanctions?))\b/i },
  { id: 'B4-FINAL', q: 'B4', kind: 'contrary', label: 'Decisions described as final or unappealable', re: /\b(?:no (?:right of |right to )?appeal|cannot be appealed|not (?:subject to|open to) (?:appeal|judicial review|review|challenge)|final and binding|decisions? (?:are|is) final|unappealable)\b/i },

  { id: 'B5-FORCE', requireSubject: true, q: 'B5', kind: 'qualifying', label: 'Rules remain in force until changed', re: /\b(?:remain(?:s|ed)? in (?:force|effect|place)|(?:entered|came|comes|enters) into (?:force|effect)|in force since|until (?:it is |they are |being )?(?:repealed|revoked|amended|replaced|rescinded|superseded|withdrawn)|still (?:in force|in effect|applies|apply|valid|binding))\b/i },
  { id: 'B5-PERMANENT', q: 'B5', kind: 'qualifying', label: 'Permanent or indefinite authority', re: /\b(?:permanent (?:body|organ|agency|institution|authority|mandate|court|secretariat|members?|seats?|status|establishment|committee|council|tribunal)|(?:serve|serves|remain|remains|continue|continues|operate|operates|exist|exists|persist|persists) indefinitely|indefinite (?:mandate|term|duration|period)|in perpetuity|perpetual (?:succession|existence|charter))\b/i },
  { id: 'B5-PRECEDENT', q: 'B5', kind: 'qualifying', label: 'Past decisions continue to apply', re: /\b(?:binding precedents?|precedents? (?:remain|continue|still)|long-?standing (?:rules?|polic(?:y|ies)|practices?|regulations?)|(?:has|have) remained (?:unchanged|in place|in force))\b/i },
  { id: 'B5-TIMEBOUND', q: 'B5', kind: 'contrary', label: 'Authority expires or requires renewal', re: SUNSET },

  { id: 'C2-SUCCESS', q: 'C2', kind: 'qualifying', only: '1.0', label: 'Appeals have been granted', re: /\b(?:appeals? (?:was|were|have been|has been) (?:granted|upheld|successful|allowed)|won (?:an|its|their|the|on) appeal|successful(?:ly)? appeal\w*)\b/i },
  { id: 'C3-SUNSET', q: 'C3', kind: 'qualifying', label: 'Authority expires or must be renewed', re: SUNSET },
];

type WikiPage = { pageid?: number; title: string; index?: number; description?: string; fullurl?: string; missing?: boolean; extract?: string; pageprops?: { wikibase_item?: string; disambiguation?: string }; revisions?: { revid: number; timestamp: string }[]; extlinks?: { url: string }[] };
type Claim = { mainsnak?: { datavalue?: { value?: unknown } } };
type WikidataEntity = { missing?: string; lastrevid?: number; modified?: string; labels?: Record<string, { value: string }>; descriptions?: Record<string, { value: string }>; claims?: Record<string, Claim[]> };
type Identity = { qid: string; revision: string; modified: string; description: string; instanceIds: string[]; facts: Fact[]; dissolved: string; officialSite: string; officialName: string; shortNames: string[] };
type Ctx = { title: string; revid: string; revisionDate: string; cutoff: string; sentenceCount: number; documentCount: number; version: Version; sourceCount: number };

const clip = (text: string, max: number) => text.length > max ? `${text.slice(0, max - 1).trimEnd()}…` : text;
const dedupe = (list: Signal[]) => list.filter((signal, index) => list.findIndex(other => other.sentence === signal.sentence && other.rule === signal.rule) === index);
const wikiParams = (params: Record<string, string>) => ({ ...params, format: 'json', formatversion: '2', origin: '*' });

export async function searchOrganizations(query: string, signal?: AbortSignal): Promise<Candidate[]> {
  const data = await getJson<{ query?: { pages?: WikiPage[] } }>(buildUrl(WIKIPEDIA_API, wikiParams({ action: 'query', generator: 'search', gsrsearch: query, gsrlimit: '8', gsrnamespace: '0', prop: 'pageprops|description|info', ppprop: 'wikibase_item|disambiguation', inprop: 'url', redirects: '1' })), signal);
  const normalized = query.trim().toLowerCase();
  return (data.query?.pages ?? [])
    .filter(page => !(page.pageprops && 'disambiguation' in page.pageprops) && !/^list of /i.test(page.title))
    .map(page => ({ title: page.title, description: page.description ?? '', qid: page.pageprops?.wikibase_item ?? '', url: page.fullurl ?? `https://en.wikipedia.org/wiki/${encodeURIComponent(page.title.replace(/ /g, '_'))}`, rank: page.title.toLowerCase() === normalized ? 0 : page.index ?? 99 }))
    .sort((a, b) => a.rank - b.rank)
    .slice(0, 6);
}

const SKIP_SECTIONS = /^(?:see also|references|notes|further reading|external links|bibliography|sources|citations|footnotes|works cited|gallery|notes and references)$/i;
const ABBREVIATIONS = /\b(U\.S|U\.K|U\.N|E\.U|Inc|Ltd|Co|Corp|Dr|Mr|Mrs|Ms|St|No|vs|e\.g|i\.e|Jr|Sr|approx|Gen|Gov|Sen|Rep|v)\./g;

export function splitSentences(extract: string, defaultSection = 'Introduction', minLength = 30): { text: string; section: string }[] {
  const sentences: { text: string; section: string }[] = [];
  let section = defaultSection;
  let skip = false;
  for (const raw of extract.split('\n')) {
    const line = raw.trim();
    if (!line) continue;
    const heading = line.match(/^(={2,6})\s*(.+?)\s*\1$/);
    if (heading) { section = heading[2]; skip = SKIP_SECTIONS.test(section); continue; }
    if (skip) continue;
    const protectedLine = line.replace(ABBREVIATIONS, '$1\u0002');
    for (const part of protectedLine.replace(/([.!?])\s+(?=["“‘(\[]?[A-Z0-9])/g, '$1\u0001').split('\u0001')) {
      const text = part.replace(/\u0002/g, '.').trim();
      if (text.length >= minLength && text.length <= 700) sentences.push({ text, section });
    }
  }
  return sentences;
}

/** Converts a rendered Wikipedia revision into plain text with `== Heading ==` markers. */
export function articleTextFromHtml(html: string): string {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('sup.reference, .mw-editsection, .navbox, .infobox, .sidebar, table, style, script, .hatnote, .mw-empty-elt, .reflist, .refbegin, .thumb, figure, .gallery, .toc, .shortdescription, .noprint, .mw-references-wrap, ol.references, .metadata, .ambox, .portal, .sistersitebox, .mw-authority-control, .catlinks').forEach(element => element.remove());
  const parts: string[] = [];
  doc.querySelectorAll('h2, h3, h4, p, li, dd').forEach(element => {
    if (element.closest('li') !== element && element.tagName === 'P' && element.closest('li')) return;
    const text = element.textContent?.replace(/\[\d+\]|\[[a-z]\]|\[citation needed\]/gi, '').replace(/\s+/g, ' ').trim() ?? '';
    if (!text) return;
    const level = Number(element.tagName[1]);
    if (/^H[2-4]$/.test(element.tagName)) parts.push(`${'='.repeat(level)} ${text} ${'='.repeat(level)}`);
    else parts.push(text);
  });
  return parts.join('\n');
}

function sentenceYear(text: string, maxYear: number): number | null {
  const years = (text.match(/\b(?:1[89]\d{2}|20\d{2})\b/g) ?? []).map(Number).filter(year => year <= maxYear);
  return years.length ? Math.max(...years) : null;
}

/** Links straight to the quoted sentence using a text fragment; unsupported browsers simply open the pinned revision. */
function fragmentLink(permalink: string, sentence: string): string {
  const words = sentence.replace(/\s+/g, ' ').replace(/[.!?;:,]+$/, '').split(' ');
  const encode = (text: string) => encodeURIComponent(text).replace(/-/g, '%2D');
  if (words.length <= 8) return `${permalink}#:~:text=${encode(words.join(' '))}`;
  return `${permalink}#:~:text=${encode(words.slice(0, 5).join(' '))},${encode(words.slice(-3).join(' '))}`;
}

type RawSignal = Omit<Signal, 'link' | 'date' | 'origin'>;
export function matchSentences(sentences: { text: string; section: string }[], version: Version, aliases: RegExp, maxYear: number, requireAlias = false, specific: RegExp = aliases): RawSignal[] {
  const signals: RawSignal[] = [];
  for (const { text, section } of sentences) {
    if (requireAlias && !aliases.test(text)) continue;
    for (const rule of RULES) {
      const match = rule.re.exec(text);
      if (!match || rule.exclude?.test(text)) continue;
      if (rule.alias && !aliases.test(text) && !rule.subject?.test(text)) continue;
      if (rule.requireSubject && !RULE_SUBJECT.test(text)) continue;
      // "Library of Congress" must not trigger the legislature rule: re-test with the entity's own name removed.
      if (rule.stripAlias && !rule.re.test(text.replace(new RegExp(specific.source, 'gi'), '§'))) continue;
      if (rule.actor) {
        const prefix = text.slice(Math.max(0, match.index - 80), match.index);
        if (OTHER_ACTOR.test(prefix) && !aliases.test(prefix)) continue;
      }
      const kind: SignalKind = rule.kind === 'contrary' ? 'contrary' : rule.only && rule.only !== version ? 'candidate' : 'qualifying';
      signals.push({ rule: rule.id, question: rule.q, kind, label: rule.label, sentence: text, section, year: sentenceYear(text, maxYear), basis: rule.basis });
    }
  }
  return signals;
}

/** Kept for the rules sandbox and tests: analyse free text as if it were the encyclopedic article. */
export function analyzeText(extract: string, version: Version, permalink: string, maxYear: number, aliases: RegExp = /$^/): { sentences: { text: string; section: string }[]; signals: Signal[] } {
  const sentences = splitSentences(extract);
  const origin: SignalOrigin = { source: 'wikipedia', sourceName: 'Wikipedia', category: 'encyclopedic', tier: 'tertiary', title: 'Article text', dateBasis: 'article revision' };
  return { sentences, signals: matchSentences(sentences, version, aliases, maxYear, false, aliases).map(signal => ({ ...signal, link: fragmentLink(permalink, signal.sentence), date: null, origin })) };
}

function formatWikidataTime(time: string, precision: number): string {
  const match = time.match(/^([+-])(\d+)-(\d{2})-(\d{2})/);
  if (!match) return '';
  const [, sign, yearText, month, day] = match;
  const year = Number(yearText);
  if (sign === '-') return `${year} BCE`;
  if (precision >= 11 && month !== '00' && day !== '00') return new Intl.DateTimeFormat('en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(year, Number(month) - 1, Number(day))));
  if (precision === 10 && month !== '00') return new Intl.DateTimeFormat('en-US', { year: 'numeric', month: 'long', timeZone: 'UTC' }).format(new Date(Date.UTC(year, Number(month) - 1, 1)));
  return String(year);
}

async function readWikidata(qid: string, signal?: AbortSignal): Promise<Identity | null> {
  const data = await getJson<{ entities?: Record<string, WikidataEntity> }>(buildUrl(WIKIDATA_API, wikiParams({ action: 'wbgetentities', ids: qid, props: 'labels|descriptions|claims|info', languages: 'en' })), signal);
  const entity = data.entities?.[qid];
  if (!entity || entity.missing !== undefined) return null;
  const values = (prop: string) => (entity.claims?.[prop] ?? []).map(claim => claim.mainsnak?.datavalue?.value);
  const itemIds = (prop: string) => values(prop).map(value => (value as { id?: string } | undefined)?.id).filter((id): id is string => !!id).slice(0, 6);
  const englishText = (prop: string) => values(prop).map(value => value as { text?: string; language?: string } | undefined).filter(value => value?.language === 'en' && value.text).map(value => value!.text as string);
  const ids = Array.from(new Set(['P31', 'P1454', 'P749', 'P17', 'P159', 'P3719'].flatMap(itemIds)));
  let labels: Record<string, string> = {};
  if (ids.length) {
    try {
      const labelData = await getJson<{ entities?: Record<string, WikidataEntity> }>(buildUrl(WIKIDATA_API, wikiParams({ action: 'wbgetentities', ids: ids.join('|'), props: 'labels', languages: 'en' })), signal);
      labels = Object.fromEntries(Object.entries(labelData.entities ?? {}).map(([id, item]) => [id, item.labels?.en?.value ?? id]));
    } catch (error) { if (isAbort(error)) throw error; }
  }
  const names = (prop: string) => itemIds(prop).map(id => labels[id] ?? id).join(', ');
  const time = (prop: string) => { const value = values(prop)[0] as { time?: string; precision?: number } | undefined; return value?.time ? formatWikidataTime(value.time, value.precision ?? 9) : ''; };
  const sites = values('P856').filter((value): value is string => typeof value === 'string' && /^https?:\/\//.test(value));
  const officialSite = sites.find(site => !/\/(?:fr|es|ru|ar|zh|de|pt|it|ja)\/?$/.test(site)) ?? sites[0] ?? '';
  const facts: Fact[] = [
    { label: 'Type', value: names('P31') },
    { label: 'Legal form', value: names('P1454') },
    { label: 'Parent organization', value: names('P749') },
    { label: 'Regulated by (Wikidata)', value: names('P3719') },
    { label: 'Country', value: names('P17') },
    { label: 'Headquarters', value: names('P159') },
    { label: 'Founded', value: time('P571') },
    { label: 'Dissolved', value: time('P576') },
    { label: 'Official website', value: officialSite, url: officialSite || undefined },
  ].filter(fact => fact.value);
  return { qid, revision: String(entity.lastrevid ?? ''), modified: entity.modified ?? '', description: entity.descriptions?.en?.value ?? '', instanceIds: itemIds('P31'), facts, dissolved: time('P576'), officialSite, officialName: englishText('P1448')[0] ?? '', shortNames: englishText('P1813') };
}

const scope = (ctx: Ctx, code: string) => `Bounded automated search: ${ctx.sentenceCount} sentences from ${ctx.documentCount} documents across ${ctx.sourceCount} sources (Wikipedia revision ${ctx.revid} of ${ctx.revisionDate}, plus court, legislative, news and archive records dated on or before ${ctx.cutoff}) were checked for ${code} with rule set ${RULE_SET}.`;
const quotes = (list: Signal[], count = 2) => list.slice(0, count).map(signal => `“${clip(signal.sentence, 240)}” — ${signal.origin.sourceName}, ${signal.origin.title}${signal.date ? `, ${signal.date}` : ''}`).join(' ');
const rankSignals = (list: Signal[]) => [...list].sort((a, b) => TIER_RANK[a.origin.tier] - TIER_RANK[b.origin.tier] || (b.date ?? '').localeCompare(a.date ?? ''));

function buildFinding(code: string, signals: Signal[], ctx: Ctx): { finding: Finding; answer: Answer } {
  const mine = signals.filter(signal => signal.question === code);
  const scored = rankSignals(dedupe(mine.filter(signal => signal.kind === 'qualifying')));
  const contrary = rankSignals(dedupe(mine.filter(signal => signal.kind === 'contrary')));
  const candidates = rankSignals(dedupe(mine.filter(signal => signal.kind === 'candidate')));
  if (scored.length) {
    const labels = Array.from(new Set(scored.map(signal => signal.label))).slice(0, 3).join('; ');
    const gap = contrary.length ? `Conflicting statement also found and flagged for review: “${clip(contrary[0].sentence, 200)}” (${contrary[0].origin.sourceName})` : '';
    return { finding: { code, answer: true, scored, contrary, candidates, gap }, answer: { value: true, source: scored[0].link, date: scored[0].date ?? ctx.revisionDate, notes: clip(`Automated match (${labels}): ${quotes(scored)}`, 900), gap } };
  }
  const related = candidates.length ? ` Related statements were found but do not meet the Ground-0 v${ctx.version} rule for ${code}, for example: “${clip(candidates[0].sentence, 200)}” (${candidates[0].origin.sourceName}).` : '';
  const gap = `${scope(ctx, code)} No qualifying statement was found. This records an evidence gap; it is not proof of the negative.${related}`;
  const answer: Answer = contrary.length
    ? { value: false, source: contrary[0].link, date: contrary[0].date ?? ctx.revisionDate, notes: clip(`Contrary statement (${contrary[0].label}): ${quotes(contrary, 1)}`, 700), gap }
    : { value: false, source: '', date: '', notes: '', gap };
  return { finding: { code, answer: false, scored, contrary, candidates, gap }, answer };
}

function buildConstraints(signals: Signal[], ctx: Ctx): { finding: Finding; answer: Answer }[] {
  const windowStart = (months: number) => { const date = new Date(`${ctx.cutoff}T00:00:00Z`); date.setUTCMonth(date.getUTCMonth() - months); return date.getTime(); };
  const stamp = (signal: Signal) => signal.date ? Date.parse(`${signal.date}T00:00:00Z`) : signal.year !== null ? Date.parse(`${signal.year}-01-01T00:00:00Z`) : NaN;
  const within = (signal: Signal, months: number) => { const value = stamp(signal); return Number.isFinite(value) && value >= windowStart(months) && value <= Date.parse(`${ctx.cutoff}T23:59:59Z`); };
  const byDate = (list: Signal[]) => [...list].sort((a, b) => (Number.isFinite(stamp(b)) ? stamp(b) : 0) - (Number.isFinite(stamp(a)) ? stamp(a) : 0));
  const overrides = byDate(dedupe(signals.filter(signal => signal.question === 'C1' || (OVERRIDE_RULES.includes(signal.rule) && signal.kind !== 'contrary'))));
  const strongOverrides = overrides.filter(signal => signal.question !== 'C1' || signal.kind === 'qualifying');
  const appeals = dedupe(signals.filter(signal => signal.question === 'C2'));
  const qualifyingAppeals = appeals.filter(signal => signal.kind === 'qualifying');
  const sunsets = dedupe(signals.filter(signal => signal.question === 'C3'));
  const none = (code: string, detail: string): Answer => ({ value: false, source: '', date: '', notes: '', gap: `${scope(ctx, code)} ${detail}` });
  const dated = (signal: Signal, months: number, what: string): Answer => ({ value: true, source: signal.link, date: signal.date ?? `${signal.year}-01-01`, notes: clip(`Automated match (${what}; ${signal.date ? `dated ${signal.date}` : `event year ${signal.year}, conservatively dated ${signal.year}-01-01`} for the ${months}-month window): “${clip(signal.sentence, 300)}” — ${signal.origin.sourceName}, ${signal.origin.title}`, 700), gap: '' });
  const make = (code: string, scored: Signal[], answer: Answer, candidates: Signal[] = []) => ({ finding: { code, answer: answer.value === true, scored, contrary: [], candidates, gap: answer.gap }, answer });

  const recentOverrides = strongOverrides.filter(signal => within(signal, 24));
  const latest = overrides[0];
  const c1 = recentOverrides.length
    ? make('C1', recentOverrides, dated(recentOverrides[0], 24, 'external override'), overrides.filter(signal => !recentOverrides.includes(signal)).slice(0, 3))
    : make('C1', [], none('C1', `No dated external override within 24 months of the cutoff was found.${latest ? ` The most recent override-related record found is ${latest.date ?? latest.year ?? 'undated'}: “${clip(latest.sentence, 160)}” (${latest.origin.sourceName}).` : ''}`), overrides.slice(0, 3));
  const c2 = ctx.version === '1.1'
    ? make('C2', [], none('C2', 'Ground-0 v1.1 requires a published route, invoked cases and a complete, bounded outcome set with at least 50% relief. Automated screening cannot establish a complete outcome set, so C2 is not demonstrated.'), appeals.slice(0, 3))
    : qualifyingAppeals.length
      ? make('C2', qualifyingAppeals, { value: true, source: qualifyingAppeals[0].link, date: qualifyingAppeals[0].date ?? ctx.revisionDate, notes: clip(`Automated match (appeals granted): ${quotes(qualifyingAppeals)}`, 700), gap: '' })
      : make('C2', [], none('C2', 'No statement of granted or successful appeals was found.'));
  const c3 = sunsets.length
    ? make('C3', sunsets, { value: true, source: sunsets[0].link, date: sunsets[0].date ?? ctx.revisionDate, notes: clip(`Automated match (sunset or renewal requirement): ${quotes(sunsets)}`, 700), gap: '' })
    : make('C3', [], none('C3', 'No sunset clause, expiry or renewal requirement was found.'));
  const fresh = byDate(dedupe([...strongOverrides, ...qualifyingAppeals, ...sunsets])).filter(signal => within(signal, 12));
  const c4 = fresh.length
    ? make('C4', fresh, dated(fresh[0], 12, 'constraint activity'))
    : make('C4', [], none('C4', 'No constraint activity dated within 12 months of the cutoff was found.'));
  return [c1, c2, c3, c4];
}

type RunOptions = { candidate: Candidate; version: Version; cutoff?: string; categories?: Category[]; existing: AuditRecord[]; onProgress: (update: ProgressUpdate) => void; signal?: AbortSignal };

export async function runAutomaticAudit({ candidate, version, cutoff: requestedCutoff, categories, existing, onProgress, signal }: RunOptions): Promise<AutoOutcome> {
  const retrieved = new Date().toISOString();
  const cutoff = requestedCutoff && requestedCutoff <= today() ? requestedCutoff : today();
  const enabled = new Set<Category>(categories ?? ['encyclopedic', 'official', 'court', 'legislative', 'news', 'archive']);
  onProgress({ stage: 'identity', name: 'Wikipedia' });

  // 1. Encyclopedic identity: the newest Wikipedia revision on or before the cutoff.
  const revisionData = await getJson<{ query?: { pages?: WikiPage[] } }>(buildUrl(WIKIPEDIA_API, wikiParams({ action: 'query', prop: 'revisions|pageprops|info', titles: candidate.title, rvlimit: '1', rvdir: 'older', rvstart: `${cutoff}T23:59:59Z`, rvprop: 'ids|timestamp', ppprop: 'wikibase_item', inprop: 'url', redirects: '1' })), signal);
  const page = revisionData.query?.pages?.[0];
  if (!page || page.missing) throw new Error(`No Wikipedia article was found for “${candidate.title}”. Try another match or use the manual audit.`);
  const revision = page.revisions?.[0];
  if (!revision) throw new Error(`The Wikipedia article “${page.title}” has no revision on or before ${cutoff}. Choose a later cutoff.`);
  const revid = String(revision.revid);
  const revisionDate = revision.timestamp.slice(0, 10);
  const permalink = `https://en.wikipedia.org/w/index.php?title=${encodeURIComponent(page.title.replace(/ /g, '_'))}&oldid=${revid}`;
  let articleText = '';
  const warnings: string[] = [];
  try {
    const parsed = await getJson<{ parse?: { text?: string } }>(buildUrl(WIKIPEDIA_API, wikiParams({ action: 'parse', oldid: revid, prop: 'text', disableeditsection: '1', disabletoc: '1', disablelimitreport: '1' })), signal);
    articleText = articleTextFromHtml(parsed.parse?.text ?? '');
  } catch (error) { if (isAbort(error)) throw error; }
  if (!articleText.trim()) {
    const fallback = await getJson<{ query?: { pages?: WikiPage[] } }>(buildUrl(WIKIPEDIA_API, wikiParams({ action: 'query', prop: 'extracts', titles: page.title, explaintext: '1', exsectionformat: 'wiki', redirects: '1' })), signal);
    articleText = fallback.query?.pages?.[0]?.extract ?? '';
    if (articleText.trim()) warnings.push('The pinned revision could not be rendered, so the current article text was used instead.');
  }
  if (!articleText.trim()) throw new Error(`No readable article text was available for “${page.title}”.`);

  // 2. Structured identity from Wikidata and the article's cited links.
  onProgress({ stage: 'identity', name: 'Wikidata' });
  const qid = page.pageprops?.wikibase_item || candidate.qid;
  let identity: Identity | null = null;
  if (qid) {
    try { identity = await readWikidata(qid, signal); }
    catch (error) { if (isAbort(error)) throw error; warnings.push('Wikidata could not be reached, so structured facts, aliases and the official website are unavailable.'); }
  }
  let extlinks: string[] = [];
  try {
    const links = await getJson<{ query?: { pages?: WikiPage[] } }>(buildUrl(WIKIPEDIA_API, wikiParams({ action: 'query', prop: 'extlinks', titles: page.title, ellimit: '300', redirects: '1' })), signal);
    extlinks = (links.query?.pages?.[0]?.extlinks ?? []).map(link => link.url).filter(url => /^https?:\/\//.test(url) && !/web\.archive\.org|wikipedia\.org|wikidata\.org|doi\.org|books\.google|jstor|archive\.org/.test(url));
  } catch (error) { if (isAbort(error)) throw error; }
  const acronym = articleText.slice(0, 600).match(/\(([A-Z][A-Za-z0-9&.]{1,9})\)/)?.[1] ?? '';
  const baseName = page.title.replace(/\s*\(.*\)$/, '');
  const aliasNames = Array.from(new Set([page.title, baseName, identity?.officialName ?? '', ...(identity?.shortNames ?? []), acronym].filter(name => name.length >= 3)));
  const searchNames = Array.from(new Set([baseName, identity?.officialName ?? ''].filter(name => name.length >= 6))).slice(0, 2);
  const specificAliases = aliasPattern(aliasNames, { generic: false });
  const officialHost = (() => { try { return identity?.officialSite ? new URL(identity.officialSite).hostname.replace(/^www\./, '') : ''; } catch { return ''; } })();
  const sameHost = (url: string) => Number(!!officialHost && url.includes(officialHost));
  const strongPages = extlinks.filter(url => POLICY_PAGE.test(url)).sort((a, b) => sameHost(b) - sameHost(a) || Number(/\.pdf(?:$|[?#])/i.test(a)) - Number(/\.pdf(?:$|[?#])/i.test(b)));
  const aboutPages = extlinks.filter(url => !strongPages.includes(url) && ABOUT_PAGE.test(url) && sameHost(url));
  const candidatePages = Array.from(new Set([...strongPages, ...aboutPages])).slice(0, 6);

  // 3. Public record searches, in parallel, each isolated so one failure never stops the others.
  const context: SearchContext = { name: page.title, searchNames, aliasRe: specificAliases, qid, cutoff, officialSite: identity?.officialSite ?? '', candidatePages, signal };
  const coverage: CoverageEntry[] = [];
  const docs: Doc[] = [];
  await Promise.all(ADAPTERS.map(async adapter => {
    const base = { key: adapter.key, name: adapter.name, category: adapter.category, coverage: adapter.coverage };
    if (!enabled.has(adapter.category)) { coverage.push({ ...base, status: 'skipped', total: null, used: 0, query: '', searchUrl: '', note: 'Turned off for this audit.', ms: 0 }); onProgress({ stage: 'search', source: adapter.key, name: adapter.name, category: adapter.category, status: 'skipped' }); return; }
    onProgress({ stage: 'search', source: adapter.key, name: adapter.name, category: adapter.category, status: 'running' });
    const started = performance.now();
    try {
      const result = await adapter.run(context);
      const status: CoverageEntry['status'] = result.docs.length || (result.total ?? 0) > 0 ? 'searched' : 'no-results';
      coverage.push({ ...base, status, total: result.total, used: result.docs.length, query: result.query, searchUrl: result.searchUrl, note: result.note, ms: Math.round(performance.now() - started) });
      docs.push(...result.docs);
      onProgress({ stage: 'search', source: adapter.key, name: adapter.name, category: adapter.category, status, count: result.total, note: result.note });
    } catch (error) {
      if (isAbort(error)) throw error;
      const note = error instanceof Error ? error.message : 'Unavailable.';
      coverage.push({ ...base, status: 'unavailable', total: null, used: 0, query: '', searchUrl: '', note, ms: Math.round(performance.now() - started) });
      onProgress({ stage: 'search', source: adapter.key, name: adapter.name, category: adapter.category, status: 'unavailable', note });
    }
  }));
  coverage.sort((a, b) => ADAPTERS.findIndex(adapter => adapter.key === a.key) - ADAPTERS.findIndex(adapter => adapter.key === b.key));

  // 4. Evidence matching across every document, with provenance on each signal.
  onProgress({ stage: 'analysis' });
  const maxYear = Number(cutoff.slice(0, 4));
  const wikipediaAliases = aliasPattern(aliasNames, { generic: true });
  const wikipediaSentences = splitSentences(articleText);
  const wikipediaOrigin: SignalOrigin = { source: 'wikipedia', sourceName: 'Wikipedia', category: 'encyclopedic', tier: 'tertiary', title: `${page.title} (revision ${revid})`, dateBasis: 'article revision' };
  const signals: Signal[] = matchSentences(wikipediaSentences, version, wikipediaAliases, maxYear, false, specificAliases).map(signal => ({ ...signal, link: fragmentLink(permalink, signal.sentence), date: null, origin: wikipediaOrigin }));
  let sentenceCount = wikipediaSentences.length;
  const objectOverride = new RegExp(`${OVERRIDE_VERB.source}[^.;]{0,80}${specificAliases.source}|${specificAliases.source}(?:'s|’s)?\\s+(?:own\\s+)?(?:rule|order|decision|policy|regulation|ban|action|determination|designation|approval)s?[^.;]{0,60}${OVERRIDE_VERB.source}`, 'i');
  for (const doc of docs) {
    if (!doc.text.trim()) continue;
    const origin: SignalOrigin = { source: doc.source, sourceName: doc.sourceName, category: doc.category, tier: doc.tier, title: doc.title, dateBasis: doc.dateBasis };
    const sentences = splitSentences(doc.text, doc.title, 20);
    sentenceCount += sentences.length;
    const aliases = aliasPattern(aliasNames, { generic: doc.firstPerson, firstPerson: doc.firstPerson });
    for (const raw of matchSentences(sentences, version, aliases, maxYear, doc.requireAlias, specificAliases)) {
      let signal: Signal = { ...raw, link: doc.url, date: doc.date || null, origin };
      if (doc.category === 'court' && signal.kind === 'qualifying' && COURT_CONTEXT_RULES.has(signal.rule) && !objectOverride.test(signal.sentence)) {
        signal = { ...signal, kind: 'candidate', label: `${signal.label} (court record — confirm it was this organization's own decision that was overturned)` };
      }
      signals.push(signal);
    }
    if (doc.source === 'federal-register' && doc.issuer === 'entity' && doc.kind === 'rule') {
      signals.push({ rule: 'FR-RULE', question: 'B3', kind: 'qualifying', label: 'Publishes binding rules in the Federal Register', sentence: doc.title, section: 'Federal Register', year: Number(doc.date.slice(0, 4)), date: doc.date, link: doc.url, origin });
      signals.push({ rule: 'FR-EFFECTIVE', question: 'B5', kind: 'candidate', label: 'Final rule with an effective date (persists until amended unless a sunset applies — verify)', sentence: `${doc.title}${doc.meta?.effective ? ` Effective ${doc.meta.effective}.` : ''}`, section: 'Federal Register', year: Number(doc.date.slice(0, 4)), date: doc.date, link: doc.url, origin });
    }
    if (doc.category === 'court' && OVERRIDE_VERB.test(doc.text)) {
      const strong = objectOverride.test(doc.text);
      signals.push({ rule: strong ? 'COURT-OVERRIDE' : 'COURT-OVERRIDE-CONTEXT', question: 'C1', kind: strong ? 'qualifying' : 'candidate', label: strong ? 'Court order overriding or enjoining the organization' : 'Court record mentioning vacatur, reversal or injunction (party role unclear)', sentence: clip(doc.text, 400), section: doc.meta?.court ?? 'Court record', year: Number(doc.date.slice(0, 4)) || null, date: doc.date || null, link: doc.url, origin });
    }
  }
  const ctx: Ctx = { title: page.title, revid, revisionDate, cutoff, sentenceCount, documentCount: docs.length + 1, version, sourceCount: coverage.filter(entry => entry.status === 'searched' || entry.status === 'no-results').length + 1 };
  const built = ['B1', 'B2', 'B3', 'B4', 'B5'].map(code => buildFinding(code, signals, ctx));
  const constraintSet = buildConstraints(signals, ctx);
  if (identity?.instanceIds.includes('Q5')) warnings.push('Wikidata describes this subject as a person, not an organization. Ground-0 is designed for institutions and systems.');
  if (identity?.dissolved) warnings.push(`Wikidata records that this organization was dissolved (${identity.dissolved}). The screening describes the historical record.`);
  if (wikipediaSentences.length < 40) warnings.push(`Only ${wikipediaSentences.length} sentences of article text were available, so several questions may rest on other sources or remain evidence gaps.`);
  const unavailable = coverage.filter(entry => entry.status === 'unavailable');
  if (unavailable.length) warnings.push(`${unavailable.length} source${unavailable.length === 1 ? ' was' : 's were'} unavailable: ${unavailable.map(entry => entry.name).join(', ')}. Their records were not searched.`);

  // 5. Assemble the Ground-0 input.
  const input = newInput(version);
  input.name = page.title;
  input.identifier = qid || `WIKIPEDIA-${page.title.replace(/[^A-Za-z0-9]+/g, '-').toUpperCase()}`;
  input.cutoff = cutoff;
  input.answers = built.map(item => item.answer);
  input.constraints = constraintSet.map(item => item.answer);
  const strict = built[3].finding.scored.find(item => item.basis);
  input.b4 = strict
    ? { ...input.b4, actor: 'Member or affected party (as described in the cited source)', action: 'The institutional action or participation described in the cited sentence', procedure: `Automated extract: “${clip(strict.sentence, 300)}” (${strict.origin.sourceName})`, basis: strict.basis ?? 'NOT_DEMONSTRATED' }
    : { ...input.b4, basis: signals.some(item => OVERRIDE_RULES.includes(item.rule) || item.question === 'C1') ? 'EXTERNAL_ORDER_ONLY' : 'NOT_DEMONSTRATED' };
  const courtDocs = docs.filter(doc => doc.category === 'court' && doc.date).sort((a, b) => b.date.localeCompare(a.date));
  const enacted = docs.filter(doc => doc.source === 'govtrack' && /enacted|signed/i.test(doc.kind));
  const exercised = constraintSet[0].finding.answer;
  const anchor = courtDocs[0] ?? enacted[0];
  if (anchor) input.external = { exists: true, exercised, holder: `${courtDocs.length ? `Courts (${courtDocs.length} record${courtDocs.length === 1 ? '' : 's'} naming the organization)` : ''}${courtDocs.length && enacted.length ? ' and ' : ''}${enacted.length ? 'the US Congress (enacted legislation mentioning the organization)' : ''}`, scope: anchor.title, source: anchor.url, date: anchor.date };

  const sources: SourceRecord[] = [
    { name: `Wikipedia — ${page.title}`, url: permalink, revision: revid, published: revisionDate, retrieved, role: `Article text as of the cutoff (${wikipediaSentences.length} sentences; tertiary source)` },
    ...(identity ? [{ name: `Wikidata — ${qid}`, url: `https://www.wikidata.org/w/index.php?title=${qid}&oldid=${identity.revision}`, revision: identity.revision, published: (identity.modified || retrieved).slice(0, 10), retrieved, role: 'Identity, aliases, official website and structured facts (not scored)' }] : []),
  ];
  const primaryPages: ReviewPage[] = docs.filter(doc => doc.source === 'wayback').map(doc => ({ title: doc.title, url: doc.url, date: doc.date, dateBasis: doc.dateBasis, original: doc.meta?.original ?? doc.title }));
  const record = await createAudit(input, existing);
  const finding = `Automated screening, pending human review. ${record.finding}`;
  const decorated: AuditRecord = {
    ...record,
    method: 'automatic',
    status: record.status === 'Draft' ? 'Draft' : 'Needs review',
    finding,
    replicationRisk: 'MEDIUM',
    automation: { ruleSet: RULE_SET, subject: page.title, description: candidate.description || identity?.description || '', reviewed: false, sources, warnings, coverage, primaryPages, notCovered: NOT_COVERED, documentsChecked: docs.length + 1, sentencesChecked: sentenceCount },
    report: {
      ...record.report,
      Audit_Method: 'AUTOMATED_SCREENING',
      Human_Review: 'PENDING',
      Finding: finding,
      Replication_Risk: 'MEDIUM',
      Replication_Basis: 'Deterministic for the pinned Wikipedia revision, the dated records returned by each source at the time of the search, and the rule set. Live indexes change; the coverage table records what was searched.',
      Automation: {
        Rule_Set: RULE_SET,
        Evidence_Cutoff: cutoff,
        Sources: sources,
        Coverage: coverage.map(entry => ({ Source: entry.name, Category: CATEGORY_LABELS[entry.category as Category], Status: entry.status.toUpperCase(), Results: entry.total, Used: entry.used, Query: entry.query, Search_URL: entry.searchUrl, Coverage: entry.coverage, Note: entry.note ?? null })),
        Documents_Checked: docs.length + 1,
        Sentences_Checked: sentenceCount,
        Matched_Statements: signals.slice(0, 80).map(item => ({ Rule: item.rule, Question: item.question, Kind: item.kind.toUpperCase(), Source: item.origin.sourceName, Record: item.origin.title, Tier: item.origin.tier.toUpperCase(), Date: item.date, Date_Basis: item.origin.dateBasis, Quote: clip(item.sentence, 320), Link: item.link })),
        Primary_Pages_To_Review: primaryPages,
        Not_Covered: NOT_COVERED,
        Wikidata_Facts: identity?.facts ?? [],
        Warnings: warnings,
        Limitations: LIMITATIONS,
      },
    },
  };
  onProgress({ stage: 'done' });
  return { record: decorated, candidate: { ...candidate, title: page.title, qid }, findings: built.map(item => item.finding), constraints: constraintSet.map(item => item.finding), sources, coverage, primaryPages, notCovered: NOT_COVERED, facts: identity?.facts ?? [], warnings, sentencesChecked: sentenceCount, documentsChecked: docs.length + 1, cutoff };
}
