/**
 * Key-free public record sources that can be searched directly from a browser.
 * Every source here was checked for cross-origin (CORS) access. Sources that
 * block browsers (SEC EDGAR full text, UK Parliament APIs, ECHR HUDOC, page
 * content from the Wayback Machine) are deliberately not included.
 */
export type SourceKey = 'wikipedia' | 'courtlistener' | 'recap' | 'wikidata-cases' | 'archive-courts' | 'federal-register' | 'govtrack' | 'legislation-uk' | 'gdelt' | 'wikinews' | 'wikisource' | 'archive-texts' | 'wayback';
export type Category = 'encyclopedic' | 'court' | 'legislative' | 'news' | 'archive' | 'official';
export type Tier = 'primary' | 'secondary' | 'tertiary';
export type Doc = { id: string; source: SourceKey; sourceName: string; category: Category; tier: Tier; title: string; text: string; url: string; date: string; dateBasis: string; issuer: 'entity' | 'external' | 'unknown'; kind: string; requireAlias: boolean; firstPerson: boolean; meta?: Record<string, string> };
export type SearchContext = { name: string; searchNames: string[]; aliasRe: RegExp; qid: string; cutoff: string; officialSite: string; candidatePages: string[]; signal?: AbortSignal };
export type AdapterResult = { docs: Doc[]; total: number | null; query: string; searchUrl: string; note?: string };
export type Adapter = { key: SourceKey; name: string; category: Category; coverage: string; run: (ctx: SearchContext) => Promise<AdapterResult> };

export const CATEGORY_LABELS: Record<Category, string> = { encyclopedic: 'Encyclopedic', court: 'Court records', legislative: 'Legislative & regulatory', news: 'News', archive: 'Archives', official: 'Official pages' };
export const TIER_LABELS: Record<Tier, string> = { primary: 'Primary record', secondary: 'Secondary source', tertiary: 'Tertiary source' };

const REQUEST_TIMEOUT = 22000;
export const isAbort = (error: unknown): boolean => error instanceof DOMException && error.name === 'AbortError';
export class SourceError extends Error {}

async function request(url: string, signal: AbortSignal | undefined, kind: 'json' | 'text', timeoutMs = REQUEST_TIMEOUT): Promise<unknown> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  const forward = () => controller.abort();
  signal?.addEventListener('abort', forward);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: kind === 'json' ? { Accept: 'application/json' } : undefined });
    if (response.status === 429) throw new SourceError('Rate limited by the source. Try again in a minute.');
    if (!response.ok) throw new SourceError(`The source responded with an error (${response.status}).`);
    return kind === 'json' ? await response.json() : await response.text();
  } catch (error) {
    if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
    if (error instanceof SourceError) throw error;
    if (isAbort(error)) throw new SourceError('Timed out before the source responded.');
    if (error instanceof TypeError) throw new SourceError('Not reachable from this browser (network error or the source blocks browser access).');
    throw new SourceError(error instanceof Error ? error.message : 'Unknown error.');
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener('abort', forward);
  }
}
export const getJson = <T,>(url: string, signal?: AbortSignal, timeoutMs?: number) => request(url, signal, 'json', timeoutMs) as Promise<T>;
export const getText = (url: string, signal?: AbortSignal, timeoutMs?: number) => request(url, signal, 'text', timeoutMs) as Promise<string>;

export function buildUrl(base: string, params: Record<string, string | string[]>): string {
  const url = new URL(base);
  for (const [key, value] of Object.entries(params)) {
    if (Array.isArray(value)) value.forEach(item => url.searchParams.append(key, item));
    else url.searchParams.set(key, value);
  }
  return url.toString();
}
const quoted = (name: string) => `"${name.replace(/"/g, '')}"`;
const orNames = (names: string[]) => names.length === 1 ? quoted(names[0]) : `(${names.map(quoted).join(' OR ')})`;
const isoDate = (value: unknown): string => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value) ? value.slice(0, 10) : '';
const onOrBefore = (date: string, cutoff: string) => !!date && date <= cutoff;
const compactDate = (ymd: string) => ymd.replace(/-/g, '');
export const stripHtml = (html: string): string => new DOMParser().parseFromString(html, 'text/html').body.textContent?.replace(/\s+/g, ' ').trim() ?? '';
const clean = (text: string) => text.replace(/<\/?mark>/g, '').replace(/\s+/g, ' ').trim();
const escapeRe = (text: string) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const OVERRIDE_TERMS = 'enjoined OR enjoin OR vacated OR vacate OR reversed OR overturned OR "struck down" OR "set aside" OR invalidated OR unlawful';

// ---------------------------------------------------------------- Court records
type CLResult = { caseName?: string; docket_absolute_url?: string; dateFiled?: string; court?: string; docketNumber?: string; absolute_url?: string; cluster_id?: number; docket_id?: number; suitNature?: string; opinions?: { snippet?: string }[]; recap_documents?: { description?: string; snippet?: string }[]; party?: string[] };
type CLResponse = { count?: number; results?: CLResult[] };

const courtlistener: Adapter = {
  key: 'courtlistener', name: 'CourtListener opinions', category: 'court',
  coverage: 'US federal and state court opinions (Free Law Project). Case captions and highlighted snippets only; full opinions open on CourtListener.',
  async run(ctx) {
    const caseName = orNames(ctx.searchNames);
    const base = 'https://www.courtlistener.com/api/rest/v4/search/';
    const common = { type: 'o', case_name: caseName, filed_before: ctx.cutoff, order_by: 'dateFiled desc', highlight: 'on' };
    const [all, overrides] = await Promise.all([
      getJson<CLResponse>(buildUrl(base, common), ctx.signal),
      getJson<CLResponse>(buildUrl(base, { ...common, q: OVERRIDE_TERMS }), ctx.signal),
    ]);
    const seen = new Set<number>();
    const toDoc = (result: CLResult, kind: string): Doc | null => {
      const id = result.cluster_id ?? 0;
      if (seen.has(id)) return null;
      seen.add(id);
      const date = isoDate(result.dateFiled);
      if (!onOrBefore(date, ctx.cutoff)) return null;
      const snippet = clean(result.opinions?.[0]?.snippet ?? '');
      const caseName = clean(result.caseName ?? 'Opinion');
      return { id: `cl-${id}`, source: 'courtlistener', sourceName: 'CourtListener', category: 'court', tier: 'primary', title: `${caseName} (${result.court ?? 'court'}, ${date})`, text: `${caseName}. ${snippet}`, url: `https://www.courtlistener.com${result.absolute_url ?? ''}`, date, dateBasis: 'date filed', issuer: 'external', kind, requireAlias: true, firstPerson: false, meta: { court: result.court ?? '', docket: result.docketNumber ?? '' } };
    };
    const docs = [...(overrides.results ?? []).map(result => toDoc(result, 'override')), ...(all.results ?? []).map(result => toDoc(result, 'opinion'))].filter((doc): doc is Doc => !!doc);
    return { docs, total: all.count ?? docs.length, query: `case name: ${caseName}, filed on or before ${ctx.cutoff}`, searchUrl: buildUrl('https://www.courtlistener.com/', { type: 'o', case_name: caseName, filed_before: ctx.cutoff, order_by: 'dateFiled desc' }), note: overrides.count ? `${overrides.count} of these opinions mention vacatur, reversal, injunction or similar terms.` : undefined };
  },
};

const recap: Adapter = {
  key: 'recap', name: 'PACER dockets (RECAP)', category: 'court',
  coverage: 'US federal court dockets collected by the RECAP project. Party names, courts and filing dates; documents open on CourtListener.',
  async run(ctx) {
    const party = orNames(ctx.searchNames);
    const data = await getJson<CLResponse>(buildUrl('https://www.courtlistener.com/api/rest/v4/search/', { type: 'r', party_name: party, filed_before: ctx.cutoff, order_by: 'dateFiled desc' }), ctx.signal);
    const docs = (data.results ?? []).slice(0, 12).map((result): Doc | null => {
      const date = isoDate(result.dateFiled);
      if (!onOrBefore(date, ctx.cutoff)) return null;
      const description = clean(result.recap_documents?.[0]?.description ?? '');
      const caseName = clean(result.caseName ?? 'Docket');
      const path = result.docket_absolute_url ?? result.absolute_url ?? '';
      if (!path) return null;
      return { id: `recap-${result.docket_id ?? result.docketNumber}`, source: 'recap', sourceName: 'RECAP dockets', category: 'court', tier: 'primary', title: `${caseName} (${result.court ?? 'court'}, ${date})`, text: `${caseName}. ${result.suitNature ? `Nature of suit: ${result.suitNature}. ` : ''}${description}`, url: `https://www.courtlistener.com${path}`, date, dateBasis: 'date filed', issuer: 'external', kind: 'docket', requireAlias: true, firstPerson: false, meta: { court: result.court ?? '', parties: (result.party ?? []).slice(0, 4).join('; ') } };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: data.count ?? docs.length, query: `party name: ${party}, filed on or before ${ctx.cutoff}`, searchUrl: buildUrl('https://www.courtlistener.com/', { type: 'r', party_name: party, filed_before: ctx.cutoff, order_by: 'dateFiled desc' }) };
  },
};

type SparqlBinding = Record<string, { value: string } | undefined>;
const wikidataCases: Adapter = {
  key: 'wikidata-cases', name: 'Wikidata legal cases', category: 'court',
  coverage: 'Legal cases worldwide recorded in Wikidata where the organization is a plaintiff, defendant or participant.',
  async run(ctx) {
    if (!ctx.qid) return { docs: [], total: 0, query: 'no Wikidata item', searchUrl: 'https://query.wikidata.org/', note: 'The organization has no Wikidata identifier, so structured case data could not be queried.' };
    const sparql = `SELECT ?case ?caseLabel ?date ?date2 ?courtLabel ?article WHERE { ?case wdt:P31/wdt:P279* wd:Q2334719 . ?case (wdt:P1591|wdt:P1620|wdt:P710) wd:${ctx.qid} . OPTIONAL { ?case wdt:P577 ?date } OPTIONAL { ?case wdt:P585 ?date2 } OPTIONAL { ?case wdt:P4884 ?court } OPTIONAL { ?article schema:about ?case ; schema:isPartOf <https://en.wikipedia.org/> } SERVICE wikibase:label { bd:serviceParam wikibase:language "en". } } LIMIT 40`;
    const data = await getJson<{ results?: { bindings?: SparqlBinding[] } }>(buildUrl('https://query.wikidata.org/sparql', { format: 'json', query: sparql }), ctx.signal);
    const docs = (data.results?.bindings ?? []).map((row): Doc | null => {
      const date = isoDate(row.date?.value) || isoDate(row.date2?.value);
      if (date && !onOrBefore(date, ctx.cutoff)) return null;
      const label = row.caseLabel?.value ?? 'Legal case';
      const court = row.courtLabel?.value ?? '';
      return { id: `wd-${row.case?.value ?? label}`, source: 'wikidata-cases', sourceName: 'Wikidata', category: 'court', tier: 'secondary', title: `${label}${court ? ` (${court})` : ''}`, text: `${label}. ${court ? `Court: ${court}. ` : ''}${ctx.name} was a party.`, url: row.article?.value ?? row.case?.value ?? 'https://www.wikidata.org/', date: date || '', dateBasis: date ? 'decision or publication date' : 'undated', issuer: 'external', kind: 'case', requireAlias: false, firstPerson: false };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: docs.length, query: `legal cases with ${ctx.qid} as a party`, searchUrl: `https://query.wikidata.org/#${encodeURIComponent(sparql)}` };
  },
};

type IAResponse = { response?: { numFound?: number; docs?: { identifier?: string; title?: string | string[]; date?: string; description?: string | string[]; creator?: string | string[] }[] } };
const first = (value: string | string[] | undefined) => Array.isArray(value) ? value[0] ?? '' : value ?? '';
function archiveAdapter(key: 'archive-courts' | 'archive-texts', name: string, category: Category, tier: Tier, collection: string, coverage: string): Adapter {
  return {
    key, name, category, coverage,
    async run(ctx) {
      const query = `${orNames(ctx.searchNames)} AND ${collection}`;
      const url = buildUrl('https://archive.org/advancedsearch.php', { q: query, 'fl[]': ['identifier', 'title', 'date', 'description', 'creator'], rows: '10', 'sort[]': 'date desc', output: 'json' });
      const data = await getJson<IAResponse>(url, ctx.signal);
      const docs = (data.response?.docs ?? []).map((item): Doc | null => {
        const date = isoDate(item.date);
        if (!onOrBefore(date, ctx.cutoff)) return null;
        const title = first(item.title) || item.identifier || 'Archived item';
        return { id: `ia-${item.identifier}`, source: key, sourceName: 'Internet Archive', category, tier, title, text: `${title}. ${stripHtml(first(item.description)).slice(0, 1200)}`, url: `https://archive.org/details/${item.identifier}`, date, dateBasis: 'item date', issuer: 'unknown', kind: key === 'archive-courts' ? 'docket' : 'text', requireAlias: true, firstPerson: false, meta: { creator: first(item.creator) } };
      }).filter((doc): doc is Doc => !!doc);
      return { docs, total: data.response?.numFound ?? docs.length, query, searchUrl: buildUrl('https://archive.org/search', { query }) };
    },
  };
}
const archiveCourts = archiveAdapter('archive-courts', 'Internet Archive court filings', 'court', 'primary', 'collection:usfederalcourts', 'Federal court filings mirrored from PACER into the Internet Archive (RECAP collection). Titles, dates and descriptions.');
const archiveTexts = archiveAdapter('archive-texts', 'Internet Archive texts', 'archive', 'secondary', 'mediatype:texts', 'Books, reports and government documents in the Internet Archive that mention the organization. Titles and descriptions only.');

// ---------------------------------------------------------- Legislative & regulatory
type FRDoc = { title?: string; type?: string; agencies?: { name?: string; raw_name?: string }[]; publication_date?: string; effective_on?: string | null; html_url?: string; abstract?: string | null; document_number?: string };
const federalRegister: Adapter = {
  key: 'federal-register', name: 'Federal Register', category: 'legislative',
  coverage: 'US federal rules, proposed rules, notices and presidential documents since 1994. Titles and abstracts; the issuing agency is recorded.',
  async run(ctx) {
    const term = orNames(ctx.searchNames);
    const url = buildUrl('https://www.federalregister.gov/api/v1/documents.json', { 'conditions[term]': term, 'conditions[publication_date][lte]': ctx.cutoff, per_page: '20', order: 'newest', 'fields[]': ['title', 'type', 'agencies', 'publication_date', 'effective_on', 'html_url', 'abstract', 'document_number'] });
    const data = await getJson<{ count?: number; results?: FRDoc[] }>(url, ctx.signal);
    const docs = (data.results ?? []).map((item): Doc | null => {
      const date = isoDate(item.publication_date);
      if (!onOrBefore(date, ctx.cutoff)) return null;
      const agencies = (item.agencies ?? []).map(agency => agency.name || agency.raw_name || '').filter(Boolean);
      const issuer = agencies.some(agency => ctx.aliasRe.test(agency)) ? 'entity' : 'external';
      return { id: `fr-${item.document_number}`, source: 'federal-register', sourceName: 'Federal Register', category: 'legislative', tier: 'primary', title: `${item.title ?? 'Document'} (${item.type ?? 'document'}, ${date})`, text: `${item.title ?? ''}. ${item.abstract ?? ''}`, url: item.html_url ?? 'https://www.federalregister.gov/', date, dateBasis: 'publication date', issuer, kind: (item.type ?? 'document').toLowerCase(), requireAlias: issuer !== 'entity', firstPerson: issuer === 'entity', meta: { agencies: agencies.join('; '), effective: isoDate(item.effective_on) } };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: data.count ?? docs.length, query: `${term}, published on or before ${ctx.cutoff}`, searchUrl: buildUrl('https://www.federalregister.gov/documents/search', { 'conditions[term]': term, 'conditions[publication_date][lte]': ctx.cutoff }) };
  },
};

type GovTrackBill = { id?: number; title?: string; current_status?: string; current_status_label?: string; current_status_date?: string; introduced_date?: string; link?: string; display_number?: string };
const govtrack: Adapter = {
  key: 'govtrack', name: 'US Congress bills (GovTrack)', category: 'legislative',
  coverage: 'Bills and resolutions in the US Congress since 1973 that mention the organization. Titles and status only, not bill text.',
  async run(ctx) {
    const query = orNames(ctx.searchNames);
    const data = await getJson<{ meta?: { total_count?: number }; objects?: GovTrackBill[] }>(buildUrl('https://www.govtrack.us/api/v2/bill', { q: query, sort: '-introduced_date', limit: '15' }), ctx.signal);
    const docs = (data.objects ?? []).map((bill): Doc | null => {
      const introduced = isoDate(bill.introduced_date);
      if (!onOrBefore(introduced, ctx.cutoff)) return null;
      const statusDate = isoDate(bill.current_status_date);
      const date = statusDate && statusDate <= ctx.cutoff ? statusDate : introduced;
      const link = bill.link ?? '';
      return { id: `gt-${bill.id}`, source: 'govtrack', sourceName: 'GovTrack', category: 'legislative', tier: 'primary', title: `${bill.title ?? 'Bill'} (${bill.current_status_label ?? 'status unknown'}, ${date})`, text: `${bill.title ?? ''}. Status: ${bill.current_status_label ?? 'unknown'}.`, url: link.startsWith('http') ? link : `https://www.govtrack.us${link}`, date, dateBasis: statusDate && statusDate <= ctx.cutoff ? 'status date' : 'introduced date', issuer: 'external', kind: bill.current_status ?? 'bill', requireAlias: true, firstPerson: false };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: data.meta?.total_count ?? docs.length, query, searchUrl: buildUrl('https://www.govtrack.us/congress/bills/browse', { text: ctx.searchNames[0] }) };
  },
};

const legislationUk: Adapter = {
  key: 'legislation-uk', name: 'UK legislation.gov.uk', category: 'legislative',
  coverage: 'UK primary and secondary legislation whose text mentions the organization. Titles and enactment years.',
  async run(ctx) {
    const text = quoted(ctx.searchNames[0]);
    const feedUrl = buildUrl('https://www.legislation.gov.uk/all/data.feed', { text });
    const xml = new DOMParser().parseFromString(await getText(feedUrl, ctx.signal), 'application/xml');
    if (xml.getElementsByTagName('parsererror').length) throw new SourceError('The legislation feed could not be read.');
    const morePages = Number(xml.getElementsByTagNameNS('http://www.legislation.gov.uk/namespaces/legislation', 'morePages')[0]?.textContent ?? '') || 0;
    const docs = Array.from(xml.getElementsByTagName('entry')).slice(0, 15).map((entry, index): Doc | null => {
      const title = entry.getElementsByTagName('title')[0]?.textContent?.trim() ?? 'Legislation';
      const id = entry.getElementsByTagName('id')[0]?.textContent?.trim() ?? '';
      const link = Array.from(entry.getElementsByTagName('link')).find(item => !item.getAttribute('rel') || item.getAttribute('rel') === 'alternate')?.getAttribute('href') ?? id;
      const year = id.match(/\/(\d{4})\//)?.[1] ?? title.match(/\b(19|20)\d{2}\b/)?.[0];
      const date = year ? `${year}-01-01` : '';
      if (!date || !onOrBefore(date, ctx.cutoff)) return null;
      return { id: `uk-${index}-${id}`, source: 'legislation-uk', sourceName: 'legislation.gov.uk', category: 'legislative', tier: 'primary', title, text: `${title}.`, url: link.replace(/^http:/, 'https:'), date, dateBasis: 'legislation year (1 January used as the earliest possible date)', issuer: 'external', kind: 'legislation', requireAlias: true, firstPerson: false };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: null, query: `text contains ${text}`, searchUrl: buildUrl('https://www.legislation.gov.uk/all', { text }), note: morePages > 1 ? `${morePages} pages of results exist; the first page was read.` : docs.length ? 'Single page of results; all were read.' : undefined };
  },
};

// ------------------------------------------------------------------------ News
type GdeltArticle = { url?: string; title?: string; seendate?: string; domain?: string; language?: string };
const gdelt: Adapter = {
  key: 'gdelt', name: 'GDELT global news', category: 'news',
  coverage: 'Headlines from online news worldwide monitored by the GDELT Project since 2017. GDELT rate-limits requests and may be unavailable.',
  async run(ctx) {
    const start = new Date(`${ctx.cutoff}T00:00:00Z`);
    start.setUTCFullYear(start.getUTCFullYear() - 3);
    const startStamp = `${compactDate(start.toISOString().slice(0, 10))}000000`;
    const query = `${quoted(ctx.searchNames[0])} sourcelang:english`;
    const url = buildUrl('https://api.gdeltproject.org/api/v2/doc/doc', { query, mode: 'artlist', maxrecords: '25', format: 'json', startdatetime: startStamp < '20170101000000' ? '20170101000000' : startStamp, enddatetime: `${compactDate(ctx.cutoff)}235959` });
    const data = await getJson<{ articles?: GdeltArticle[] }>(url, ctx.signal, 9000);
    const docs = (data.articles ?? []).map((article, index): Doc | null => {
      const stamp = article.seendate ?? '';
      const date = stamp.length >= 8 ? `${stamp.slice(0, 4)}-${stamp.slice(4, 6)}-${stamp.slice(6, 8)}` : '';
      if (!onOrBefore(date, ctx.cutoff) || !article.url) return null;
      return { id: `gdelt-${index}`, source: 'gdelt', sourceName: 'GDELT', category: 'news', tier: 'secondary', title: `${article.title ?? 'Article'} (${article.domain ?? 'news'}, ${date})`, text: article.title ?? '', url: article.url, date, dateBasis: 'date first seen by GDELT', issuer: 'external', kind: 'headline', requireAlias: true, firstPerson: false, meta: { domain: article.domain ?? '' } };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: docs.length, query, searchUrl: url, note: 'Headlines only. Open the article to verify.' };
  },
};

type WikiSearch = { query?: { searchinfo?: { totalhits?: number }; search?: { title?: string; snippet?: string; timestamp?: string; pageid?: number }[] } };
const wikinews: Adapter = {
  key: 'wikinews', name: 'Wikinews', category: 'news',
  coverage: 'English Wikinews articles (volunteer-written, dated by page revision) that mention the organization.',
  async run(ctx) {
    const term = quoted(ctx.searchNames[0]);
    const data = await getJson<WikiSearch>(buildUrl('https://en.wikinews.org/w/api.php', { action: 'query', list: 'search', srsearch: term, srlimit: '15', srprop: 'snippet|timestamp', format: 'json', formatversion: '2', origin: '*' }), ctx.signal);
    const docs = (data.query?.search ?? []).map((item): Doc | null => {
      const date = isoDate(item.timestamp);
      if (!onOrBefore(date, ctx.cutoff)) return null;
      const title = item.title ?? 'Article';
      return { id: `wn-${item.pageid}`, source: 'wikinews', sourceName: 'Wikinews', category: 'news', tier: 'secondary', title: `${title} (Wikinews, ${date})`, text: `${title}. ${stripHtml(item.snippet ?? '')}`, url: `https://en.wikinews.org/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`, date, dateBasis: 'page revision date', issuer: 'external', kind: 'article', requireAlias: true, firstPerson: false };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: data.query?.searchinfo?.totalhits ?? docs.length, query: term, searchUrl: buildUrl('https://en.wikinews.org/w/index.php', { search: term, ns0: '1' }) };
  },
};

// --------------------------------------------------------------------- Archives
type WikisourcePage = { pageid?: number; title?: string; extract?: string; fullurl?: string; revisions?: { timestamp?: string }[] };
const wikisource: Adapter = {
  key: 'wikisource', name: 'Wikisource documents', category: 'archive',
  coverage: 'Transcribed primary documents on English Wikisource (statutes, treaties, charters, official statements) that mention the organization. Up to three documents are read in full.',
  async run(ctx) {
    const term = quoted(ctx.searchNames[0]);
    const search = await getJson<WikiSearch>(buildUrl('https://en.wikisource.org/w/api.php', { action: 'query', list: 'search', srsearch: term, srlimit: '3', srprop: 'timestamp', format: 'json', formatversion: '2', origin: '*' }), ctx.signal);
    const titles = (search.query?.search ?? []).map(item => item.title).filter((title): title is string => !!title);
    const pages = await Promise.all(titles.map(async title => {
      const data = await getJson<{ query?: { pages?: WikisourcePage[] } }>(buildUrl('https://en.wikisource.org/w/api.php', { action: 'query', prop: 'extracts|revisions|info', titles: title, explaintext: '1', exchars: '9000', rvprop: 'timestamp', inprop: 'url', format: 'json', formatversion: '2', origin: '*' }), ctx.signal);
      return data.query?.pages?.[0];
    }));
    const docs = pages.map((page): Doc | null => {
      if (!page?.extract) return null;
      const date = isoDate(page.revisions?.[0]?.timestamp);
      if (!onOrBefore(date, ctx.cutoff)) return null;
      return { id: `ws-${page.pageid}`, source: 'wikisource', sourceName: 'Wikisource', category: 'archive', tier: 'primary', title: page.title ?? 'Document', text: page.extract, url: page.fullurl ?? 'https://en.wikisource.org/', date, dateBasis: 'transcription revision date (the document itself may be older)', issuer: 'unknown', kind: 'document', requireAlias: true, firstPerson: false };
    }).filter((doc): doc is Doc => !!doc);
    return { docs, total: search.query?.searchinfo?.totalhits ?? docs.length, query: term, searchUrl: buildUrl('https://en.wikisource.org/w/index.php', { search: term, ns0: '1' }) };
  },
};

type Closest = { available?: boolean; url?: string; timestamp?: string; status?: string };
type WaybackAvailable = { archived_snapshots?: { closest?: Closest } };
export const POLICY_PAGE = /(terms|\btos\b|policy|policies|enforcement|complian|appeal|complaint|dispute|governance|constitution|by-?laws|\brules\b|regulation|sanction|legal|conduct|community-?(standards|guidelines)|standards|charter|statute|mandate|accountability|oversight|transparency|privacy|guidelines)/i;
export const ABOUT_PAGE = /\/about(?:-us|-who)?\/?(?:$|[?#])|\/(?:who-we-are|what-we-do|mission|governance)\b/i;
async function nearestCapture(url: string, cutoff: string, signal?: AbortSignal): Promise<{ url: string; date: string } | null> {
  // The availability API is unreliable with scheme-prefixed URLs (verified: 'who.int' finds captures where 'https://www.who.int' returns nothing).
  const bare = url.replace(/^https?:\/\//, '').replace(/^www\./, '');
  const lookup = async (stamp: string) => (await getJson<WaybackAvailable>(buildUrl('https://archive.org/wayback/available', { url: bare, timestamp: stamp }), signal, 12000)).archived_snapshots?.closest;
  const accept = (closest: Closest | undefined) => {
    const stamp = closest?.timestamp ?? '';
    if (!closest?.available || !closest.url || stamp.length < 8) return null;
    const date = `${stamp.slice(0, 4)}-${stamp.slice(4, 6)}-${stamp.slice(6, 8)}`;
    return date <= cutoff ? { url: closest.url.replace(/^http:/, 'https:'), date } : null;
  };
  const direct = accept(await lookup(compactDate(cutoff)));
  if (direct) return direct;
  const earlier = new Date(`${cutoff}T00:00:00Z`);
  earlier.setUTCFullYear(earlier.getUTCFullYear() - 1);
  return accept(await lookup(compactDate(earlier.toISOString().slice(0, 10))));
}
const wayback: Adapter = {
  key: 'wayback', name: 'Wayback Machine (official pages)', category: 'official',
  coverage: 'The organization’s own website and policy pages, dated by their nearest archived capture on or before the cutoff. Browsers cannot read archived page text, so these pages are listed for review with a verifiable date.',
  async run(ctx) {
    const targets = Array.from(new Set([ctx.officialSite, ...ctx.candidatePages].filter(Boolean))).slice(0, 7);
    if (!targets.length) return { docs: [], total: 0, query: 'no official website recorded', searchUrl: 'https://web.archive.org/', note: 'Wikidata lists no official website for this organization.' };
    // Sequential lookups: parallel bursts trip archive.org throttling and silently lose captures.
    const results: { target: string; capture: { url: string; date: string } | null; failed: boolean }[] = [];
    for (const target of targets) {
      try { results.push({ target, capture: await nearestCapture(target, ctx.cutoff, ctx.signal), failed: false }); }
      catch (error) { if (isAbort(error)) throw error; results.push({ target, capture: null, failed: true }); }
    }
    const docs = results.flatMap(({ target, capture }): Doc[] => capture ? [{ id: `wb-${target}`, source: 'wayback', sourceName: 'Wayback Machine', category: 'official', tier: 'primary', title: target.replace(/^https?:\/\//, ''), text: '', url: capture.url, date: capture.date, dateBasis: 'archive capture date (the page existed no later than this date)', issuer: 'entity', kind: 'page', requireAlias: false, firstPerson: true, meta: { original: target } }] : []);
    const missing = results.filter(item => !item.capture && !item.failed).length;
    const failed = results.filter(item => item.failed).length;
    const notes = [missing ? `${missing} page${missing === 1 ? '' : 's'} had no capture on or before the cutoff.` : '', failed ? `${failed} lookup${failed === 1 ? '' : 's'} failed (archive service busy) — not proof the pages are unarchived.` : ''].filter(Boolean).join(' ');
    return { docs, total: targets.length, query: `${targets.length} page${targets.length === 1 ? '' : 's'} checked for captures on or before ${ctx.cutoff}`, searchUrl: `https://web.archive.org/web/*/${ctx.officialSite || targets[0]}`, note: notes || undefined };
  },
};

export const ADAPTERS: Adapter[] = [courtlistener, recap, wikidataCases, archiveCourts, federalRegister, govtrack, legislationUk, gdelt, wikinews, wikisource, archiveTexts, wayback];
export const CATEGORY_ORDER: Category[] = ['encyclopedic', 'official', 'court', 'legislative', 'news', 'archive'];

export function aliasPattern(names: string[], options: { generic?: boolean; firstPerson?: boolean } = {}): RegExp {
  const specific = Array.from(new Set(names.map(name => name.trim()).filter(name => name.length >= 3))).map(escapeRe);
  const parts = [...specific];
  if (options.generic !== false) parts.push('it', 'its', 'the (?:organi[sz]ation|agency|company|corporation|bank|board|committee|council|library|platform|system|institution|body|authority|association|foundation|archive|service|network|union|fed|firm|group|commission|department|ministry|office|bureau|court|university)');
  if (options.firstPerson) parts.push('we', 'our', 'us');
  return new RegExp(`\\b(?:${parts.join('|')})\\b`, 'i');
}
