import { blankBadge, provisionalBadge, type ProvisionalBadge } from './badge';

export type Version = '1.0' | '1.1';
export type Phase = 'NAB' | 'CWO' | 'NAB-Constrained' | 'GSRB' | 'AMBIGUOUS' | 'INCOHERENT';
export type Confidence = 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
export type Answer = { value: boolean | null; source: string; date: string; notes: string; gap: string };
export type Evidence = { id: string; title: string; url: string; published: string; retrieved: string; claim: string; codes: string[]; entity: string };
export type PDHResult = { status: 'VALID' | 'INVALID' | 'MISSING'; structural: boolean; signature: boolean; freshness: boolean; consistency: boolean; declared: 'NAB' | 'CWO' | 'GSRB' | 'NONE'; reason: string; headerId?: string; payload?: string; effectiveTimestamp?: string };
export type B4Record = { actor: string; action: string; procedure: string; basis: string; numerator: string; denominator: string; complete: boolean; start: string; end: string };
export type C2Record = { route: boolean; invoked: boolean; complete: boolean; numerator: string; denominator: string; start: string; end: string };
export type ExternalRecord = { exists: boolean; exercised: boolean; holder: string; scope: string; source: string; date: string };
export type DecrementRecord = { enabled: boolean; oldSource: string; newSource: string; oldDate: string; newDate: string; notes: string };
export type AuditInput = { name: string; identifier: string; version: Version; cutoff: string; answers: Answer[]; constraints: Answer[]; b4: B4Record; c2: C2Record; external: ExternalRecord; decrement: DecrementRecord; headerText: string; publicKeyText: string; trustedOrigin: string };
export type Transition = { from: Phase; to: Phase; fromDate: string; toDate: string; status: string; pattern: string; severity: string; entryId: string; notes: string };
export type CoverageEntry = { key: string; name: string; category: string; status: 'searched' | 'no-results' | 'unavailable' | 'skipped'; total: number | null; used: number; query: string; searchUrl: string; coverage: string; note?: string; ms: number };
export type ReviewPage = { title: string; url: string; date: string; dateBasis: string; original: string };
export type AutomationMeta = { ruleSet: string; subject: string; description: string; reviewed: boolean; sources: { name: string; url: string; revision: string; published: string; retrieved: string; role: string }[]; warnings: string[]; coverage?: CoverageEntry[]; primaryPages?: ReviewPage[]; notCovered?: string[]; documentsChecked?: number; sentencesChecked?: number };
export type AuditRecord = { input?: AuditInput; method?: 'manual' | 'automatic'; automation?: AutomationMeta; provisionalBadge?: ProvisionalBadge; id: string; name: string; identifier: string; version: Version; createdAt: string; cutoff: string; reportedDeclared: string; phase: Phase; confidence: Confidence; severity: string; compliance: string; badge: string; status: 'Complete' | 'Needs review' | 'Draft'; baseline: boolean; evidence: Evidence[]; answers: Answer[]; constraints: Answer[]; pdh: PDHResult; finding: string; replicationRisk: string; temporalPattern: string; transition: Transition | null; report: Record<string, unknown> };

export const CENTER_ORIGIN = '0•000•000•0000';
export const emptyAnswer = (): Answer => ({ value: null, source: '', date: '', notes: '', gap: '' });
export const today = () => new Date().toISOString().slice(0, 10);
export const newInput = (version: Version = '1.0'): AuditInput => ({
  name: '', identifier: '', version, cutoff: today(), answers: Array.from({ length: 5 }, emptyAnswer), constraints: Array.from({ length: 4 }, emptyAnswer),
  b4: { actor: '', action: '', procedure: '', basis: 'NOT_DEMONSTRATED', numerator: '', denominator: '', complete: false, start: '', end: '' },
  c2: { route: false, invoked: false, complete: false, numerator: '', denominator: '', start: '', end: '' },
  external: { exists: false, exercised: false, holder: '', scope: '', source: '', date: '' },
  decrement: { enabled: false, oldSource: '', newSource: '', oldDate: '', newDate: '', notes: '' },
  headerText: '', publicKeyText: '', trustedOrigin: CENTER_ORIGIN,
});

export const questions = [
  { code: 'B1', title: 'Can compliance be coerced?', short: 'Coercion', variable: 'enforcement_present', description: 'Does the entity impose penalties, access restrictions, funding cuts, or other negative consequences for not following its directives?', examples: 'Funding conditions, license revocation, access restrictions, fines, termination, or documented enforcement.' },
  { code: 'B2', title: 'Can decisions be ignored without consequence?', short: 'Optional decisions', variable: 'decisions_optional', description: 'Can an affected entity proceed without penalty when it does not follow an institutional decision or directive?', examples: 'Advisory or voluntary decisions, non-binding public statements, or documented non-compliance without penalty.' },
  { code: 'B3', title: 'Do rules activate real-world effects?', short: 'Executable rules', variable: 'rules_execute', description: 'Do guidance, policies, or directives cause observable downstream changes in behavior, enforcement, or resource allocation?', examples: 'Implemented policies, rules embedded in law or contracts, operational changes, or a documented real-world cascade.' },
  { code: 'B4', title: 'Does refusal or appeal reliably stop action?', short: 'Terminal refusal', variable: 'refusal_terminal', description: 'Is there an evidenced mechanism through which refusal or appeal reliably halts the specified institutional action?', examples: 'v1.0: formal appeals, successful court review, legislative override, or penalty-free exit. v1.1: an operative terminal/stay rule, a complete ≥50% relief record, or a binding no-penalty exit; external orders alone do not qualify.' },
  { code: 'B5', title: 'Do rules persist by default over time?', short: 'Persistent authority', variable: 'authority_persists', description: 'Does a decision remain in effect until actively changed, rather than automatically expiring and requiring renewal?', examples: 'No sunset clause, policies effective until repealed, historic decisions still in force, or a burden on repeal rather than renewal.' },
];

export const constraintQuestions = [
  { code: 'C1', title: 'External override demonstrated', description: 'A legislature, court, or external body has actually overridden or repealed the entity’s decision within the preceding 24 months.' },
  { code: 'C2', title: 'Appeal mechanism active & invoked', description: 'A published, accessible appeal route actually grants relief. In v1.1, a complete, bounded set of resolved outcomes must show at least 50% relief.' },
  { code: 'C3', title: 'Authority has a sunset requirement', description: 'Decisions automatically expire or require periodic renewal, demonstrated by sunset clauses, budget renewals, term limits, or expiry dates.' },
  { code: 'C4', title: 'Constraints are functioning now', description: 'Current constraint mechanisms are active, with demonstrated functioning or qualifying actions within the preceding 12 months.' },
];

export const phaseDefinitions = [
  { phase: 'NAB' as Phase, name: 'Neural Atomic Body', category: 'Refusal-bound', icon: 'cube', color: 'sage', symbol: '🧊', description: 'Authority is borrowed, never assumed.', characteristics: ['External, per-action legitimacy', 'The center cannot act independently', 'Refusal is terminal', 'Symbolism is non-executable', 'Time degrades authority'], examples: 'Advisory bodies without execution power, refusal-gated systems, and custodial archives with refusal capability.', fields: ['Non-Acting', 'External', 'Terminal', 'Disabled', 'Degrades'], vector: [false, true, false, true, false] },
  { phase: 'CWO' as Phase, name: 'Custodial Witness Orb', category: 'Witness-only', icon: 'droplet', color: 'blue', symbol: '💧', description: 'It preserves the record, not the power.', characteristics: ['Action and execution are forbidden', 'The center records but never decides', 'Symbolism is preserved but inert', 'Time accumulates meaning, not authority', 'Legitimacy is observed, not created'], examples: 'Archives, historians, record-keepers, and observation-only auditors.', fields: ['Custodial', 'Observed-Only', 'Expository', 'Disabled or Archived', 'Neutral'], vector: [false, true, false, null, false] },
  { phase: 'NAB-Constrained' as Phase, name: 'Legislatively constrained NAB', category: 'Externally accountable', icon: 'cube-plus', color: 'amber', symbol: '🧊+', description: 'Real power, bounded by demonstrable checks.', characteristics: ['External authority can override', 'Decisions can be repealed or reversed', 'Appeal mechanisms are functional', 'Authority requires renewal', 'All four C criteria must be demonstrated'], examples: 'Agencies subject to functional court review, legislatively checked institutions, and boards with demonstrable term limits.', fields: ['NAB variant', 'External oversight', 'Functional appeals', 'All C1–C4 required', 'Sunset / renewal'], vector: null },
  { phase: 'GSRB' as Phase, name: 'God-Sovereign Religious Body', category: 'Sovereign-acting', icon: 'cloud', color: 'peach', symbol: '🌫', description: 'The center authorizes itself and acts.', characteristics: ['Legitimacy is internal and self-authorizing', 'The center acts and decides', 'Refusal is override-able', 'Symbolism has operational effects', 'Time confirms authority'], examples: 'The framework’s sovereign-acting category: institutions, platforms, or systems with self-authorizing execution and enforcement.', fields: ['Acting', 'Internal', 'Override-able', 'Enabled', 'Confirms'], vector: [true, false, true, false, true] },
];

export function classify(vector: boolean[]): { phase: Phase; confidence: Confidence; matches: number[] } {
  const branches: (boolean | null)[][] = [[false, true, false, true, false], [false, true, false, null, false], [true, false, true, false, true]];
  const matches = branches.map(branch => branch.reduce<number>((total, condition, i) => total + (condition !== null && vector[i] === condition ? 1 : 0), 0));
  const sizes = [5, 4, 5];
  const complete = matches.findIndex((n, i) => n === sizes[i]);
  if (complete !== -1) return { phase: (['NAB', 'CWO', 'GSRB'] as Phase[])[complete], confidence: 'HIGH', matches };
  if (matches.some(n => n >= 3)) return { phase: 'AMBIGUOUS', confidence: matches.some((n, i) => n === sizes[i] - 1) ? 'MEDIUM' : 'LOW', matches };
  return { phase: 'INCOHERENT', confidence: 'LOW', matches };
}

export const isPublicUrl = (value: string): boolean => {
  try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) && !!url.hostname && !['localhost', '127.0.0.1'].includes(url.hostname); } catch { return false; }
};
export function beforeCutoff(date: string, cutoff: string): boolean {
  const timestamp = Date.parse(date);
  return !!date && Number.isFinite(timestamp) && timestamp <= Date.parse(`${cutoff}T23:59:59.999Z`);
}
export function qualifies(answer: Answer, cutoff: string): boolean { return isPublicUrl(answer.source) && beforeCutoff(answer.date, cutoff) && answer.notes.trim().length >= 5; }
function withinMonths(date: string, cutoff: string, months: number): boolean {
  const start = new Date(`${cutoff}T00:00:00Z`); start.setUTCMonth(start.getUTCMonth() - months);
  return beforeCutoff(date, cutoff) && Date.parse(date) >= start.getTime();
}
function reliefQualifies(numerator: string, denominator: string, complete: boolean, start: string, end: string, cutoff: string): boolean {
  const n = Number(numerator), d = Number(denominator);
  return complete && numerator !== '' && denominator !== '' && Number.isInteger(n) && Number.isInteger(d) && d > 0 && n >= 0 && n <= d && n / d >= 0.5 && beforeCutoff(start, cutoff) && beforeCutoff(end, cutoff) && Date.parse(start) <= Date.parse(end);
}
export function b4Qualifies(input: AuditInput): boolean {
  const b = input.b4;
  if (!qualifies(input.answers[3], input.cutoff) || !b.actor.trim() || !b.action.trim() || !b.procedure.trim()) return false;
  if (b.basis === 'TERMINAL_RULE' || b.basis === 'NO_PENALTY_EXIT') return true;
  return b.basis === 'RESOLVED_APPEALS' && reliefQualifies(b.numerator, b.denominator, b.complete, b.start, b.end, input.cutoff);
}
export function scoredVector(input: AuditInput): boolean[] {
  return input.answers.map((answer, i) => {
    if (input.version === '1.0') return answer.value === true;
    return answer.value === true && qualifies(answer, input.cutoff) && (i !== 3 || b4Qualifies(input));
  });
}
export function scoredConstraints(input: AuditInput): boolean[] {
  return input.constraints.map((answer, i) => {
    if (answer.value !== true || !qualifies(answer, input.cutoff)) return false;
    if (i === 0 && !withinMonths(answer.date, input.cutoff, 24)) return false;
    if (i === 3 && !withinMonths(answer.date, input.cutoff, 12)) return false;
    if (i === 1 && input.version === '1.1') return input.c2.route && input.c2.invoked && reliefQualifies(input.c2.numerator, input.c2.denominator, input.c2.complete, input.c2.start, input.c2.end, input.cutoff);
    return true;
  });
}

const requiredFields = ['Header-ID', 'Creator-ID', 'Center-Origin', 'Declared-Phase', 'Center-Capability', 'Legitimacy-Source', 'Refusal-Semantics', 'Symbolism-Executability', 'Time-Authority-Effect', 'Effective-Timestamp', 'Declaration-Hash'];
export const headerExample = JSON.stringify({ 'Header-ID': 'PDH-2026-09-12-00001', 'Creator-ID': 'ꔧIDꔧENTITY-001(ENTITY-001)', 'Center-Origin': CENTER_ORIGIN, 'Declared-Phase': 'NAB', 'Center-Capability': 'Non-Acting', 'Legitimacy-Source': 'External', 'Refusal-Semantics': 'Terminal', 'Symbolism-Executability': 'Disabled', 'Time-Authority-Effect': 'Degrades', 'Effective-Timestamp': '2026-09-12T00:00:00Z', 'Declaration-Hash': 'BASE64URL_SIGNATURE' }, null, 2);
export function canonicalHeader(header: Record<string, unknown>): string {
  return JSON.stringify(Object.fromEntries(requiredFields.filter(field => field !== 'Declaration-Hash').sort().map(field => [field, header[field]])));
}
const missingPDH = (): PDHResult => ({ status: 'MISSING', structural: false, signature: false, freshness: false, consistency: false, declared: 'NONE', reason: 'No Phase Declaration Header supplied. Behavioral detection may proceed; no phase badge can be issued.' });
export async function validatePDH(input: AuditInput): Promise<PDHResult> {
  if (!input.headerText.trim()) return missingPDH();
  const result: PDHResult = { status: 'INVALID', structural: false, signature: false, freshness: false, consistency: false, declared: 'NONE', reason: '' };
  let header: Record<string, unknown>;
  try { header = JSON.parse(input.headerText); if (!header || typeof header !== 'object' || Array.isArray(header)) throw new Error(); }
  catch { return { ...result, reason: 'NO_VALID_PDH: The header must be a JSON object containing the 11 required fields.' }; }
  const creator = String(header['Creator-ID'] ?? '').match(/^ꔧIDꔧ\s*([^()]+)\s*\(([^()]+)\)$/);
  const validCreator = !!creator && creator[1].trim() === creator[2].trim() && (!input.identifier.trim() || creator[1].trim() === input.identifier.trim());
  const phase = header['Declared-Phase'];
  result.headerId = String(header['Header-ID'] ?? '');
  result.effectiveTimestamp = String(header['Effective-Timestamp'] ?? '');
  result.payload = canonicalHeader(header);
  result.structural = requiredFields.every(field => typeof header[field] === 'string' && String(header[field]).trim().length > 0) && /^PDH-\d{4}-\d{2}-\d{2}-[A-Za-z0-9]{5}$/.test(String(header['Header-ID'])) && validCreator && ['NAB', 'CWO', 'GSRB'].includes(String(phase)) && /^\d{4}-\d{2}-\d{2}T/.test(String(header['Effective-Timestamp'])) && Number.isFinite(Date.parse(String(header['Effective-Timestamp']))) && !!String(header['Center-Origin']).trim();
  if (!result.structural) return { ...result, reason: 'NO_VALID_PDH: A required field is missing or malformed. Creator IDs must match each other and the entity identifier.' };
  const delta = Date.parse(`${input.cutoff}T23:59:59.999Z`) - Date.parse(String(header['Effective-Timestamp']));
  result.freshness = delta >= 0 && delta <= 90 * 86400000;
  const phaseDef = phaseDefinitions.find(def => def.phase === phase);
  const fieldNames = ['Center-Capability', 'Legitimacy-Source', 'Refusal-Semantics', 'Symbolism-Executability', 'Time-Authority-Effect'];
  result.consistency = !!phaseDef && fieldNames.every((field, i) => phase === 'CWO' && i === 3 ? ['Disabled', 'Archived'].includes(String(header[field])) : String(header[field]) === phaseDef.fields[i]);
  if (input.publicKeyText.trim() && input.trustedOrigin.trim() === header['Center-Origin']) {
    try {
      const jwk = JSON.parse(input.publicKeyText) as JsonWebKey;
      if (jwk.kty !== 'EC' || jwk.crv !== 'P-256' || jwk.d) throw new Error('A public P-256 key is required');
      const key = await crypto.subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      const base64 = String(header['Declaration-Hash']).replace(/-/g, '+').replace(/_/g, '/');
      const raw = atob(base64);
      const signature = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) signature[i] = raw.charCodeAt(i);
      result.signature = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, signature, new TextEncoder().encode(canonicalHeader(header)));
    } catch { result.signature = false; }
  }
  if (!result.signature) result.reason = 'UNSIGNED_PDH: No verifiable signature against a trusted Center-Origin key. A non-empty hash alone is not proof of a signature.';
  else if (!result.freshness) result.reason = 'STALE_PDH: The effective timestamp is future-dated or more than 90 days before the evidence cutoff; revalidation is required.';
  else if (!result.consistency) result.reason = 'INCOHERENT_PDH: Field values contradict the declared phase.';
  else { result.status = 'VALID'; result.declared = phase as PDHResult['declared']; result.reason = 'Complete, signed against the supplied trusted origin key, fresh, and internally consistent.'; }
  return result;
}

export async function createAudit(input: AuditInput, existing: AuditRecord[]): Promise<AuditRecord> {
  const pdh = await validatePDH(input);
  if (pdh.status === 'VALID' && existing.some(a => !a.baseline && a.pdh.headerId === pdh.headerId && a.pdh.payload !== pdh.payload)) {
    pdh.status = 'INVALID'; pdh.structural = false; pdh.declared = 'NONE';
    pdh.reason = 'NO_VALID_PDH: This Header-ID is already bound to different declaration fields in the local workspace.';
  }
  const vector = scoredVector(input);
  const initial = classify(vector);
  const constraints = scoredConstraints(input);
  let phase = initial.phase;
  let confidence = initial.confidence;
  if (phase === 'AMBIGUOUS' && constraints.every(Boolean)) { phase = 'NAB-Constrained'; confidence = 'HIGH'; }
  const answerDocumented = input.answers.map((a, i) => a.value !== null && (a.value ? qualifies(a, input.cutoff) && (input.version === '1.0' || i !== 3 || b4Qualifies(input)) : qualifies(a, input.cutoff) || a.gap.trim().length >= 8));
  const constraintDocumented = initial.phase !== 'AMBIGUOUS' || input.constraints.every((a, i) => a.value !== null && (a.value ? constraints[i] : qualifies(a, input.cutoff) || a.gap.trim().length >= 8));
  const sourceCount = input.answers.filter(a => qualifies(a, input.cutoff)).length;
  const complete = answerDocumented.every(Boolean) && constraintDocumented && sourceCount > 0;
  if (!complete) confidence = 'NONE';
  let compliance = 'N/A'; let badge = 'Unissued'; let severity = 'WARNING';
  let finding = `Observable behavior matches ${phase}; no valid phase declaration was supplied. Publish a signed PDH matching the detected behavior before a badge can be issued.`;
  if (phase === 'AMBIGUOUS') {
    compliance = input.version === '1.1' ? 'N/A (phase unresolved)' : 'INCOHERENT';
    severity = input.version === '1.1' ? 'WARNING' : 'BREACH';
    finding = input.version === '1.1' ? 'Observed conditions partially match a defined phase branch; no phase badge is assigned. One or more constraint criteria are not demonstrated.' : 'The behavioral vector is ambiguous. Constraint evidence does not demonstrate all four checks; v1.0’s optional escalation is not automated because it has no specified predicate.';
  } else if (phase === 'INCOHERENT') {
    compliance = 'INCOHERENT'; badge = 'Invalid'; severity = 'COLLAPSE_RISK';
    finding = 'No defined branch reaches the minimum match threshold. Require clarification and revalidation before a phase badge can be considered.';
  } else if (pdh.status === 'VALID') {
    if (pdh.declared === phase) { compliance = 'COMPLIANT'; badge = 'Confirmed'; severity = 'INFORMATIONAL'; finding = `The validated declaration and observed behavior both identify ${phase}. The declaration is consistent with the documented activator vector.`; }
    else { compliance = 'MISMATCH'; badge = 'Reclassified'; severity = 'BREACH'; finding = `The entity declares ${pdh.declared}, but its documented behavior identifies ${phase}. The phase is reclassified and the contradiction is logged.`; }
  }
  if (!complete) { badge = 'Unissued'; compliance = 'N/A (evidence incomplete)'; severity = 'WARNING'; finding = `Provisional scoring yields ${phase}; the public evidence record is incomplete. Unsupported v1.1 YES answers are coded NO, not treated as proof of a negative; no badge is issued.`; }
  const now = new Date().toISOString();
  const entityCode = (input.identifier || input.name).toUpperCase().replace(/[^A-Z0-9]/g, '-').replace(/-+/g, '-').slice(0, 32) || 'ENTITY';
  const history = existing.filter(a => !a.baseline && (input.identifier ? a.identifier === input.identifier : a.name.toLowerCase() === input.name.toLowerCase())).sort((a, b) => a.cutoff.localeCompare(b.cutoff));
  const nextSequence = Math.max(0, ...history.map(a => Number(String(a.report.Duty_Collation_Entry_ID || '').split('-').pop()) || 0)) + 1;
  const entryId = `PDH-${input.cutoff}-${entityCode}-${String(nextSequence).padStart(3, '0')}`;
  const decrement = input.decrement.enabled && isPublicUrl(input.decrement.oldSource) && isPublicUrl(input.decrement.newSource) && beforeCutoff(input.decrement.oldDate, input.cutoff) && beforeCutoff(input.decrement.newDate, input.cutoff) && Date.parse(input.decrement.oldDate) < Date.parse(input.decrement.newDate) && input.decrement.notes.trim().length >= 8;
  const previousRecords = history.filter(a => a.cutoff <= input.cutoff);
  const previous = previousRecords[previousRecords.length - 1];
  let temporalPattern = decrement ? 'Drift' : 'N/A';
  let transition: Transition | null = null;
  if (previous) {
    let status = 'OBSERVED_ONLY'; let notes = 'A temporal transition requires distinct valid declarations with different effective timestamps at both endpoints. This record alone does not authorize a transition.';
    temporalPattern = decrement ? 'Drift' : previous.phase === phase ? 'Stable' : 'N/A';
    if (previous.pdh.status === 'VALID' && pdh.status === 'VALID' && previous.pdh.headerId !== pdh.headerId && previous.pdh.effectiveTimestamp !== pdh.effectiveTimestamp && complete) {
      if (previous.phase === 'GSRB' && ['NAB', 'CWO'].includes(phase)) { status = 'FORBIDDEN'; severity = 'COLLAPSE_RISK'; badge = 'Invalid'; compliance = 'MISMATCH (forbidden transition)'; notes = 'UNAUTHORIZED_REVERSION: GSRB cannot revert to NAB or CWO without complete structural collapse and rebuild.'; finding += ' The attempted reversion is forbidden under the source transition rule; no destination badge is issued.'; }
      else if (['NAB', 'CWO'].includes(previous.phase) && phase === 'GSRB') { status = 'DECLARATION_REVIEW_REQUIRED'; badge = 'Unissued'; severity = 'WARNING'; notes = 'SOVEREIGNTY_ESCALATION: the signed declaration must additionally state loss of misuse resistance; that textual precondition is not independently verified by this workspace.'; finding += ' The sovereignty transition requires declaration review before a badge can be issued.'; }
      else if (['NAB', 'CWO'].includes(previous.phase) && ['NAB', 'CWO'].includes(phase)) { status = 'ALLOWED'; notes = 'A reversible NAB ↔ CWO transition with a valid destination declaration.'; }
      else if (previous.phase === phase) { status = 'ALLOWED'; notes = 'Stable phase across both validated declaration records.'; }
      else { status = 'UNSPECIFIED'; notes = 'The source does not specify a transition rule for this combination; no permission is inferred.'; }
      if (previous.pdh.declared !== pdh.declared && previous.phase === phase) { temporalPattern = 'Rebranding'; severity = 'BREACH'; }
      if (history.some(a => a.phase === 'NAB') && previous.phase === 'CWO' && phase === 'GSRB') temporalPattern = 'Drift';
    }
    transition = { from: previous.phase, to: phase, fromDate: previous.cutoff, toDate: input.cutoff, status, pattern: temporalPattern, severity, entryId, notes };
  }
  const evidence: Evidence[] = [];
  [...input.answers, ...input.constraints].forEach((answer, i) => {
    if (!qualifies(answer, input.cutoff)) return;
    const code = i < 5 ? `B${i + 1}` : `C${i - 4}`;
    const duplicate = evidence.find(e => e.url === answer.source && e.published === answer.date);
    if (duplicate) duplicate.codes.push(code);
    else evidence.push({ id: `${entryId}-E${evidence.length + 1}`, title: answer.notes.slice(0, 80), url: answer.source, published: answer.date, retrieved: now.slice(0, 10), claim: answer.notes, codes: [code], entity: input.name });
  });
  const externalDemonstrated = input.external.exists && isPublicUrl(input.external.source) && beforeCutoff(input.external.date, input.cutoff) && !!input.external.holder.trim() && !!input.external.scope.trim();
  const externalRecord = { ...input.external, exists: externalDemonstrated, exercised: externalDemonstrated && input.external.exercised, Exists: externalDemonstrated ? 'YES' : 'NO', Exercised: externalDemonstrated && input.external.exercised ? 'YES' : 'NO', Auditor_Stated_Exists: input.external.exists, Auditor_Stated_Exercised: input.external.exercised, Descriptive_Only: true, Latent: externalDemonstrated && !input.external.exercised, Evidence_Gap: input.external.exists && !externalDemonstrated ? 'Qualifying public provenance was not demonstrated by the cutoff.' : null };
  if (externalDemonstrated && !evidence.some(e => e.url === input.external.source)) evidence.push({ id: `${entryId}-EXTERNAL`, title: `External authority: ${input.external.holder}`, url: input.external.source, published: input.external.date, retrieved: now.slice(0, 10), claim: input.external.scope, codes: ['EXTERNAL (NON-SCORING)'], entity: input.name });
  if (decrement) for (const [code, url, date] of [['OLD', input.decrement.oldSource, input.decrement.oldDate], ['NEW', input.decrement.newSource, input.decrement.newDate]]) {
    if (!evidence.some(e => e.url === url)) evidence.push({ id: `${entryId}-DECREMENT-${code}`, title: `Constraint decrement: ${code.toLowerCase()} instrument`, url, published: date, retrieved: now.slice(0, 10), claim: input.decrement.notes, codes: ['TEMPORAL (NON-SCORING)'], entity: input.name });
  }
  // The provisional badge colours a segment only on affirmative evidence: a qualifying artifact whose answer matches the scored answer. Gap statements leave it blank.
  const badgeAnswers = input.answers.map((answer, i) => answer.value !== null && qualifies(answer, input.cutoff) && answer.value === vector[i] ? vector[i] : null);
  const badgeRecord = provisionalBadge(badgeAnswers, badgeAnswers.map(value => value !== null));
  const replicationRisk = complete && pdh.status === 'VALID' ? 'LOW' : complete ? 'MEDIUM' : 'HIGH';
  const activatorVector = input.answers.map((a, i) => ({ Question: `B${i + 1}`, Auditor_Answer: a.value === null ? 'UNANSWERED' : a.value ? 'YES' : 'NO', Scored_Answer: vector[i] ? 'YES' : 'NO', Source: a.source || null, Publication_Date: a.date || null, Claim: a.notes || null, Evidence_Gap: a.gap || (!qualifies(a, input.cutoff) ? 'No qualifying public artifact by cutoff.' : null), Cutoff_Status: qualifies(a, input.cutoff) ? 'ELIGIBLE' : 'NOT_DEMONSTRATED' }));
  const report: Record<string, unknown> = {
    Algorithm_Version: `Ground-0 v${input.version}`, Specification_Status: input.version === '1.0' ? 'NORMATIVE BASELINE' : 'AMENDMENT DRAFT — NOT RATIFIED', Record_Status: complete ? 'EVIDENCE_DOCUMENTED' : 'DRAFT — EVIDENCE INCOMPLETE',
    Entity_Name: input.name.trim(), Entity_Identifier: input.identifier.trim() || null, Audit_Timestamp: now, Evidence_Cutoff: `${input.cutoff}T23:59:59.999Z`,
    PDH_Status: pdh.status, PDH_Validation: pdh, Declared_Phase: pdh.declared, Detected_Phase: phase, Compliance_Status: compliance, Confidence_Level: confidence, Severity_Level: severity, Badge_Status: badge, Finding: finding,
    Evidence_Summary: evidence, Activator_Vector: activatorVector, Branch_Matches: { NAB: initial.matches[0], CWO: initial.matches[1], GSRB: initial.matches[2] },
    B4_Event_Record: { ...input.b4, B4_Basis: input.b4.basis, Actor: input.b4.actor, Action: input.b4.action, Procedure: input.b4.procedure, Result_Claim: input.answers[3].notes || 'NOT_RECORDED', External_Order_Separate: input.external, Scored_Answer: vector[3] ? 'YES' : 'NO' }, Constraint_Results: input.constraints.map((a, i) => ({ Code: `C${i + 1}`, Auditor_Answer: a.value === null ? 'UNANSWERED' : a.value ? 'YES' : 'NO', Scored_Answer: constraints[i] ? 'YES' : 'NO', Source: a.source, Publication_Date: a.date, Evidence_Gap: a.gap })), C2_Outcome_Record: input.c2,
    External_Constraint_Record: externalRecord, Constraint_Decrement: { Verified_By_Auditor: decrement ? 'YES' : 'NO', ...input.decrement, Non_Scoring: true },
    Provisional_Badge: { Normative: false, Protocol: 'Workspace extension: blank badge issued by default, presumes CWO, coloured in per evidenced answer. Badge_Status above is the specification value.', Presumption: badgeRecord.presumption, Filled: `${badgeRecord.filled}/5`, Proven_Wrong: badgeRecord.provenWrong, Upheld: badgeRecord.upheld, Blank: badgeRecord.blank, Segments: badgeRecord.segments.map(segment => ({ Question: segment.code, State: segment.state.toUpperCase(), Evidenced_Answer: segment.answer === null ? null : segment.answer ? 'YES' : 'NO' })), Summary: badgeRecord.summary },
    Duty_Collation_Entry_ID: entryId, Replication_Risk: replicationRisk, Temporal_Pattern: temporalPattern, Transition_History: [...history.filter(a => a.cutoff <= input.cutoff).flatMap(a => a.transition ? [a.transition] : []), ...(transition ? [transition] : [])],
    Implementation_Notes: ['Signatures use the workspace ECDSA P-256/SHA-256 adapter; origin-key trust is supplied by the auditor, not independently certified. Header-ID conflicts are checked locally, not against an external registry.', ...(input.version === '1.0' ? ['The unspecified optional Step 3.5 GSRB escalation is never inferred automatically.'] : []), 'The source does not define a rapid-oscillation time threshold; no automated oscillation finding is made.'],
  };
  return { input: JSON.parse(JSON.stringify(input)) as AuditInput, id: typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`, name: input.name.trim(), identifier: input.identifier.trim(), version: input.version, createdAt: now, cutoff: input.cutoff, reportedDeclared: pdh.declared === 'NONE' ? 'None' : pdh.declared, phase, confidence, severity, compliance, badge, provisionalBadge: badgeRecord, status: !complete ? 'Draft' : phase === 'AMBIGUOUS' || phase === 'INCOHERENT' || transition?.status === 'FORBIDDEN' || transition?.status === 'DECLARATION_REVIEW_REQUIRED' ? 'Needs review' : 'Complete', baseline: false, evidence, answers: input.answers, constraints: input.constraints, pdh, finding, replicationRisk, temporalPattern, transition, report };
}

export function baselineAudits(): AuditRecord[] {
  const rows: [string, string, string, Phase, Confidence][] = [
    ['Quantum Library', 'QL-001', 'CWO', 'CWO', 'HIGH'],
    ['World Health Organization', 'WHO', 'None', 'GSRB', 'HIGH'],
    ['Federal Reserve', 'FED', 'Implicit NAB', 'GSRB', 'HIGH'],
    ['Social Platform', 'SP-001', 'NAB / CWO', 'GSRB', 'HIGH'],
    ['Government (Normal)', 'GOV-N', 'Implicit CWO', 'AMBIGUOUS', 'MEDIUM'],
    ['Government (Emergency)', 'GOV-E', 'Implicit', 'GSRB', 'HIGH'],
  ];
  return rows.map(([name, identifier, declared, phase, confidence], i) => {
    const finding = `The v1.0 manuscript reports ${phase} with ${confidence.toLowerCase()} confidence for this baseline test. The underlying artifact set, activator vector, and signed PDH are not supplied here; this is not an independently verified audit.`;
    return { id: `baseline-${i}`, name, identifier, version: '1.0', createdAt: '2026-09-12T00:00:00Z', cutoff: '', reportedDeclared: declared, phase, confidence, provisionalBadge: blankBadge(), severity: phase === 'AMBIGUOUS' ? 'WARNING' : 'INFORMATIONAL', compliance: 'N/A (source baseline)', badge: 'Unissued', status: phase === 'AMBIGUOUS' ? 'Needs review' : 'Complete', baseline: true, evidence: [], answers: Array.from({ length: 5 }, emptyAnswer), constraints: Array.from({ length: 4 }, emptyAnswer), pdh: missingPDH(), finding, replicationRisk: 'HIGH', temporalPattern: 'N/A', transition: null,
      report: { Source_Baseline: true, Source: 'Ground-0 v1.0, Section XII — Test Replication Results', Algorithm_Version: '1.0', Entity_Name: name, Entity_Identifier: identifier, Audit_Timestamp: null, Baseline_Finalization_Date: '2026-09-12', Evidence_Cutoff: 'NOT STATED IN MANUSCRIPT', PDH_Status: 'MISSING', Declared_Phase: 'NONE', Reported_Declaration: declared, Detected_Phase: phase, Confidence_Level: confidence, Confidence_Basis: 'REPORTED BY SOURCE — NOT RECOMPUTED', Compliance_Status: 'N/A (source baseline)', Badge_Status: 'Unissued', Severity_Level: phase === 'AMBIGUOUS' ? 'WARNING' : 'INFORMATIONAL', Finding: finding, Evidence_Summary: [], Activator_Vector: 'NOT SUPPLIED', B4_Event_Record: 'NOT SUPPLIED', External_Constraint_Record: 'NOT SUPPLIED', Constraint_Decrement: 'NOT ASSESSED', Duty_Collation_Entry_ID: `BASELINE-${identifier}`, Replication_Risk: 'HIGH — supporting evidence unavailable in workspace', Temporal_Pattern: 'N/A', Transition_History: [] },
    };
  });
}

export function formatDate(date: string, short = false): string {
  if (!date) return 'Not stated';
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', ...(short ? {} : { year: 'numeric' }), timeZone: 'UTC' }).format(new Date(date.length === 10 ? `${date}T00:00:00Z` : date));
}
export function downloadFile(name: string, content: string, type = 'application/json'): void {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = name; document.body.appendChild(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function exportAudit(audit: AuditRecord): void { downloadFile(`ground-0-${audit.identifier || 'audit'}-v${audit.version}.json`, JSON.stringify(audit.report, null, 2)); }
