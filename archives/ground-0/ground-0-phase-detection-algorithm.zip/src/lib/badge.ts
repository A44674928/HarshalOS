/**
 * Provisional badge protocol (workspace extension, not part of the v1.0/v1.1 text).
 *
 * Every audited entity receives a blank badge by default. The badge presumes the
 * weakest claim of authority — CWO, witness-only — and each of the five
 * behavioral questions colours in one segment as evidence arrives:
 *   • custodial  – the evidenced answer is consistent with the CWO presumption
 *   • authority  – the evidenced answer proves the presumption wrong
 *   • blank      – no qualifying evidence yet
 * The specification's Badge_Status (Confirmed / Reclassified / Unissued / Invalid)
 * is unchanged and still governs formal issuance.
 */
export type SegmentState = 'blank' | 'custodial' | 'authority';
export type BadgeSegment = { code: string; short: string; state: SegmentState; answer: boolean | null; supported: boolean; custodialAnswer: boolean };
export type ProvisionalBadge = { presumption: 'CWO'; segments: BadgeSegment[]; filled: number; provenWrong: string[]; upheld: string[]; blank: string[]; summary: string; normative: false };

const SHORT = ['Coercion', 'Optional decisions', 'Executable rules', 'Terminal refusal', 'Persistent authority'];
/** Answers a pure witness-only body would give to B1–B5. */
const CUSTODIAL_ANSWERS = [false, true, false, true, false];

const list = (codes: string[]) => codes.length === 0 ? 'none' : codes.length === 1 ? codes[0] : `${codes.slice(0, -1).join(', ')} and ${codes[codes.length - 1]}`;

export function provisionalBadge(answers: (boolean | null)[], supported: boolean[]): ProvisionalBadge {
  const segments: BadgeSegment[] = CUSTODIAL_ANSWERS.map((custodialAnswer, index) => {
    const answer = answers[index] ?? null;
    const isSupported = !!supported[index] && answer !== null;
    const state: SegmentState = !isSupported ? 'blank' : answer === custodialAnswer ? 'custodial' : 'authority';
    return { code: `B${index + 1}`, short: SHORT[index], state, answer, supported: isSupported, custodialAnswer };
  });
  const provenWrong = segments.filter(segment => segment.state === 'authority').map(segment => segment.code);
  const upheld = segments.filter(segment => segment.state === 'custodial').map(segment => segment.code);
  const blank = segments.filter(segment => segment.state === 'blank').map(segment => segment.code);
  const filled = provenWrong.length + upheld.length;
  const summary = filled === 0
    ? 'Blank provisional badge: no question has qualifying evidence yet. The default presumption is CWO, witness-only.'
    : `Provisional badge with ${filled} of 5 segments coloured in. The CWO presumption is proven wrong on ${list(provenWrong)} and upheld on ${list(upheld)}. Blank: ${list(blank)}.`;
  return { presumption: 'CWO', segments, filled, provenWrong, upheld, blank, summary, normative: false };
}

export const blankBadge = (): ProvisionalBadge => provisionalBadge([null, null, null, null, null], [false, false, false, false, false]);
