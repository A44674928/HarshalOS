# Ground-0 Phase Intelligence

An evidence-first React/Vite workspace with two audit routes:

- **Manual audit:** the guided, versioned Ground-0 checklist, citations, PDH validation, constraints, and temporal records.
- **Automatic audit:** enter an organization name. Public-source research prepares a draft, preserving citations and gaps, with a manual-review handoff. Automatic drafts are never issued badges or treated as independently verified findings.

v1.0 remains the normative source baseline. v1.1 is an unratified amendment draft. Accessibility changes and research automation do not adopt or amend either source.

## Static deployment / key-free lookup

Run `npm run build` and serve `dist/`.

On a static deployment the automatic screen searches, in parallel and without any API key:

| Record type | Source | Used for |
| --- | --- | --- |
| Identity and official website | Wikimedia Action API + Wikidata `P856` | Resolving which organization is meant |
| Official policy, governance, and appeal pages | Jina Reader (key-free GET) | B1–B5 behavioral evidence |
| Archived captures at your cutoff | Internet Archive Wayback availability API | Reading a verified capture taken before the cutoff; a capture is not itself proof of an effective date |
| Court opinions and dockets | CourtListener v4 (Free Law Project) | C1/C4 external override, external-constraint record |
| Regulatory and executive documents | Federal Register API | C1/C4, regulatory context |
| Legislative records | GovTrack | Legislative context |
| News coverage | GDELT | Dated leads only — never scored |

Scoring rules that keep this honest:

- A registry hit only suggests a constraint when a real source sentence describes a court or regulator acting on **this organization’s decision or policy**. Caption matches and keywords alone are not enough. App-written reading guidance, requests for relief, denied motions, docket filing dates, and proposed rules cannot activate C1/C4. Full-text-only mentions remain context.
- An external authority acting on the entity is recorded under C1/C4 and the external-constraint record. It is **never** treated as the entity's own coercive power (B1).
- News is always `scoreable: false`. It is presented as a lead to find a primary artifact.
- Every query is bounded by the inclusive evidence cutoff; results after it are dropped.

Coverage is displayed in the result, **including registries that returned nothing, were partially available, or were unavailable**. Archive checks distinguish captures found, no match, unavailable, and not needed. Queries inspect bounded result sets; the app never represents this as a search of every public record.

Remaining limits, stated in the UI: court, regulatory, and legislative indexes are US-focused; state, local, non-US, sealed, and paywalled records are not covered; news indexing is rate-limited; and the site reader follows homepage links rather than crawling an entire domain.

The organization name goes to Wikimedia, CourtListener, Federal Register, GovTrack, and GDELT; page URLs go to Jina Reader and the Internet Archive. Local audit history and display preferences are never sent. No API key is requested in the browser.

## Working badge vs. formal badge

The specification issues a badge only with a valid, signed, fresh, consistent PDH. That rule is unchanged. Alongside it, every audit now carries a **working badge**, which is a progress indicator, not a certification:

- It starts as **CWO — default, unproven**: an empty outline with a dashed centre, on the assumption that a body merely records rather than decides.
- It has five arcs, one per behavioral question. An arc fills **only** when that answer is backed by a dated public artifact that passes the cutoff check.
- When documented evidence contradicts a record-only centre (B1/B2/B3/B5), the CWO default is marked **disproven** and the badge re-colours to the detected phase. A fully evidenced NAB vector takes precedence over the broader CWO branch even though its first four branch conditions overlap. An unanswered question or unsupported v1.1 B4 claim does not fill an arc.
- With all five evidenced but no single complete branch, it shows **contested**.
- Separately evidenced C1–C4 constraint checks are reported in the badge text but never fill the behavioral arcs.

`Badge_Status` in the exported record keeps its normative meaning, and the UI always shows "Formal badge: … — needs a valid signed PDH" next to the working badge. A filled working badge never issues, implies, or substitutes for a formal badge.

## Optional broader name-only web research

A deployment operator can use the included Node 20+ server to enable broader cited research via the OpenAI Responses API. Users still enter only a name; **the API key stays on the server**.

1. Build: `npm run build`.
2. Set `OPENAI_API_KEY` in your hosting platform's secret store or server environment. Never use a `VITE_` variable for this key; never commit the key.
3. Optionally set `OPENAI_RESEARCH_MODEL` (default `gpt-5.5`, as documented in the current Responses web-search guide), `PORT` (default `3000`), and `HOST` (default `127.0.0.1`; set `0.0.0.0` if appropriate to your hosting environment).
4. Start the server with `node server/research.mjs`. It serves the built workspace and same-origin research routes.

Routes:

- `GET /api/research/status` returns whether hosted research is configured; no credential is returned.
- `POST /api/research` accepts `{ "name": "Organization name", "version": "1.0", "cutoff": "YYYY-MM-DD" }`.

The server first runs Responses `web_search` with mandatory search and a bounded tool budget. It then extracts a strict JSON-schema evidence record. Only consulted public URLs are accepted. Proposed scoring quotes are independently re-read using Jina Reader; exact quote matching and explicit dates are checked. This does not prove substantive correctness. **AI source selection and evidence coding remain fallible and require human review.** No provider-supplied phase is trusted; the local engine computes the provisional phase.

The frontend automatically detects the configured same-origin service. When it is not configured, the key-free lookup remains available. When an enabled hosted service fails, the UI shows an error and retry/manual options; it does not silently fabricate a result.

### Production responsibilities

The included server is a deployment starting point, not a managed production service. It provides basic same-origin checks, a small body limit, per-address rate limits, a concurrent-request cap, cancellation, and timeouts. Before public deployment:

- Put it behind HTTPS and your normal authentication/abuse protection if applicable.
- Apply provider spending limits and monitoring. Web search/model calls incur charges.
- Use a shared rate-limit store for multiple replicas; the included limiter is per process.
- Set `ALLOWED_ORIGIN` only when a deliberate reverse-proxy setup needs it.
- Review provider retention, privacy, legal, and regional data-processing requirements.
- Test organization identity, evidence scope, citations, and archival cutoff behavior with domain experts.

No model API key, private audit history, or browser preference data is included in provider requests. `store: false` is used for Responses; this does not by itself guarantee zero provider retention.

## Accessibility features

- Skip-to-content navigation, native buttons for table actions, and persistent focus indicators.
- Labeled inputs, answer groups, and disclosure controls; keyboard focus follows manual steps.
- Modal focus containment and restoration with an inert background.
- Announced automatic progress, error messages, cancellation, and no timed review tasks.
- Persistent standard/125%/150% text sizes, high-contrast mode, comfortable reading mode, and reduced motion; system reduced-motion preferences are respected.
- Accessible source links and plain-text report downloads, plus optional browser read-aloud summaries.
- No mandatory microphone, drag interaction, puzzle, disability disclosure, or account authentication.

These changes support accessibility but are not a claim of full WCAG certification. Test with real assistive technologies and disabled users, including screen readers, switch control, dictation, keyboard-only use, 200%/400% zoom, and mobile reflow. Browser speech synthesis may use an OS/cloud voice according to the user's device configuration; it is optional and never starts without an explicit action.

## Validation

- `npx tsc --noEmit`
- `npm run build`
- Existing workflow suite: `node scripts/smoke-test.mjs` (install Playwright for local test execution).
- Registry connectors and badge progression are covered by `scripts/accessible-automatic-test.mjs` using offline fixtures.
- Bug regressions: `node scripts/bug-regression-test.mjs` — legacy-record recovery, badge precedence, court false positives, archive provenance, cancellation, and retained research coverage.
- Optional-server guards: `node scripts/server-regression-test.mjs` — no real API key or paid calls required.
- Accessibility/automatic workflow checks are in `scripts/accessible-automatic-test.mjs`.

## API references

- MediaWiki CORS: https://www.mediawiki.org/wiki/Manual:CORS
- Wikidata entity queries: https://www.mediawiki.org/wiki/API:Presenting_Wikidata_knowledge
- Jina Reader: https://jina.ai/reader/
- Responses web search: https://platform.openai.com/docs/guides/tools-web-search
- Structured Outputs: https://platform.openai.com/docs/guides/structured-outputs
- W3C status messages: https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html
- CourtListener API: https://www.courtlistener.com/help/api/rest/
- Federal Register API: https://www.federalregister.gov/developers/documentation/api/v1
- GovTrack API: https://www.govtrack.us/api/v2
- Wayback availability API: https://archive.org/help/wayback_api.php
- GDELT DOC API: https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/


## Reliability fixes

- Saved audits from earlier versions are normalized on load and missing working badges rebuilt. Incompatible originals are preserved under the corresponding local-storage key with `-recovery` appended; no evidence or signed PDH is invented during migration.
- Request deadlines and cancellation remain active through response-body decoding. News retry delays are cancelable, and late results cannot replace a newer search.
- Archived evidence keeps its actual Wayback URL, original URL, capture date, and publication/effective date separately. Policy-link discovery uses the live homepage. If a historical capture is unavailable, current mutable text is retained as context instead of silently treated as historical proof.
- Evidence cutoff checks reject invalid calendar dates, include the full UTC cutoff day, and use clamped calendar-month lookbacks.
- Research coverage and limitations survive saving, resuming, manual regeneration, and JSON export. Changing evidence after confirming review resets that confirmation. An automatic result that has already been reviewed/saved cannot be saved again as a duplicate draft.
