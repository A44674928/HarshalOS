import { useEffect, useState } from 'react';
import Icon from './Icon';

export default function ListenButton({ text }: { text: string }) {
  const [speaking, setSpeaking] = useState(false);
  const supported = typeof window !== 'undefined' && 'speechSynthesis' in window;
  useEffect(() => () => { if (supported) window.speechSynthesis.cancel(); }, [supported, text]);
  if (!supported) return null;
  const listen = () => {
    if (speaking) { window.speechSynthesis.cancel(); setSpeaking(false); return; }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US'; utterance.rate = .92;
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    setSpeaking(true); window.speechSynthesis.speak(utterance);
  };
  return <button type="button" className={`button secondary listen-button ${speaking ? 'speaking' : ''}`} onClick={listen} aria-pressed={speaking}><Icon name={speaking ? 'pause' : 'volume'} size={17}/>{speaking ? 'Stop reading' : 'Listen to summary'}</button>;
}
