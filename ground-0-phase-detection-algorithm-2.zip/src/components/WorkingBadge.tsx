import Icon from './Icon';
import type { WorkingBadge as WorkingBadgeData } from '../lib/engine';

const palette: Record<string, { fill: string; ring: string; ink: string }> = {
  CWO: { fill: '#8fb6cc', ring: '#c9dde8', ink: '#3c6076' },
  NAB: { fill: '#8bb072', ring: '#d3e3c4', ink: '#3f6229' },
  'NAB-Constrained': { fill: '#cfa85f', ring: '#eddfc0', ink: '#7a5c17' },
  GSRB: { fill: '#c98f64', ring: '#ecd8c6', ink: '#7e4c25' },
  AMBIGUOUS: { fill: '#c0ad74', ring: '#e8e0c6', ink: '#6f5f20' },
  INCOHERENT: { fill: '#bf8d80', ring: '#e8d3cd', ink: '#7a3b2c' },
};
const icons: Record<string, string> = { CWO: 'droplet', NAB: 'cube', 'NAB-Constrained': 'cube-plus', GSRB: 'cloud', AMBIGUOUS: 'warning', INCOHERENT: 'warning' };

/** Five arcs, one per behavioral question. Each arc fills only when that answer is
 *  backed by a dated public artifact, so the badge shows evidence, not assertion. */
export default function WorkingBadge({ badge, size = 'regular' }: { badge: WorkingBadgeData; size?: 'regular' | 'compact' }) {
  const colors = palette[badge.phase] || palette.CWO;
  const radius = 34;
  const gap = 7;
  const circumference = 2 * Math.PI * radius;
  const arc = circumference / 5 - gap;
  const summary = `Working badge: ${badge.label}. ${badge.filled} of 5 behavioral questions evidenced. Formal badge status: ${badge.formal}.`;
  return <div className={`working-badge ${size}`} data-state={badge.state}>
    <div className="working-badge-mark" role="img" aria-label={summary}>
      <svg viewBox="0 0 88 88" aria-hidden="true">
        <circle cx="44" cy="44" r={radius} fill="none" stroke={colors.ring} strokeWidth="7" strokeDasharray={`${arc} ${gap}`} strokeLinecap="round" transform="rotate(-90 44 44)" opacity=".55"/>
        {badge.segments.map((segment, i) => segment.documented && <circle key={segment.code} cx="44" cy="44" r={radius} fill="none" stroke={colors.fill} strokeWidth="7" strokeLinecap="round" strokeDasharray={`${arc} ${circumference - arc}`} strokeDashoffset={-(i * (circumference / 5))} transform="rotate(-90 44 44)"/>)}
        <circle cx="44" cy="44" r="25" fill={badge.filled === 0 ? 'transparent' : `${colors.fill}1f`} stroke={badge.filled === 0 ? colors.ring : 'transparent'} strokeDasharray={badge.filled === 0 ? '3 4' : undefined}/>
      </svg>
      <span className="working-badge-icon" style={{ color: badge.filled === 0 ? colors.ring : colors.ink }}><Icon name={icons[badge.phase] || 'droplet'} size={size === 'compact' ? 19 : 26}/></span>
    </div>
    <div className="working-badge-text">
      <span className="working-badge-label" style={{ color: colors.ink }}>{badge.label}</span>
      <span className="working-badge-progress"><i style={{ width: `${(badge.filled / 5) * 100}%`, background: colors.fill }}/></span>
      <span className="working-badge-count">{badge.filled} of 5 questions evidenced{badge.disproved && <em> · default disproven</em>}</span>
      {size === 'regular' && <p>{badge.explanation}</p>}
      {size === 'regular' && <span className="working-badge-formal"><Icon name="shield" size={14}/>Formal badge: {badge.formal}{badge.formal === 'Unissued' && ' — needs a valid signed PDH and completed review'}</span>}
    </div>
  </div>;
}
