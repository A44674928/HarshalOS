export default function Orbit() {
  return <div className="orbit-art" aria-hidden="true">
    <svg viewBox="0 0 340 260" fill="none">
      <defs>
        <radialGradient id="orb-halo"><stop stopColor="#8AC1A1" stopOpacity=".2"/><stop offset="1" stopColor="#8AC1A1" stopOpacity="0"/></radialGradient>
        <linearGradient id="orb-face" x1="121" y1="86" x2="193" y2="158" gradientUnits="userSpaceOnUse"><stop stopColor="#C0DFBB"/><stop offset="1" stopColor="#79AE8B"/></linearGradient>
        <linearGradient id="orb-side" x1="170" y1="108" x2="203" y2="164" gradientUnits="userSpaceOnUse"><stop stopColor="#739D73"/><stop offset="1" stopColor="#43694D"/></linearGradient>
        <linearGradient id="orb-top" x1="118" y1="100" x2="205" y2="92" gradientUnits="userSpaceOnUse"><stop stopColor="#DAE9CE"/><stop offset="1" stopColor="#A8CCA3"/></linearGradient>
        <filter id="orb-shadow" x="80" y="55" width="180" height="170"><feGaussianBlur stdDeviation="9"/></filter>
      </defs>
      <circle cx="166" cy="131" r="130" fill="url(#orb-halo)"/>
      <path d="M30 132h270M167 19v226" stroke="#91B59D" strokeOpacity=".12" strokeDasharray="3 5"/>
      <ellipse cx="167" cy="131" rx="117" ry="86" stroke="#91B59D" strokeOpacity=".22"/>
      <ellipse cx="167" cy="131" rx="81" ry="113" transform="rotate(-36 167 131)" stroke="#91B59D" strokeOpacity=".36"/>
      <ellipse cx="167" cy="131" rx="110" ry="48" transform="rotate(-28 167 131)" stroke="#AACAB0" strokeOpacity=".49"/>
      <ellipse cx="167" cy="131" rx="68" ry="88" transform="rotate(37 167 131)" stroke="#91B59D" strokeOpacity=".26" strokeDasharray="3 5"/>
      <ellipse cx="166" cy="170" rx="38" ry="13" fill="#061D15" opacity=".5" filter="url(#orb-shadow)"/>
      <path d="m166 84 42 24-42 24-42-24Z" fill="url(#orb-top)" stroke="#CAE1BE" strokeWidth=".5"/>
      <path d="m124 108 42 24v48l-42-24Z" fill="url(#orb-face)" stroke="#A9C69D" strokeWidth=".5"/>
      <path d="m166 132 42-24v48l-42 24Z" fill="url(#orb-side)" stroke="#82A47D" strokeWidth=".5"/>
      <path d="m136 115 29 17v31M177 126l20-12v33" stroke="#E0EDD2" strokeOpacity=".23" strokeWidth=".8"/>
      <circle cx="66" cy="172" r="5" fill="#D8B175"/><circle cx="66" cy="172" r="10" stroke="#D8B175" strokeOpacity=".18"/>
      <circle cx="245" cy="67" r="4" fill="#91BEA0"/><circle cx="245" cy="67" r="8" stroke="#91BEA0" strokeOpacity=".2"/>
      <circle cx="248" cy="170" r="3" fill="#AACBB0"/>
      <path d="M93 70v-8h8M267 203h8v-8" stroke="#88AD93" strokeOpacity=".55"/>
      <g><rect x="231" y="83" width="57" height="25" rx="5" fill="#234C3B" stroke="#547460" strokeWidth=".7"/><circle cx="243" cy="95.5" r="2.5" fill="#BDD4AF"/><text x="251" y="99" fill="#D1DFC9" fontSize="9" fontFamily="monospace" letterSpacing="1">NAB</text></g>
      <g><rect x="34" y="91" width="56" height="25" rx="5" fill="#1C4536" stroke="#547460" strokeWidth=".7"/><circle cx="46" cy="103.5" r="2.5" fill="#94B8CC"/><text x="54" y="107" fill="#C0D6DC" fontSize="9" fontFamily="monospace" letterSpacing="1">CWO</text></g>
      <g><rect x="198" y="203" width="62" height="25" rx="5" fill="#284938" stroke="#6E7254" strokeWidth=".7"/><circle cx="210" cy="215.5" r="2.5" fill="#D8B175"/><text x="218" y="219" fill="#DBC9A5" fontSize="9" fontFamily="monospace" letterSpacing="1">GSRB</text></g>
      <text x="105" y="242" fill="#8BA894" fontSize="7.5" fontFamily="monospace" letterSpacing="1.5">0•000•000•0000</text>
    </svg>
  </div>;
}
