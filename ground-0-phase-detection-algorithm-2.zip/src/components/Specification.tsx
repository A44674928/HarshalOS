import { useEffect, useState } from 'react';
import Icon from './Icon';
import { amendmentItems, getSections } from '../lib/specification';
import type { Version } from '../lib/engine';

export default function Specification({ version, onVersionChange, onToast }: { version: Version; onVersionChange: (version: Version) => void; onToast: (message: string) => void }) {
  const [view, setView] = useState<'reader' | 'source'>('reader');
  const [raw, setRaw] = useState('');
  const [loading, setLoading] = useState(false);
  const sections = getSections(version);
  const sourcePath = `/specifications/ground-0-v${version}.md`;
  useEffect(() => {
    if (view !== 'source') return;
    let cancelled = false;
    setLoading(true);
    fetch(sourcePath).then(response => { if (!response.ok) throw new Error(); return response.text(); }).then(text => { if (!cancelled) { setRaw(text); setLoading(false); } }).catch(() => { if (!cancelled) { setRaw('The source could not be loaded. Use the source download or switch back to the reader.'); setLoading(false); } });
    return () => { cancelled = true; };
  }, [view, sourcePath]);
  const copyCitation = async () => {
    try { await navigator.clipboard.writeText(`Patel, Harshal Priyavadan (A44674928). Ground-0 Phase Detection Algorithm v${version}. Harshal’s Systems (AGS++) | OCM. ${version === '1.0' ? 'Finalized September 12, 2026. Normative baseline.' : 'Amendment draft, pending author adoption; not ratified.'} Center Origin: 0•000•000•0000.`); onToast('Source citation copied.'); } catch { onToast('Clipboard unavailable. You can download the complete source.'); }
  };
  return <><div className="page-heading"><div><span className="eyebrow">THE VERSIONED STANDARD</span><h1>One source. A clear baseline.</h1><p>Understand the rules—and the version that governs them.</p></div><a className="button primary" href={sourcePath} download><Icon name="download" size={17}/>Download source</a></div>
    <div className="spec-toolbar"><div className="version-switch"><button className={version === '1.0' ? 'active' : ''} onClick={() => onVersionChange('1.0')}>v1.0 <span>Normative</span></button><button className={version === '1.1' ? 'active' : ''} onClick={() => onVersionChange('1.1')}>v1.1 <span>Amendment draft</span></button></div><div className="segmented"><button className={view === 'reader' ? 'active' : ''} onClick={() => setView('reader')}><Icon name="book" size={15}/>Reader</button><button className={view === 'source' ? 'active' : ''} onClick={() => setView('source')}><Icon name="code" size={15}/>Source text</button></div></div>
    {version === '1.1' && <div className="callout amber spec-status"><Icon name="info" size={20}/><p><strong>Proposed amendment—not ratified.</strong> v1.1 is pending author adoption and does not supersede the finalized v1.0 baseline. Baseline case results must be rerun before being reported as v1.1 results.</p></div>}
    <div className="spec-layout"><aside className="spec-toc"><span className="eyebrow">IN THIS DOCUMENT</span>{sections.map(section => <button key={section.id} onClick={() => { setView('reader'); setTimeout(() => document.getElementById(`spec-${section.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50); }}><span>{section.numeral}</span>{section.title}</button>)}<div className="toc-origin"><Icon name="target" size={19}/><span>CENTER ORIGIN<strong>0•000•000•0000</strong></span></div></aside>
      <article className="spec-document"><header className="spec-document-header"><span className={`source-status ${version === '1.0' ? 'normative' : 'draft'}`}><i/>{version === '1.0' ? 'FINALIZED · NORMATIVE SOURCE' : 'AMENDMENT DRAFT · PENDING ADOPTION'}</span><h2>Ground-0 Phase<br/>Detection Algorithm <span>v{version}</span></h2><p>Harshal’s Systems (AGS++) · Orb Communicator Model</p><div className="spec-author"><span className="avatar">HP</span><div><strong>Harshal Priyavadan Patel</strong><span>A44674928 · Baseline finalized September 12, 2026</span></div><button className="icon-button" title="Copy source citation" aria-label="Copy source citation" onClick={copyCitation}><Icon name="copy" size={18}/></button></div></header>
        {view === 'source' ? <div className="source-reader"><span className="eyebrow">VERSIONED SOURCE TEXT</span>{loading ? <div className="loading-state"><span className="spinner"/>Loading the archived source…</div> : <pre>{raw}</pre>}</div> : <div className="reader-content"><div className="reader-note"><Icon name="info" size={15}/><span>This reader organizes the supplied specification. The source download preserves the versioned text.</span></div>{version === '1.1' && <section className="amendment-summary"><span className="eyebrow">FIVE PROPOSED CLARIFICATIONS</span>{amendmentItems.map((item, i) => <div key={item.title}><span>0{i + 1}</span><div><h4>{item.title}</h4><p>{item.text}</p></div></div>)}</section>}
          {sections.map(section => <section id={`spec-${section.id}`} className="spec-section" key={section.id}><div className="spec-section-heading"><span>{section.numeral}</span><div><h3>{section.title}</h3><p>{section.summary}</p></div></div>{section.paragraphs?.map(paragraph => <p key={paragraph}>{paragraph}</p>)}{section.code && <pre className="spec-code">{section.code}</pre>}{section.table && <div className="spec-table-wrap"><table className="spec-table"><thead><tr>{section.table.headers.map(header => <th key={header}>{header}</th>)}</tr></thead><tbody>{section.table.rows.map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>)}</tbody></table></div>}{section.bullets && <ul>{section.bullets.map(bullet => <li key={bullet}>{bullet}</li>)}</ul>}</section>)}<div className="spec-end"><Icon name="shield" size={24}/><span>END OF SPECIFICATION</span><p>{version === '1.0' ? 'Normative baseline · v1.0' : 'Amendment draft · Not ratified'}</p></div></div>}
      </article></div></>;
}
