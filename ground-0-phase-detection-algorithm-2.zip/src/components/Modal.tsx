import { useEffect, useRef, useId, type ReactNode } from 'react';
import { createPortal } from 'react-dom';

export default function Modal({ children, onClose, className = '', label }: { children: ReactNode; onClose: () => void; className?: string; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  const titleId = useId();
  close.current = onClose;
  useEffect(() => {
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    const overlay = ref.current?.parentElement;
    const siblings = Array.from(document.body.children).filter(element => element !== overlay && !['SCRIPT', 'STYLE', 'LINK'].includes(element.tagName));
    const inertStates = siblings.map(element => ({ element, wasInert: element.hasAttribute('inert') }));
    for (const { element } of inertStates) element.setAttribute('inert', '');
    document.body.style.overflow = 'hidden';
    const heading = ref.current?.querySelector<HTMLHeadingElement>('h2');
    if (heading) { heading.id = heading.id || titleId; ref.current?.setAttribute('aria-labelledby', heading.id); }
    const frame = requestAnimationFrame(() => {
      const auto = ref.current?.querySelector<HTMLElement>('[data-autofocus]');
      const first = auto || ref.current?.querySelector<HTMLElement>('input:not([disabled]), button:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href]');
      (first || ref.current)?.focus();
    });
    const handleKey = (event: KeyboardEvent) => {
      if (overlay?.hasAttribute('inert')) return;
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close.current(); return; }
      if (event.key !== 'Tab') return;
      const items = Array.from(ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], summary, [tabindex="0"]') || []).filter(el => el.getClientRects().length > 0 && !el.closest('[inert]'));
      const first = items[0], last = items[items.length - 1];
      if (!first) { event.preventDefault(); ref.current?.focus(); return; }
      if (event.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', handleKey, true);
    return () => {
      cancelAnimationFrame(frame); document.body.style.overflow = previousOverflow; document.removeEventListener('keydown', handleKey, true);
      for (const { element, wasInert } of inertStates) if (!wasInert) element.removeAttribute('inert');
      if (previousFocus?.isConnected && !previousFocus.closest('[inert]')) previousFocus.focus();
    };
  }, [titleId]);
  return createPortal(<div className="modal-overlay" onMouseDown={event => { if (event.target === event.currentTarget) close.current(); }}>
    <div className={`modal ${className}`} ref={ref} role="dialog" aria-modal="true" aria-label={label} tabIndex={-1}>{children}</div>
  </div>, document.body);
}
