import { useState } from 'react';
import Icon from './Icon';
import Modal from './Modal';
import type { AccessibilitySettings } from '../lib/accessibility';

export default function AccessibilityPanel({ settings, onChange, onReset, onClose }: { settings: AccessibilitySettings; onChange: (settings: AccessibilitySettings) => void; onReset: () => void; onClose: () => void }) {
  const [message, setMessage] = useState('');
  const change = (next: AccessibilitySettings, announcement: string) => { onChange(next); setMessage(announcement); };
  return <Modal className="accessibility-modal" label="Accessibility and display preferences" onClose={onClose}>
    <div className="modal-heading"><div><span className="eyebrow"><Icon name="accessibility" size={16}/> YOUR WORKSPACE, YOUR WAY</span><h2>Make room for how you work.</h2><p>These preferences apply throughout the workspace.</p></div><button className="icon-button" aria-label="Close accessibility settings" onClick={onClose}><Icon name="close"/></button></div>
    <div className="accessibility-body">
      <fieldset className="preference-fieldset"><legend>Text size</legend><p>Increase text without losing controls or content.</p><div className="text-size-options">{[['standard', 'Aa', 'Standard', '100%'], ['large', 'Aa', 'Large', '125%'], ['larger', 'Aa', 'Larger', '150%']].map(([id, sample, label, size]) => <label className={`text-size-option ${settings.textSize === id ? 'selected' : ''}`} key={id}><input type="radio" name="text-size" value={id} checked={settings.textSize === id} onChange={() => change({ ...settings, textSize: id as AccessibilitySettings['textSize'] }, `${label} text enabled.`)}/><span className={`size-sample ${id}`} aria-hidden="true">{sample}</span><strong>{label}</strong><span>{size}</span></label>)}</div></fieldset>
      <div className="preference-toggles">
        <label className="preference-toggle"><span className="preference-icon"><Icon name="contrast" size={22}/></span><span><strong>High contrast</strong><small>Darker text, clearer borders, and stronger focus.</small></span><input type="checkbox" role="switch" checked={settings.highContrast} onChange={e => change({ ...settings, highContrast: e.target.checked }, `High contrast ${e.target.checked ? 'on' : 'off'}.`)}/></label>
        <label className="preference-toggle"><span className="preference-icon"><Icon name="pause" size={22}/></span><span><strong>Reduce motion</strong><small>No decorative transitions or moving indicators.</small></span><input type="checkbox" role="switch" checked={settings.reduceMotion} onChange={e => change({ ...settings, reduceMotion: e.target.checked }, `Reduced motion ${e.target.checked ? 'on' : 'off'}.`)}/></label>
        <label className="preference-toggle"><span className="preference-icon"><Icon name="book" size={22}/></span><span><strong>Comfortable reading</strong><small>System font, more line spacing, and less visual clutter.</small></span><input type="checkbox" role="switch" checked={settings.readingMode} onChange={e => change({ ...settings, readingMode: e.target.checked }, `Comfortable reading ${e.target.checked ? 'on' : 'off'}.`)}/></label>
      </div>
      <div className="keyboard-guide"><Icon name="keyboard" size={20}/><div><h3>Every task works with a keyboard.</h3><p><kbd>Tab</kbd> or <kbd>Shift + Tab</kbd> moves between controls. <kbd>Enter</kbd> activates buttons. <kbd>Esc</kbd> closes dialogs. You can also use your device’s dictation to enter an organization name.</p></div></div>
      <p className="preference-saved"><Icon name="lock" size={15}/>Saved only in this browser. No disability information is collected.</p>
      <p className="sr-only" role="status" aria-live="polite" aria-atomic="true">{message}</p>
    </div>
    <div className="modal-footer"><button className="text-button" onClick={() => { onReset(); setMessage('Display preferences reset to defaults.'); }}><Icon name="refresh" size={16}/>Reset preferences</button><button className="button primary" onClick={onClose}>Done<Icon name="check" size={17}/></button></div>
  </Modal>;
}
