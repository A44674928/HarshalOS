import { beforeCutoff, createAudit, newInput, questions, today, type Answer, type AuditInput, type AuditRecord, type AutomationMetadata, type AutomationSource, type CoverageEntry, type DateBasis, type Version } from './engine';
import { externalOverrideQuote, lookupArchivedSnapshot, registryLabels, searchPublicRegistries, type PublicRecord, type RegistryName, type RegistrySearch } from './sources';
import { fetchJson } from './network';
import { artifactDate, canonicalUrl, isCalendarDate, isObject, parseArchiveUrl, sameResource, safePublicUrl, withinCalendarMonths } from './validation';
export { safePublicUrl } from './validation';
export type { CoverageEntry } from './engine';

export type Organization = { name: string; identifier: string; description: string; website: string; articleUrl: string; pageId: number };
export type ResearchProgress = { step: number; message: string; completed: number; total: number };
export type AutomaticResult = { organization: Organization; input: AuditInput; record: AuditRecord; sources: AutomationSource[]; warnings: string[]; coverage: CoverageEntry[]; method: 'public-lookup' | 'web-research'; completedAt: string };
export type ResearchAvailability = { enabled: boolean; provider: string };
type ReaderData = { title?: string; url?: string; content?: string; publishedTime?: string; metadata?: Record<string, unknown>; httpStatus?: number };
export type ResearchDocument = { title: string; url: string; content: string; published: string | null; official: boolean; archived?: string | null; liveUrl?: string; liveContent?: string; scoringEligible?: boolean; archiveStatus?: 'found' | 'no-match' | 'unavailable' | 'not-needed'; dateBasis?: DateBasis };
type Document = ResearchDocument;
type WikiPage = { pageid: number; title: string; index?: number; extract?: string; fullurl?: string; pageprops?: { wikibase_item?: string; disambiguation?: string } };
type Claim = { rank?: string; qualifiers?: Record<string, unknown>; mainsnak?: { datavalue?: { value?: unknown } } };
type ProviderResponse = { organization?: { name?: string; identifier?: string; description?: string; website?: string }; answers?: Partial<Answer>[]; constraints?: Partial<Answer>[]; b4?: Partial<AuditInput['b4']>; c2?: Partial<AuditInput['c2']>; external?: Partial<AuditInput['external']>; sources?: AutomationSource[]; warnings?: string[]; provider?: string };

export class OrganizationChoiceError extends Error {
  candidates: Organization[];
  constructor(candidates: Organization[]) { super('Several public records match this name. Choose the organization you mean.'); this.name = 'OrganizationChoiceError'; this.candidates = candidates; }
}
function apiUrl(base: string, parameters: Record<string, string>) {
  const url = new URL(base); for (const [key, value] of Object.entries({ ...parameters, format: 'json', origin: '*' })) url.searchParams.set(key, value); return url.href;
}
export async function researchAvailability(signal: AbortSignal): Promise<ResearchAvailability> {
  try {
    const data = await fetchJson<unknown>('/api/research/status', { signal, timeoutMs: 3000 });
    return { enabled: isObject(data) && data.enabled === true, provider: isObject(data) && typeof data.provider === 'string' ? data.provider : 'Public-record research' };
  } catch { signal.throwIfAborted(); return { enabled: false, provider: 'Public-record research' }; }
}
function normalName(value: string) { return value.toLocaleLowerCase().replace(/[^\p{L}\p{N}]/gu, ''); }
function sameSite(value: string, website: string) {
  try { const host = new URL(value).hostname.replace(/^www\./, ''), official = new URL(website).hostname.replace(/^www\./, ''); return host === official || host.endsWith(`.${official}`); } catch { return false; }
}
const monthsBefore = withinCalendarMonths;

export async function lookupOrganizations(name: string, signal: AbortSignal): Promise<Organization[]> {
  const url = apiUrl('https://en.wikipedia.org/w/api.php', { action: 'query', generator: 'search', gsrsearch: name, gsrnamespace: '0', gsrlimit: '4', prop: 'pageprops|extracts|info', exintro: '1', explaintext: '1', exsentences: '3', exlimit: 'max', inprop: 'url', formatversion: '2' });
  const result = await fetchJson<{ query?: { pages?: WikiPage[] } }>(url, { signal });
  if (!isObject(result) || result.query && !Array.isArray(result.query.pages)) throw new Error('The public directory returned an unexpected response. Try again or use a manual audit.');
  const pages: WikiPage[] = (result.query?.pages || []).filter((page: WikiPage) => page.pageprops?.wikibase_item && page.pageprops?.disambiguation === undefined).sort((a: WikiPage, b: WikiPage) => (a.index || 0) - (b.index || 0));
  if (!pages.length) return [];
  const entityResponse = await fetchJson<{ entities?: Record<string, { labels?: { en?: { value?: string } }; descriptions?: { en?: { value?: string } }; claims?: { P856?: Claim[] } }> }>(apiUrl('https://www.wikidata.org/w/api.php', { action: 'wbgetentities', ids: pages.map(p => p.pageprops!.wikibase_item).join('|'), props: 'labels|descriptions|claims', languages: 'en' }), { signal });
  if (!isObject(entityResponse) || !isObject(entityResponse.entities)) throw new Error('The public identity record could not be retrieved. Please try again.');
  const entities = entityResponse.entities;
  return pages.map(page => {
    const identifier = page.pageprops!.wikibase_item!;
    const entity = entities[identifier] || {};
    const websites: Claim[] = (entity.claims?.P856 || []).filter((claim: Claim) => claim.rank !== 'deprecated' && !claim.qualifiers?.P582).sort((a: Claim, b: Claim) => Number(b.rank === 'preferred') - Number(a.rank === 'preferred'));
    const website = websites.map(claim => claim.mainsnak?.datavalue?.value).find((v): v is string => typeof v === 'string' && safePublicUrl(v)) || '';
    return { name: entity.labels?.en?.value || page.title, identifier, website, description: page.extract || entity.descriptions?.en?.value || 'Public identity record; operational behavior is not yet assessed.', articleUrl: page.fullurl || `https://en.wikipedia.org/wiki/${encodeURIComponent(page.title.replace(/ /g, '_'))}`, pageId: page.pageid };
  }).filter(org => !!org.website || /(organization|organisation|corporation|company|agency|bank|institution|foundation|government|association|university|nonprofit)/i.test(org.description));
}

export function publicationDate(data: ReaderData): string | null {
  const text = data.content || '';
  const dateLine = text.slice(0, 5000).match(/(?:effective(?:\s+date)?|last\s+updated|updated\s+on|published(?:\s+on)?)[\s:*#–-]{0,16}((?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}|\d{4}-\d{2}-\d{2}|\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4})/i);
  const metadata = data.metadata || {};
  const value = dateLine?.[1] || data.publishedTime || metadata['article:published_time'] || metadata['datePublished'];
  if (typeof value !== 'string' || !Number.isFinite(Date.parse(value))) return null;
  return artifactDate(value);
}
function stripMarkdown(value: string) { return value.replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[*_#`]/g, '').replace(/\s+/g, ' ').trim(); }
export async function readPublicPage(url: string, website: string, signal: AbortSignal): Promise<Document> {
  if (!safePublicUrl(url)) throw new Error('This source URL is not safe to retrieve.');
  const result = await fetchJson<{ data?: ReaderData }>(`https://r.jina.ai/${url}`, { signal, timeoutMs: 22000 });
  if (!isObject(result) || !isObject(result.data)) throw new Error('The public page reader returned an unexpected response.');
  const data = result.data;
  if (typeof data.httpStatus === 'number' && data.httpStatus >= 400 || typeof data.content !== 'string' || data.content.trim().length < 80) throw new Error('This page returned no usable public content.');
  const requestedArchive = parseArchiveUrl(url);
  const returnedUrl = safePublicUrl(data.url) ? data.url : url;
  const returnedArchive = parseArchiveUrl(returnedUrl);
  if (requestedArchive && !sameResource(returnedArchive?.original || returnedUrl, requestedArchive.original)) throw new Error('The archive reader returned a different page; this capture was not used as evidence.');
  const finalUrl = requestedArchive ? url : returnedUrl;
  const original = requestedArchive?.original || returnedArchive?.original || finalUrl;
  return { title: data.title || new URL(original).hostname, url: finalUrl, content: data.content.slice(0, 90000), published: publicationDate(data), official: sameSite(original, website), ...(requestedArchive ? { archived: requestedArchive.captured, liveUrl: original } : {}) };
}
/** Discovery uses live links; historical scoring uses a verified capture, even if the reader reports the original URL. */
export async function readWithArchive(url: string, website: string, cutoff: string, signal: AbortSignal): Promise<Document> {
  let live: Document | null = null; let liveError: unknown;
  try { live = await readPublicPage(url, website, signal); } catch (error) { signal.throwIfAborted(); liveError = error; }
  const historical = cutoff < today();
  if (live?.published && beforeCutoff(live.published, cutoff) && !historical) return { ...live, archiveStatus: 'not-needed', scoringEligible: true, dateBasis: 'publication', liveContent: live.content };
  const lookup = await lookupArchivedSnapshot(url, cutoff, signal);
  if (lookup.snapshot) {
    try {
      const archived = await readPublicPage(lookup.snapshot.url, website, signal);
      return { ...archived, url: lookup.snapshot.url, title: live?.title || archived.title, archived: lookup.snapshot.captured, liveUrl: url, liveContent: live?.content, archiveStatus: 'found', scoringEligible: !archived.published || beforeCutoff(archived.published, cutoff), dateBasis: archived.published ? 'publication' : 'archive-capture' };
    } catch (error) { signal.throwIfAborted(); if (!live) throw error; }
  }
  if (!live) throw liveError instanceof Error ? liveError : new Error('Neither the live page nor a qualifying archive capture was readable.');
  return { ...live, liveContent: live.content, archiveStatus: lookup.status === 'found' ? 'unavailable' : lookup.status, scoringEligible: !historical && !!live.published && beforeCutoff(live.published, cutoff), dateBasis: live.published ? 'publication' : 'unknown' };
}
export function policyLinks(content: string, website: string): string[] {
  const links: { url: string; score: number }[] = [];
  for (const match of content.matchAll(/\[([^\]]{1,100})\]\(([^\s)]+)\)/g)) {
    const label = match[1]; let url: string;
    try { url = new URL(match[2], website).href.split('#')[0]; const archivedLink = parseArchiveUrl(url); if (archivedLink) url = archivedLink.original; } catch { continue; }
    if (!safePublicUrl(url) || !sameSite(url, website) || /\.(png|jpg|svg|mp4|pdf)(?:\?|$)/i.test(url)) continue;
    const score = /terms(?:\s+of\s+(?:use|service))?|conditions|appeal|governance|charter|enforcement|constitution|transparency|accountability|bylaws|oversight/i.test(label) ? 3 : /polic(?:y|ies)|safety|usage|acceptable|compliance|report/i.test(label) ? 2 : 0;
    if (score) links.push({ url, score });
  }
  return links.sort((a, b) => b.score - a.score).filter((entry, i, all) => all.findIndex(e => e.url === entry.url) === i).map(e => e.url).slice(0, 6);
}

type SignalRule = { value: boolean; expression: RegExp; basis?: string };
const behaviorRules: SignalRule[][] = [
  [{ value: true, expression: /(?:we|the (?:company|institution|organization))\s+(?:may|will|can|reserve the right to)\s+(?:suspend|terminate|restrict|revoke|withdraw|disable|ban)[^.!?\n]{10,500}(?:violation|violat|breach|non.compliance|comply)/i }, { value: true, expression: /(?:violation|breach|non.compliance)[^.!?\n]{10,350}(?:penalt|suspend|suspension|terminat|revok|revocation|fine|fined|ban(?:ned)?|disqualif)/i }],
  [{ value: true, expression: /(?:recommendations|decisions|guidance|participation)[^.!?\n]{0,100}(?:non.binding|voluntary|advisory only)/i }, { value: false, expression: /(?:failure to comply|violat(?:ion|ing)|breach)[^.!?\n]{0,250}(?:penalt|suspend|suspension|terminat|revok|revocation|fine|fined|ban(?:ned)?|disqualif)/i }],
  [{ value: true, expression: /(?:accounts?|licenses?|access|funding)\s+(?:was|were|has been|have been)\s+(?:suspended|revoked|restricted|withdrawn|terminated)[^.!?\n]{0,300}(?:violation|breach|policy|non.compliance)/i }, { value: true, expression: /(?:in accordance with|under|pursuant to)\s+[^.!?\n]{0,100}(?:policy|directive|rule)[^.!?\n]{0,200}(?:was|were|has been|have been)\s+(?:enforced|implemented|blocked|restricted|revoked)/i }],
  [{ value: true, expression: /(?:appeal|refusal)[^.!?\n]{0,130}(?:automatically stays|automatically suspends|must halt|shall halt)[^.!?\n]{0,130}/i, basis: 'TERMINAL_RULE' }],
  [{ value: true, expression: /(?:rules|polic(?:y|ies)|decisions|these terms)[^.!?\n]{0,160}(?:remain|continue)[^.!?\n]{0,80}(?:until (?:repealed|revoked|terminated|changed|amended)|unless (?:repealed|revoked|changed))/i }, { value: false, expression: /(?:rules|polic(?:y|ies)|decisions|authority)[^.!?\n]{0,160}(?:automatically expir|sunset clause|must be renewed|require(?:s)? periodic renewal)/i }],
];
const constraintRules: SignalRule[][] = [[], [], [{ value: true, expression: /(?:decisions|polic(?:y|ies)|authority|rules)[^.!?\n]{0,160}(?:automatically expir|sunset clause|must be renewed|require(?:s)? periodic renewal)/i }], []];
function quoteMatch(doc: Document, rules: SignalRule[]) {
  const plain = stripMarkdown(doc.content);
  for (const rule of rules) { const match = rule.expression.exec(plain); if (match) return { quote: match[0].slice(0, 600), rule }; }
  return null;
}
function recordSource(record: PublicRecord): AutomationSource {
  return { id: record.id, title: record.title, url: record.url, published: record.published, retrieved: record.retrieved, excerpt: record.excerpt, codes: [...record.codes], kind: record.kind, dateBasis: record.kind === 'news' ? 'indexed' : record.published ? 'publication' : 'unknown' };
}

export function preparePublicInput(organization: Organization, documents: Document[], registryRecords: PublicRecord[], version: Version, cutoff: string): { input: AuditInput; sources: AutomationSource[] } {
  const input = newInput(version); input.name = organization.name; input.identifier = organization.identifier; input.cutoff = cutoff;
  const candidates: AutomationSource[] = [
    ...documents.map((doc, i): AutomationSource => ({ id: `SITE-${i + 1}`, title: doc.archived ? `${doc.title} (archived ${doc.archived})` : doc.title, url: doc.url, published: doc.published, retrieved: new Date().toISOString(), excerpt: stripMarkdown(doc.content).slice(0, 650), codes: [], kind: doc.archived ? 'archive' : doc.official ? 'official' : 'context', dateBasis: doc.dateBasis || (doc.published ? 'publication' : doc.archived ? 'archive-capture' : 'unknown'), ...(doc.archived ? { capturedAt: doc.archived, originalUrl: doc.liveUrl } : {}) })),
    ...registryRecords.map(recordSource),
  ];
  const sources = candidates.filter((source, i, all) => safePublicUrl(source.url) && all.findIndex(s => canonicalUrl(s.url) === canonicalUrl(source.url)) === i);
  const officialCount = documents.filter(d => d.official).length;
  const gap = (code: string, extra = '') => `Searched ${officialCount} official page${officialCount === 1 ? '' : 's'} plus court, regulatory, legislative, news, and archive indexes for ${organization.name} through ${cutoff}. No dated qualifying ${code} artifact was matched.${extra} This is a coverage gap, not proof of a negative.`;
  const answer = (code: string, rules: SignalRule[]): Answer => {
    for (const doc of documents) {
      if (!doc.official || doc.scoringEligible === false) continue;
      const match = quoteMatch(doc, rules);
      if (!match) continue;
      const source = sources.find(s => s.url === doc.url)!;
      const evidenceDate = doc.published || doc.archived;
      if (!source || !evidenceDate || !beforeCutoff(evidenceDate, cutoff)) continue;
      source.codes = Array.from(new Set([...source.codes, code])); source.excerpt = match.quote;
      if (code === 'B4' && match.rule.basis) input.b4 = { ...input.b4, actor: 'Affected party named by the cited appeal rule — review required', action: 'The action specified in the cited operative rule — review required', procedure: match.quote, basis: match.rule.basis };
      return { value: match.rule.value, source: doc.url, date: evidenceDate, notes: match.quote, gap: match.rule.value ? '' : 'Contrary artifact located; inspect scope before accepting this suggested NO.' };
    }
    return { value: false, source: '', date: '', notes: '', gap: gap(code) };
  };
  input.answers = behaviorRules.map((rules, i) => answer(`B${i + 1}`, rules));
  input.constraints = constraintRules.map((rules, i) => answer(`C${i + 1}`, rules));

  // Score only operative SOURCE wording about this entity's action, never the app's reading instructions.
  const authorityRecords = registryRecords.filter(r => ['court', 'regulatory'].includes(r.kind) && r.named && r.published && beforeCutoff(r.published, cutoff));
  const overrides = authorityRecords.flatMap(record => { const quote = externalOverrideQuote(record, organization.name); return quote ? [{ record, quote }] : []; });
  const c1 = overrides.find(({ record }) => monthsBefore(record.published!, cutoff, 24));
  const c4 = overrides.find(({ record }) => monthsBefore(record.published!, cutoff, 12));
  for (const [index, override] of [[0, c1], [3, c4]] as const) {
    if (!override) { input.constraints[index].gap = gap(`C${index + 1}`, ` No operative source quotation demonstrates an external override within ${index === 0 ? 24 : 12} months. Captions, filing dates, requests, denials, and app-written guidance are not relief.`); continue; }
    const { record, quote } = override; const source = sources.find(s => canonicalUrl(s.url) === canonicalUrl(record.url));
    if (source) source.codes = Array.from(new Set([...source.codes, `C${index + 1}`]));
    input.constraints[index] = { value: true, source: record.url, date: record.published!, notes: quote, gap: '' };
  }
  input.constraints[1].gap = `${gap('C2')} A complete published appeal outcome set, numerator, denominator, and at least 50% relief were not demonstrated.`;
  const authority = c1?.record || authorityRecords[0];
  if (authority) input.external = { exists: true, exercised: overrides.some(o => o.record.url === authority.url), holder: authority.authority, scope: authority.title, source: authority.url, date: authority.published! };

  input.automation = { method: 'public-lookup', provider: 'Wikimedia, official site, Wayback, CourtListener, Federal Register, GovTrack, GDELT', reviewRequired: true, requestedName: organization.name, generatedAt: new Date().toISOString(), sources };
  return { input, sources };
}

function sanitizeAnswer(value: Partial<Answer> | undefined, sources: AutomationSource[], cutoff: string, code: string): Answer {
  const source = typeof value?.source === 'string' ? sources.find(s => canonicalUrl(s.url) === canonicalUrl(value.source!)) : undefined;
  const notes = typeof value?.notes === 'string' ? value.notes.slice(0, 1200) : '';
  const date = typeof value?.date === 'string' ? value.date.slice(0, 10) : '';
  const valid = !!source && source.kind !== 'news' && source.dateBasis !== 'indexed' && safePublicUrl(source.url) && beforeCutoff(date, cutoff) && date === (source.published || source.capturedAt) && notes.trim().length >= 10;
  if (!valid) return { value: false, source: '', date: '', notes: '', gap: `${code}: The hosted research did not return a qualifying, dated, consulted source. Unsupported is scored NO, not a proven negative.` };
  source.codes = Array.from(new Set([...(source.codes || []), code]));
  return { value: value?.value === true, source: source.url, date, notes, gap: typeof value?.gap === 'string' ? value.gap.slice(0, 1200) : '' };
}
function safeRecord<T extends Record<string, string | boolean>>(defaults: T, incoming: Partial<T> | undefined): T {
  const result = { ...defaults };
  if (!incoming || typeof incoming !== 'object') return result;
  for (const key of Object.keys(defaults) as (keyof T)[]) {
    if (typeof incoming[key] === typeof defaults[key]) result[key] = (typeof incoming[key] === 'string' ? String(incoming[key]).slice(0, 1600) : incoming[key]) as T[keyof T];
  }
  return result;
}
async function hostedResearch(name: string, version: Version, cutoff: string, signal: AbortSignal, onProgress: (progress: ResearchProgress) => void): Promise<{ organization: Organization; input: AuditInput; sources: AutomationSource[]; warnings: string[] }> {
  onProgress({ step: 2, message: 'Researching policies, court records, regulators, and news coverage…', completed: 2, total: 5 });
  const data = await fetchJson<ProviderResponse>('/api/research', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, version, cutoff }), signal, timeoutMs: 180000 });
  if (!isObject(data) || typeof data.organization?.name !== 'string' || !Array.isArray(data.answers) || data.answers.length !== 5 || !Array.isArray(data.constraints) || data.constraints.length !== 4 || !Array.isArray(data.sources)) throw new Error('The research service returned an incomplete record. No audit was saved.');
  const organization: Organization = { name: data.organization.name.slice(0, 200), identifier: (data.organization.identifier || '').slice(0, 100), description: (data.organization.description || '').slice(0, 1500), website: safePublicUrl(data.organization.website || '') ? data.organization.website! : '', articleUrl: '', pageId: 0 };
  const sources: AutomationSource[] = data.sources.filter(s => isObject(s) && safePublicUrl(s.url) && typeof s.title === 'string').slice(0, 20).map((s, i) => ({ id: `WEB-${i + 1}`, title: s.title.slice(0, 200), url: s.url, published: artifactDate(s.published), retrieved: new Date().toISOString(), excerpt: typeof s.excerpt === 'string' ? s.excerpt.slice(0, 1500) : '', codes: [], kind: ['official', 'court', 'regulatory', 'legislative', 'news', 'archive', 'context', 'public'].includes(s.kind) ? s.kind : 'context', dateBasis: s.kind === 'news' ? 'indexed' : 'publication' }));
  const input = newInput(version); input.name = organization.name; input.identifier = organization.identifier; input.cutoff = cutoff;
  input.answers = data.answers.map((a, i) => sanitizeAnswer(a, sources, cutoff, `B${i + 1}`));
  input.constraints = data.constraints.map((a, i) => sanitizeAnswer(a, sources, cutoff, `C${i + 1}`));
  input.b4 = safeRecord(input.b4, data.b4); input.c2 = safeRecord(input.c2, data.c2); input.external = safeRecord(input.external, data.external);
  input.automation = { method: 'web-research', provider: data.provider || 'Hosted web research', requestedName: name, generatedAt: new Date().toISOString(), reviewRequired: true, sources };
  return { organization, input, sources, warnings: (Array.isArray(data.warnings) ? data.warnings : []).filter(w => typeof w === 'string').slice(0, 10) };
}

export async function automaticAudit({ name, version, cutoff, existing, signal, onProgress, selection, availability }: { name: string; version: Version; cutoff: string; existing: AuditRecord[]; signal: AbortSignal; onProgress: (progress: ResearchProgress) => void; selection?: Organization; availability?: ResearchAvailability }): Promise<AutomaticResult> {
  const trimmed = name.trim();
  if (trimmed.length < 2 || trimmed.length > 160) throw new Error('Enter an organization name between 2 and 160 characters.');
  if (!isCalendarDate(cutoff)) throw new Error('Choose a valid inclusive evidence cutoff.');
  let progressStep = 0; const callback = onProgress;
  onProgress = progress => { signal.throwIfAborted(); progressStep = Math.max(progressStep, progress.step); callback({ ...progress, step: progressStep, completed: Math.max(progressStep, progress.completed) }); };
  onProgress({ step: 0, message: 'Looking for the organization’s public identity…', completed: 0, total: 5 });
  const service = availability || await researchAvailability(signal);
  let organization: Organization; let input: AuditInput; let sources: AutomationSource[]; const warnings: string[] = []; const coverage: CoverageEntry[] = [];
  let method: AutomaticResult['method'] = 'public-lookup';
  if (service.enabled && !selection) {
    const result = await hostedResearch(trimmed, version, cutoff, signal, onProgress);
    organization = result.organization; input = result.input; sources = result.sources; warnings.push(...result.warnings); method = 'web-research';
    coverage.push({ registry: 'Hosted web research', scope: 'Model-directed search across public web, court, regulatory, and news sources', source: result.input.automation!.provider, found: sources.length, mentions: 0, status: sources.length ? 'searched' : 'no-match' });
  } else {
    const candidates = selection ? [selection] : await lookupOrganizations(trimmed, signal);
    if (!candidates.length) throw new Error('No organization with a usable public identity was found. Try its full name or add its country. Nothing has been classified or saved.');
    const exact = candidates.filter(c => normalName(c.name) === normalName(trimmed));
    if (!selection && exact.length !== 1 && candidates.length > 1) throw new OrganizationChoiceError(candidates);
    organization = selection || exact[0] || candidates[0];
    onProgress({ step: 1, message: `Found ${organization.name}. Reading its official site and archived captures…`, completed: 1, total: 5 });
    const documents: Document[] = [{ title: `${organization.name} — public identity`, url: organization.articleUrl, content: organization.description, published: null, official: false }];
    const registryNames: string[] = [];
    const registryPromise = searchPublicRegistries(organization.name, cutoff, signal, registry => { registryNames.push(registryLabels[registry].label.toLowerCase()); onProgress({ step: 3, message: `Searched ${registryNames.join(', ')}…`, completed: 3, total: 5 }); }).catch((): RegistrySearch => { signal.throwIfAborted(); return { records: [], gaps: ['Public registries could not be searched for this run.'], consulted: [], outcomes: (['courts', 'regulatory', 'legislative', 'news'] as RegistryName[]).map(registry => ({ registry, status: 'unavailable' })) }; });
    if (organization.website) {
      try {
        const home = await readWithArchive(organization.website, organization.website, cutoff, signal); documents.push(home);
        const links = policyLinks(home.liveContent || home.content, organization.website).filter(url => !sameResource(url, organization.website));
        onProgress({ step: 2, message: `Reading ${links.length} policy page${links.length === 1 ? '' : 's'}, then searching court, regulatory, legislative, and news records…`, completed: 2, total: 5 });
        const retrieved = await Promise.allSettled(links.map(url => readWithArchive(url, organization.website, cutoff, signal)));
        for (const result of retrieved) { signal.throwIfAborted(); if (result.status === 'fulfilled') { if (!documents.some(d => canonicalUrl(d.url) === canonicalUrl(result.value.url))) documents.push(result.value); } else warnings.push(result.reason instanceof Error ? result.reason.message : 'A linked policy page was unavailable.'); }
        if (!links.length) warnings.push('No terms, governance, or appeal pages were discoverable among the homepage links. The lookup follows homepage links; it does not crawl the entire website.');
      } catch (error) { signal.throwIfAborted(); warnings.push(error instanceof Error ? error.message : 'The official website could not be read.'); }
    } else warnings.push('No current official website was available in the public identity record.');
    onProgress({ step: 3, message: 'Matching court, regulatory, legislative, and news records to this organization…', completed: 3, total: 5 });
    const registries = await registryPromise;
    signal.throwIfAborted();
    const documented = documents.filter(d => d.official).length;
    const archivedCount = documents.filter(d => d.archived).length;
    coverage.push({ registry: 'Official pages', scope: 'Homepage and linked policy, governance, and appeal pages', source: organization.website ? new URL(organization.website).hostname : 'No listed website', found: documented, mentions: 0, status: documented ? 'searched' : 'unavailable' });
    const archiveAttempts = documents.filter(d => d.official && d.archiveStatus && d.archiveStatus !== 'not-needed');
    const archiveFailures = archiveAttempts.filter(d => d.archiveStatus === 'unavailable').length;
    coverage.push({ registry: registryLabels.archive.label, scope: registryLabels.archive.scope, source: registryLabels.archive.source, found: archivedCount, mentions: 0, status: archiveFailures ? archivedCount ? 'partial' : 'unavailable' : archivedCount ? 'searched' : archiveAttempts.length ? 'no-match' : documented ? 'not-needed' : 'not-searched' });
    for (const registry of ['courts', 'regulatory', 'legislative', 'news'] as const) {
      const prefix = { courts: 'COURT', regulatory: 'REG', legislative: 'LEG', news: 'NEWS' }[registry];
      const matched = registries.records.filter(record => record.id.startsWith(prefix));
      const found = matched.filter(record => record.named).length;
      const mentions = matched.length - found;
      const outcome = registries.outcomes?.find(o => o.registry === registry);
      coverage.push({ ...registryLabels[registry], registry: registryLabels[registry].label, found, mentions, status: outcome?.status || 'unavailable' });
    }
    const prepared = preparePublicInput(organization, documents, registries.records, version, cutoff); input = prepared.input; sources = prepared.sources;
    warnings.push(...registries.gaps);
    warnings.push('Court, regulatory, and legislative coverage is US-focused (CourtListener, Federal Register, GovTrack). Other jurisdictions, state and local bodies, sealed matters, and paywalled reporting are not indexed here.');
    if (archivedCount) warnings.push(`${archivedCount} page${archivedCount === 1 ? ' was' : 's were'} read from an Internet Archive capture taken on or before the cutoff, so live text is not mistaken for the version in force then.`);
    if (documents.some(d => d.official && d.scoringEligible === false)) warnings.push('Some official pages lack a qualifying date or a readable capture for this historical cutoff. They are retained as context, not credited as operative evidence.');
    warnings.push('News results are recorded as dated leads only. They are never scored as operative evidence; open the primary court, regulatory, or policy artifact to score a question.');
  }
  signal.throwIfAborted();
  onProgress({ step: 4, message: 'Applying the versioned phase rules and filling the working badge…', completed: 4, total: 5 });
  input.automation!.coverage = coverage; input.automation!.warnings = Array.from(new Set(warnings));
  const record = await createAudit(input, existing);
  signal.throwIfAborted();
  attachResearchSources(record, input.automation!, coverage);
  onProgress({ step: 5, message: 'Your research draft is ready. Review is required; the formal badge stays unissued.', completed: 5, total: 5 });
  return { organization, input, record, sources, warnings: Array.from(new Set(warnings)), coverage, method, completedAt: new Date().toISOString() };
}
export function attachResearchSources(record: AuditRecord, metadata: AutomationMetadata, coverage?: CoverageEntry[]): void {
  for (const source of metadata.sources) {
    if (record.evidence.some(e => e.url === source.url)) continue;
    record.evidence.push({ id: `${record.id}-${source.id}`, title: source.title, url: source.url, published: source.published || '', retrieved: source.retrieved.slice(0, 10), claim: source.excerpt || 'Source retrieved for context only; no qualifying operational claim extracted.', codes: [source.kind === 'news' ? 'NEWS LEAD — NEVER SCORED' : 'RESEARCH CONTEXT — UNSCORED'], entity: record.name });
  }
  record.report.Evidence_Summary = record.evidence;
  record.report.Research_Sources = metadata.sources.map(source => ({ ...source, Cutoff_Status: source.published ? beforeCutoff(source.published, record.cutoff) ? 'DATED BEFORE CUTOFF — CLAIM REVIEW REQUIRED' : 'AFTER CUTOFF — NOT SCORED' : 'DATE NOT DEMONSTRATED — NOT SCORED' }));
  record.report.Automation = JSON.parse(JSON.stringify(metadata));
  record.report.Research_Limits = metadata.warnings || [];
  if (coverage) record.report.Registry_Coverage = coverage;
}
export function documentedAnswerCount(result: AutomaticResult): number {
  return result.record.workingBadge.filled;
}
export function plainResearchSummary(result: AutomaticResult): string {
  const badge = result.record.workingBadge;
  return [
    `GROUND-0 AUTOMATIC RESEARCH DRAFT — ${result.organization.name}`,
    `Version: v${result.input.version}${result.input.version === '1.1' ? ' (unratified amendment draft)' : ' (normative baseline)'}`,
    `Evidence cutoff: ${result.input.cutoff} (inclusive, UTC)`,
    `Working badge: ${badge.label} — ${badge.filled} of 5 questions evidenced. ${badge.explanation}`,
    `Formal badge status: ${result.record.badge}. Provisional phase: ${result.record.phase}. Confidence: ${result.record.confidence}. Human review required.`,
    '', result.record.finding, '',
    'SOURCES SEARCHED',
    ...result.coverage.map(entry => `${entry.registry}: ${entry.status === 'unavailable' ? 'unavailable this run' : `${entry.found} matching record(s)`} — ${entry.scope} (${entry.source})`),
    '',
    ...questions.map((q, i) => `${q.code}: ${q.title}\nSuggested score: ${result.input.answers[i].value ? 'YES' : 'NO / not demonstrated'}\n${result.input.answers[i].notes || result.input.answers[i].gap}\n${result.input.answers[i].source || 'No qualifying dated citation'}`),
    '', 'RETRIEVED SOURCES (not all sources qualify for scoring)',
    ...result.sources.map(s => `[${s.kind.toUpperCase()}] ${s.title}\n${s.url}\nPublished/effective: ${s.published || 'not demonstrated'}\nRetrieved: ${s.retrieved}\n${s.excerpt}`),
    '', 'LIMITATIONS', ...result.warnings,
  ].join('\n\n');
}
