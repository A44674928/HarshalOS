import { computeWorkingBadge, emptyAnswer, newInput, type Answer, type AuditInput, type AuditRecord, type AutomationMetadata, type AutomationSource, type CoverageEntry, type Evidence, type PDHResult, type Phase, type SourceKind, type Transition } from './engine';
import { dateTime, isCalendarDate, isObject, safePublicUrl } from './validation';

const phases: Phase[] = ['NAB', 'CWO', 'NAB-Constrained', 'GSRB', 'AMBIGUOUS', 'INCOHERENT'];
const sourceKinds: SourceKind[] = ['official', 'court', 'regulatory', 'legislative', 'news', 'archive', 'public', 'context'];
const text = (value: unknown, fallback = '') => typeof value === 'string' ? value : fallback;
const strings = (value: unknown): string[] => Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string') : [];
export function normalizeAnswer(value: unknown): Answer {
  if (!isObject(value)) return emptyAnswer();
  return { value: typeof value.value === 'boolean' ? value.value : null, source: safePublicUrl(value.source) ? value.source : '', date: text(value.date), notes: text(value.notes), gap: text(value.gap) };
}
function typedFields<T extends Record<string, string | boolean>>(defaults: T, value: unknown): T {
  const result = { ...defaults };
  if (isObject(value)) for (const key of Object.keys(defaults) as (keyof T)[]) if (typeof value[String(key)] === typeof defaults[key]) result[key] = value[String(key)] as T[keyof T];
  return result;
}
function normalizeCoverage(value: unknown): CoverageEntry[] {
  if (!Array.isArray(value)) return [];
  return value.filter(isObject).filter(c => typeof c.registry === 'string').map(c => ({ registry: text(c.registry), scope: text(c.scope), source: text(c.source), found: typeof c.found === 'number' && Number.isFinite(c.found) ? Math.max(0, c.found) : 0, mentions: typeof c.mentions === 'number' && Number.isFinite(c.mentions) ? Math.max(0, c.mentions) : 0, status: ['searched', 'no-match', 'unavailable', 'partial', 'not-needed', 'not-searched'].includes(text(c.status)) ? c.status as CoverageEntry['status'] : 'not-searched' }));
}
function normalizeSources(value: unknown): AutomationSource[] {
  if (!Array.isArray(value)) return [];
  const used = new Set<string>();
  return value.filter(isObject).filter(s => safePublicUrl(s.url)).map((s, i) => {
    let id = text(s.id, `RECOVERED-SOURCE-${i + 1}`); if (used.has(id)) id = `${id}-${i + 1}`; used.add(id);
    return { id, title: text(s.title, 'Public source'), url: s.url as string, published: isCalendarDate(s.published) ? s.published : null, retrieved: Number.isFinite(dateTime(s.retrieved)) ? s.retrieved as string : '', excerpt: text(s.excerpt), codes: Array.from(new Set(strings(s.codes))), kind: sourceKinds.includes(s.kind as SourceKind) ? s.kind as SourceKind : 'context', ...(isCalendarDate(s.capturedAt) ? { capturedAt: s.capturedAt } : {}), ...(safePublicUrl(s.originalUrl) ? { originalUrl: s.originalUrl } : {}), ...(['publication', 'archive-capture', 'indexed', 'unknown'].includes(text(s.dateBasis)) ? { dateBasis: s.dateBasis as AutomationSource['dateBasis'] } : {}) };
  });
}
export function normalizeAuditInput(value: unknown, fallbackVersion: AuditInput['version'] = '1.0'): AuditInput {
  const raw = isObject(value) ? value : {};
  const defaults = newInput(raw.version === '1.1' ? '1.1' : fallbackVersion);
  let automation: AutomationMetadata | undefined;
  if (isObject(raw.automation)) {
    const a = raw.automation;
    automation = { method: a.method === 'web-research' ? 'web-research' : 'public-lookup', provider: text(a.provider, 'Public research'), requestedName: text(a.requestedName, text(raw.name)), generatedAt: text(a.generatedAt), reviewRequired: a.reviewRequired !== false, sources: normalizeSources(a.sources), coverage: normalizeCoverage(a.coverage), warnings: strings(a.warnings) };
  }
  return { ...defaults, name: text(raw.name), identifier: text(raw.identifier), cutoff: isCalendarDate(raw.cutoff) ? raw.cutoff : defaults.cutoff, answers: Array.from({ length: 5 }, (_, i) => normalizeAnswer(Array.isArray(raw.answers) ? raw.answers[i] : undefined)), constraints: Array.from({ length: 4 }, (_, i) => normalizeAnswer(Array.isArray(raw.constraints) ? raw.constraints[i] : undefined)), b4: typedFields(defaults.b4, raw.b4), c2: typedFields(defaults.c2, raw.c2), external: typedFields(defaults.external, raw.external), decrement: typedFields(defaults.decrement, raw.decrement), headerText: text(raw.headerText), publicKeyText: text(raw.publicKeyText), trustedOrigin: text(raw.trustedOrigin, defaults.trustedOrigin), ...(automation ? { automation } : {}) };
}
function normalizePdh(value: unknown): PDHResult {
  const raw = isObject(value) ? value : {};
  const status: PDHResult['status'] = raw.status === 'VALID' && raw.structural === true && raw.signature === true && raw.freshness === true && raw.consistency === true ? 'VALID' : raw.status === 'INVALID' || raw.status === 'VALID' ? 'INVALID' : 'MISSING';
  return { status, structural: raw.structural === true, signature: raw.signature === true, freshness: raw.freshness === true, consistency: raw.consistency === true, declared: status === 'VALID' && ['NAB', 'CWO', 'GSRB'].includes(text(raw.declared)) ? raw.declared as PDHResult['declared'] : 'NONE', reason: text(raw.reason, 'No verified Phase Declaration Header is present in this saved record.'), ...(typeof raw.headerId === 'string' ? { headerId: raw.headerId } : {}), ...(typeof raw.payload === 'string' ? { payload: raw.payload } : {}), ...(typeof raw.effectiveTimestamp === 'string' ? { effectiveTimestamp: raw.effectiveTimestamp } : {}) };
}
export function normalizeEvidence(value: unknown, index = 0): Evidence | null {
  if (!isObject(value) || !safePublicUrl(value.url)) return null;
  return { id: text(value.id, `RECOVERED-ARTIFACT-${index + 1}`), title: text(value.title, 'Public source'), url: value.url, published: Number.isFinite(dateTime(value.published)) ? value.published as string : '', retrieved: Number.isFinite(dateTime(value.retrieved)) ? value.retrieved as string : '', claim: text(value.claim), codes: strings(value.codes), entity: text(value.entity, 'Unlinked') };
}
function normalizeTransition(value: unknown): Transition | null {
  if (!isObject(value) || !phases.includes(value.from as Phase) || !phases.includes(value.to as Phase) || !isCalendarDate(value.fromDate) || !isCalendarDate(value.toDate)) return null;
  return { from: value.from as Phase, to: value.to as Phase, fromDate: value.fromDate, toDate: value.toDate, status: text(value.status, 'OBSERVED_ONLY'), pattern: text(value.pattern, 'N/A'), severity: text(value.severity, 'WARNING'), entryId: text(value.entryId), notes: text(value.notes) };
}
/** Hydrate older records without inventing evidence or a declaration, and rebuild only the working display badge. */
export function normalizeAuditRecord(value: unknown): AuditRecord | null {
  if (!isObject(value) || typeof value.id !== 'string' || !value.id || typeof value.name !== 'string' || !value.name.trim() || !phases.includes(value.phase as Phase)) return null;
  const version = value.version === '1.1' ? '1.1' : '1.0';
  const phase = value.phase as Phase;
  const input = normalizeAuditInput({ ...(isObject(value.input) ? value.input : {}), name: value.name, identifier: text(value.identifier), version, cutoff: value.cutoff, answers: isObject(value.input) && Array.isArray(value.input.answers) ? value.input.answers : value.answers, constraints: isObject(value.input) && Array.isArray(value.input.constraints) ? value.input.constraints : value.constraints }, version);
  const report = isObject(value.report) ? { ...value.report } : {};
  if (input.automation) {
    if (!input.automation.coverage?.length) input.automation.coverage = normalizeCoverage(report.Registry_Coverage);
    if (!input.automation.warnings?.length) input.automation.warnings = strings(report.Research_Limits);
  }
  const pdh = normalizePdh(value.pdh);
  const badge = typeof value.badge === 'string' && ['Confirmed', 'Reclassified', 'Invalid', 'Unissued', 'Conditional'].includes(value.badge) ? value.badge : 'Unissued';
  const status: AuditRecord['status'] = value.status === 'Complete' ? 'Complete' : value.status === 'Needs review' ? 'Needs review' : 'Draft';
  const workingBadge = computeWorkingBadge({ ...input, cutoff: isCalendarDate(value.cutoff) ? value.cutoff : '' }, phase, badge, status !== 'Draft' && !input.automation?.reviewRequired);
  report.Working_Badge = workingBadge;
  if (input.automation) { report.Automation = input.automation; report.Registry_Coverage = input.automation.coverage || []; }
  return { ...value, id: value.id, name: value.name, identifier: text(value.identifier), version, phase, createdAt: Number.isFinite(dateTime(value.createdAt)) ? value.createdAt as string : '', cutoff: isCalendarDate(value.cutoff) ? value.cutoff : '', reportedDeclared: text(value.reportedDeclared, 'None'), confidence: ['HIGH', 'MEDIUM', 'LOW', 'NONE'].includes(text(value.confidence)) ? value.confidence as AuditRecord['confidence'] : 'NONE', severity: text(value.severity, 'WARNING'), compliance: text(value.compliance, 'N/A'), badge, status, baseline: value.baseline === true, evidence: Array.isArray(value.evidence) ? value.evidence.map(normalizeEvidence).filter((e): e is Evidence => !!e) : [], answers: input.answers, constraints: input.constraints, pdh, finding: text(value.finding, 'This saved record lacks a complete finding; review the evidence before use.'), replicationRisk: text(value.replicationRisk, 'HIGH'), temporalPattern: text(value.temporalPattern, 'N/A'), transition: normalizeTransition(value.transition), workingBadge, ...(value.baseline === true ? { input: undefined } : { input }), report };
}
function preserveRecovery(key: string, original: string): void {
  try { if (!localStorage.getItem(`${key}-recovery`)) localStorage.setItem(`${key}-recovery`, original); } catch { /* Storage restrictions must not crash the workspace. */ }
}
function loadArray<T>(key: string, normalize: (value: unknown, index: number) => T | null): T[] {
  let original: string | null = null;
  try {
    original = localStorage.getItem(key);
    if (!original) return [];
    const parsed: unknown = JSON.parse(original);
    if (!Array.isArray(parsed)) { preserveRecovery(key, original); return []; }
    const items = parsed.map(normalize).filter((value): value is T => value !== null);
    if (JSON.stringify(items) !== JSON.stringify(parsed)) preserveRecovery(key, original);
    return items;
  } catch { if (original) preserveRecovery(key, original); return []; }
}
export function loadAuditRecords(): AuditRecord[] { return loadArray('ground-0-audits-v1', normalizeAuditRecord); }
export function loadEvidenceRecords(): Evidence[] { return loadArray('ground-0-evidence-v1', normalizeEvidence); }
