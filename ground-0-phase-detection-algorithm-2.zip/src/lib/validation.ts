const isoDay = /^\d{4}-\d{2}-\d{2}$/;
const isoTime = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,9})?)?(Z|[+-]\d{2}:\d{2})$/;

/** Reject dates that Date.parse silently rolls into a different month. */
export function isCalendarDate(value: unknown): value is string {
  if (typeof value !== 'string' || !isoDay.test(value) || Number(value.slice(0, 4)) < 1) return false;
  const time = Date.parse(`${value}T00:00:00Z`);
  return Number.isFinite(time) && new Date(time).toISOString().slice(0, 10) === value;
}
export function isIsoTimestamp(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  const match = value.match(isoTime);
  if (!match || !isCalendarDate(match[1]) || Number(match[2]) > 23 || Number(match[3]) > 59 || Number(match[4] || 0) > 59) return false;
  if (match[5] !== 'Z' && (Number(match[5].slice(1, 3)) > 23 || Number(match[5].slice(4)) > 59)) return false;
  return Number.isFinite(Date.parse(value));
}
export function dateTime(value: unknown): number {
  if (isCalendarDate(value)) return Date.parse(`${value}T00:00:00Z`);
  return isIsoTimestamp(value) ? Date.parse(value) : NaN;
}
export function eligibleByCutoff(date: unknown, cutoff: unknown): boolean {
  return isCalendarDate(cutoff) && Number.isFinite(dateTime(date)) && dateTime(date) <= Date.parse(`${cutoff}T23:59:59.999Z`);
}
/** Calendar-month lookbacks clamp the day, so March 31 minus one month is February's last day. */
export function withinCalendarMonths(date: string, cutoff: string, months: number): boolean {
  if (!eligibleByCutoff(date, cutoff)) return false;
  const end = new Date(`${cutoff}T00:00:00Z`);
  const day = end.getUTCDate(); end.setUTCDate(1); end.setUTCMonth(end.getUTCMonth() - months);
  const last = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth() + 1, 0)).getUTCDate();
  end.setUTCDate(Math.min(day, last));
  return dateTime(date) >= end.getTime();
}

const monthNames = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
export function artifactDate(value: unknown): string | null {
  if (isCalendarDate(value)) return value;
  if (isIsoTimestamp(value)) return new Date(value).toISOString().slice(0, 10);
  if (typeof value !== 'string') return null;
  const a = value.trim().match(/^([a-z]+)\s+(\d{1,2}),?\s+(\d{4})$/i);
  const b = value.trim().match(/^(\d{1,2})\s+([a-z]+)\s+(\d{4})$/i);
  const name = a?.[1] || b?.[2]; const day = a?.[2] || b?.[1]; const year = a?.[3] || b?.[3];
  if (!name || !day || !year) return null;
  const month = monthNames.indexOf(name.toLowerCase()) + 1;
  const normalized = `${year}-${String(month).padStart(2, '0')}-${day.padStart(2, '0')}`;
  return month > 0 && isCalendarDate(normalized) ? normalized : null;
}

export function safePublicUrl(value: unknown): value is string {
  if (typeof value !== 'string' || value.length > 2048) return false;
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase().replace(/\.$/, '');
    return ['https:', 'http:'].includes(url.protocol) && !url.username && !url.password && host.includes('.') &&
      !host.includes(':') && !/^\d+(?:\.\d+){3}$/.test(host) &&
      !['localhost', 'local', 'internal', 'test', 'invalid'].some(suffix => host === suffix || host.endsWith(`.${suffix}`));
  } catch { return false; }
}
export function canonicalUrl(value: string): string {
  try { const url = new URL(value); url.hash = ''; return url.href.replace(/\/$/, ''); } catch { return ''; }
}
/** Accept only actual Wayback capture URLs, never a query string that merely mentions the archive. */
export function parseArchiveUrl(value: unknown): { original: string; timestamp: string; captured: string } | null {
  if (!safePublicUrl(value)) return null;
  const url = new URL(value);
  if (url.hostname !== 'web.archive.org') return null;
  const match = `${url.pathname}${url.search}`.match(/^\/web\/(\d{14})(?:[a-z_]+)?\/(https?:\/\/.+)$/i);
  if (!match || !safePublicUrl(match[2])) return null;
  const stamp = match[1];
  const captured = `${stamp.slice(0, 4)}-${stamp.slice(4, 6)}-${stamp.slice(6, 8)}`;
  const timestamp = `${captured}T${stamp.slice(8, 10)}:${stamp.slice(10, 12)}:${stamp.slice(12, 14)}Z`;
  return isIsoTimestamp(timestamp) ? { original: match[2], timestamp: stamp, captured } : null;
}
export function sameResource(a: string, b: string): boolean {
  try {
    const first = new URL(a); const second = new URL(b);
    const host = (url: URL) => url.hostname.toLowerCase().replace(/^www\./, '');
    return host(first) === host(second) && first.pathname.replace(/\/$/, '') === second.pathname.replace(/\/$/, '') && first.search === second.search;
  } catch { return false; }
}
export function isObject(value: unknown): value is Record<string, unknown> { return !!value && typeof value === 'object' && !Array.isArray(value); }
