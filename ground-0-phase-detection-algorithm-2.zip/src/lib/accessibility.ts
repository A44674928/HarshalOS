import { useEffect, useState } from 'react';

export type AccessibilitySettings = { textSize: 'standard' | 'large' | 'larger'; highContrast: boolean; reduceMotion: boolean; readingMode: boolean };
const storageKey = 'ground-0-accessibility-v1';
export function defaultAccessibility(): AccessibilitySettings {
  return { textSize: 'standard', highContrast: false, reduceMotion: typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches, readingMode: false };
}
function readSettings(): AccessibilitySettings {
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey) || 'null');
    if (!stored || typeof stored !== 'object') return defaultAccessibility();
    return { textSize: ['standard', 'large', 'larger'].includes(stored.textSize) ? stored.textSize : 'standard', highContrast: stored.highContrast === true, reduceMotion: stored.reduceMotion === true || window.matchMedia('(prefers-reduced-motion: reduce)').matches, readingMode: stored.readingMode === true };
  } catch { return defaultAccessibility(); }
}
export function useAccessibility() {
  const [settings, setSettings] = useState<AccessibilitySettings>(readSettings);
  useEffect(() => {
    const root = document.documentElement;
    root.dataset.textSize = settings.textSize;
    root.dataset.contrast = settings.highContrast ? 'high' : 'standard';
    root.dataset.motion = settings.reduceMotion ? 'reduced' : 'system';
    root.dataset.reading = settings.readingMode ? 'easy' : 'standard';
    root.style.setProperty('--text-scale', settings.textSize === 'larger' ? '1.5' : settings.textSize === 'large' ? '1.25' : '1');
    try { localStorage.setItem(storageKey, JSON.stringify(settings)); } catch { /* Preferences still work in memory when storage is unavailable. */ }
  }, [settings]);
  return { settings, setSettings, reset: () => setSettings(defaultAccessibility()) };
}

export function readableAuditText(name: string, phase: string, finding: string, sourceCount: number): string {
  return `Automatic research draft for ${name}. Provisional operational phase: ${phase}. ${finding} ${sourceCount} public sources were retrieved. Human evidence review is required. No badge has been issued.`;
}
