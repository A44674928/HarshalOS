import { abortableDelay, fetchJson, HttpError } from './network';
import { artifactDate, canonicalUrl, eligibleByCutoff, isCalendarDate, isObject, parseArchiveUrl, safePublicUrl, sameResource } from './validation';

export type RecordKind = 'official' | 'court' | 'regulatory' | 'legislative' | 'news' | 'archive' | 'context';
export type PublicRecord = {
  id: string; kind: RecordKind; title: string; url: string; published: string | null; retrieved: string;
  excerpt: string; authority: string; scoreable: boolean; named: boolean; codes: string[];
  /** Only verbatim source text belongs here. Generated reading instructions must never activate a test. */
  claim?: string;
};
export type RegistryName = 'courts' | 'regulatory' | 'legislative' | 'news' | 'archive';
export type RegistryOutcome = { registry: RegistryName; status: 'searched' | 'no-match' | 'unavailable' | 'partial'; totalMatches?: number };
export type RegistrySearch = { records: PublicRecord[]; gaps: string[]; consulted: string[]; outcomes?: RegistryOutcome[] };
export const registryLabels: Record<RegistryName, { label: string; scope: string; source: string }> = {
  courts: { label: 'Court records', scope: 'Bounded US opinion and docket searches; not all proceedings', source: 'CourtListener (Free Law Project)' },
  regulatory: { label: 'Regulatory & executive record', scope: 'Bounded US Federal Register rules, notices, and orders', source: 'Federal Register API' },
  legislative: { label: 'Legislative record', scope: 'Bounded US Congressional bill and resolution search', source: 'GovTrack' },
  news: { label: 'News coverage', scope: 'Indexed English-language news leads; never scored', source: 'GDELT Project' },
  archive: { label: 'Archived snapshots', scope: 'Available policy captures on or before the cutoff', source: 'Internet Archive Wayback Machine' },
};
const now = () => new Date().toISOString();
const clean = (value: unknown, limit = 700): string => typeof value === 'string' ? value.replace(/<[^>]*>/g, ' ').replace(/&(?:amp|quot|lt|gt|nbsp);/gi, ' ').replace(/\s+/g, ' ').trim().slice(0, limit) : '';
function arrayField(data: unknown, field: string): Record<string, unknown>[] {
  if (!isObject(data) || !Array.isArray(data[field])) throw new Error('The public index returned an unexpected record format.');
  return data[field].filter(isObject);
}
function rank(records: PublicRecord[], namedLimit: number, mentionLimit: number): PublicRecord[] {
  const byUrl = new Map<string, PublicRecord>();
  for (const record of records) {
    if (!safePublicUrl(record.url)) continue;
    const key = canonicalUrl(record.url); const previous = byUrl.get(key);
    if (!previous || !previous.scoreable && record.scoreable) byUrl.set(key, record);
  }
  const all = Array.from(byUrl.values());
  return [...all.filter(r => r.named).slice(0, namedLimit), ...all.filter(r => !r.named).slice(0, mentionLimit)];
}
const ignoredNameWords = new Set(['the', 'inc', 'llc', 'ltd', 'plc', 'corporation', 'company', 'group', 'holdings', 'organization', 'organisation']);
export function mentionsEntity(text: string, name: string): boolean {
  const normalize = (value: string) => value.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
  const haystack = ` ${normalize(text)} `; const fullName = normalize(name);
  if (!fullName) return false;
  if (haystack.includes(` ${fullName} `)) return true;
  const words = fullName.split(' ').filter(word => word.length > 2 && !ignoredNameWords.has(word));
  return words.length > 0 && words.every(word => haystack.includes(` ${word} `));
}

/** A caption match is not a successful override. Require an actual decision about this entity's action. */
export function externalOverrideQuote(record: PublicRecord, name: string): string | null {
  if (!record.scoreable || !record.named || !record.claim || !['court', 'regulatory'].includes(record.kind)) return null;
  const namePattern = name.trim().split(/\s+/).map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('\\s+');
  if (!namePattern) return null;
  const entity = `(?:${namePattern})(?:['’]s)?`;
  const action = '(?:decision|order|rule|policy|directive|action|enforcement|deployment)';
  const acted = '(?:vacated|enjoined|overturned|reversed|rescinded|annulled|invalidated|struck down|set aside)';
  const target = `(?:${entity}[^.!?]{0,70}${action}|${action}[^.!?]{0,45}(?:of|by|from)\\s+(?:the\\s+)?${entity})`;
  const active = new RegExp(`(?:court|judge|tribunal|agency|regulator|commission|we)\\b[^.!?]{0,100}\\b${acted}\\b[^.!?]{0,80}${target}`, 'i');
  const passive = new RegExp(`${target}[^.!?]{0,90}\\b(?:was|were|has been|have been)\\s+${acted}\\b[^.!?]{0,80}\\b(?:court|judge|tribunal|agency|regulator)`, 'i');
  const stopOrder = new RegExp(`\\b(?:court|judge|regulator|agency|commission)\\b[^.!?]{0,90}\\b(?:ordered|enjoined)\\s+(?:the\\s+)?${entity}[^.!?]{0,65}\\bto\\s+(?:cease|halt|stop|suspend|withdraw)\\b`, 'i');
  const notOperative = /\b(?:not|never|denied|deny|declined|refused|requested|requests|seeks|sought|petitioned|moved|motion|could|may|might|would|proposed|alleged)\b/i;
  for (const sentence of record.claim.split(/(?<=[.!?])\s+/).filter(s => s.trim())) {
    if (notOperative.test(sentence) || !mentionsEntity(sentence, name)) continue;
    if (active.test(sentence) || passive.test(sentence) || stopOrder.test(sentence)) return sentence.trim().slice(0, 1000);
  }
  return null;
}

export async function searchCourtRecords(name: string, cutoff: string, signal: AbortSignal): Promise<RegistrySearch> {
  const records: PublicRecord[] = []; const gaps: string[] = []; const consulted: string[] = [];
  let successes = 0;
  for (const [type, kindLabel] of [['o', 'opinion'], ['r', 'docket']] as const) {
    signal.throwIfAborted();
    const [year, month, day] = cutoff.split('-');
    const url = new URL('https://www.courtlistener.com/api/rest/v4/search/');
    url.search = new URLSearchParams({ q: `"${name.replace(/"/g, '')}"`, type, order_by: 'dateFiled desc', filed_before: `${month}/${day}/${year}` }).toString();
    try {
      const data = await fetchJson(url.href, { signal, timeoutMs: 20000 });
      const rows = arrayField(data, 'results'); successes++; consulted.push(url.href);
      for (const [index, item] of rows.slice(0, 20).entries()) {
        const caseName = clean(item.caseName || item.case_name_full, 220); const filed = artifactDate(item.dateFiled);
        if (!caseName || !filed || !eligibleByCutoff(filed, cutoff)) continue;
        const named = mentionsEntity(caseName, name);
        const path = typeof item.absolute_url === 'string' ? item.absolute_url : typeof item.docket_absolute_url === 'string' ? item.docket_absolute_url : '';
        if (!path) continue;
        let recordUrl: string; try { recordUrl = new URL(path, 'https://www.courtlistener.com').href; } catch { continue; }
        if (!safePublicUrl(recordUrl) || new URL(recordUrl).hostname !== 'www.courtlistener.com') continue;
        const opinions = Array.isArray(item.opinions) ? item.opinions.filter(isObject) : [];
        const claim = clean(opinions.map(o => clean(o.snippet, 1200)).join(' ') || item.snippet, 1800);
        const docketContext = `${caseName}. Docket ${clean(item.docketNumber, 60) || 'not stated'}, filed ${filed}.`;
        records.push({ id: `COURT-${type}-${index + 1}`, kind: 'court', title: `${caseName} (${kindLabel})`, url: recordUrl, published: filed, retrieved: now(), authority: clean(item.court, 160) || 'Court', claim,
          excerpt: `${claim || docketContext}${named ? '' : ' Full-text mention only: confirm the entity and party before relying on this record.'}${type === 'r' ? ' A docket filing date is not evidence that relief was granted on that date.' : ' Read the original opinion to verify the action and its scope.'}`,
          scoreable: named && type === 'o' && !!claim, named, codes: [] });
      }
      if (isObject(data) && typeof data.count === 'number' && data.count > rows.length) gaps.push(`The ${kindLabel} index has more results than this bounded first-page search; older records may be missing.`);
    } catch { signal.throwIfAborted(); gaps.push(`Court ${kindLabel} search was unavailable or rate-limited; coverage for this run is incomplete.`); }
  }
  if (!records.some(r => r.named) && successes) gaps.push('No returned court caption named this organization by the cutoff. Full-text mentions, sealed matters, and non-US proceedings do not establish an exercised override.');
  return { records: rank(records, 8, 3), gaps, consulted, outcomes: [{ registry: 'courts', status: successes === 0 ? 'unavailable' : successes < 2 ? 'partial' : records.length ? 'searched' : 'no-match' }] };
}

export async function searchRegulatoryRecords(name: string, cutoff: string, signal: AbortSignal): Promise<RegistrySearch> {
  const url = new URL('https://www.federalregister.gov/api/v1/documents.json');
  url.searchParams.set('conditions[term]', `"${name.replace(/"/g, '')}"`); url.searchParams.set('conditions[publication_date][lte]', cutoff);
  url.searchParams.set('per_page', '10'); url.searchParams.set('order', 'newest');
  for (const field of ['title', 'publication_date', 'html_url', 'abstract', 'type', 'agencies']) url.searchParams.append('fields[]', field);
  try {
    const data = await fetchJson(url.href, { signal }); const rows = arrayField(data, 'results'); const records: PublicRecord[] = [];
    for (const item of rows) {
      const title = clean(item.title, 240); const published = artifactDate(item.publication_date); const claim = clean(item.abstract, 1300);
      if (!title || !published || !eligibleByCutoff(published, cutoff) || !safePublicUrl(item.html_url)) continue;
      const named = mentionsEntity(`${title} ${claim}`, name); const type = clean(item.type, 40);
      const agencies = Array.isArray(item.agencies) ? item.agencies.filter(isObject).map(a => clean(a.name, 120)).filter(Boolean).join(', ') : '';
      records.push({ id: `REG-${records.length + 1}`, kind: 'regulatory', title: `${title} (${type || 'Document'})`, url: item.html_url, published, retrieved: now(), authority: agencies || 'US Federal Register', claim,
        excerpt: `${claim || title}${named ? '' : ' Full-text match only: verify that the document body refers to this organization.'}${/propos|notice/i.test(type) ? ' A proposal or notice alone does not establish an exercised override.' : ''}`,
        scoreable: named && !!claim && /^(Rule|PresidentialDocument|Order)$/i.test(type), named, codes: [] });
    }
    const gaps = records.length ? [] : ['No returned US Federal Register document matched this organization by the cutoff. State and non-US regulators are not covered.'];
    if (isObject(data) && typeof data.total_pages === 'number' && data.total_pages > 1) gaps.push('Only the first page of regulatory results was inspected; additional matching documents may exist.');
    return { records: rank(records, 6, 2), gaps, consulted: [url.href], outcomes: [{ registry: 'regulatory', status: records.length ? 'searched' : 'no-match' }] };
  } catch { signal.throwIfAborted(); return { records: [], gaps: ['The Federal Register index was unavailable; regulatory coverage is incomplete.'], consulted: [], outcomes: [{ registry: 'regulatory', status: 'unavailable' }] }; }
}

export async function searchLegislativeRecords(name: string, cutoff: string, signal: AbortSignal): Promise<RegistrySearch> {
  const url = new URL('https://www.govtrack.us/api/v2/bill');
  url.search = new URLSearchParams({ q: name, limit: '12', sort: '-introduced_date', introduced_date__lte: cutoff }).toString();
  try {
    const data = await fetchJson(url.href, { signal }); const rows = arrayField(data, 'objects'); const records: PublicRecord[] = [];
    for (const item of rows) {
      const title = clean(item.title_without_number || item.title, 240); const introduced = artifactDate(item.introduced_date);
      if (!title || !introduced || !eligibleByCutoff(introduced, cutoff) || !safePublicUrl(item.link)) continue;
      const named = mentionsEntity(title, name); const statusDate = artifactDate(item.current_status_date);
      const historicalStatus = statusDate && eligibleByCutoff(statusDate, cutoff);
      const status = historicalStatus ? `${clean(item.current_status_description, 600) || clean(item.current_status_label, 100)} Status date: ${statusDate}.` : 'Current bill status is not asserted for this historical cutoff without a dated action record.';
      records.push({ id: `LEG-${records.length + 1}`, kind: 'legislative', title: `${clean(item.display_number, 30)} — ${title}`, url: item.link, published: introduced, retrieved: now(), authority: 'US Congress', claim: '',
        excerpt: `${status} Introduced ${introduced}. Introduction alone is not enactment or an exercised override.${named ? '' : ' Full-text match only: verify the entity in the bill text.'}`, scoreable: false, named, codes: [] });
    }
    const gaps = records.length ? [] : ['No returned Congressional bill matched this organization by the cutoff. State, local, and non-US legislatures are not covered.'];
    if (isObject(data) && isObject(data.meta) && typeof data.meta.total_count === 'number' && data.meta.total_count > rows.length) gaps.push('Additional legislative matches exceed this bounded result set.');
    return { records: rank(records, 5, 2), gaps, consulted: [url.href], outcomes: [{ registry: 'legislative', status: records.length ? 'searched' : 'no-match' }] };
  } catch { signal.throwIfAborted(); return { records: [], gaps: ['The legislative index was unavailable; legislative coverage is incomplete.'], consulted: [], outcomes: [{ registry: 'legislative', status: 'unavailable' }] }; }
}

export async function searchNewsRecords(name: string, cutoff: string, signal: AbortSignal): Promise<RegistrySearch> {
  const url = new URL('https://api.gdeltproject.org/api/v2/doc/doc');
  url.search = new URLSearchParams({ query: `"${name.replace(/"/g, '')}" (enforcement OR lawsuit OR regulator OR fine OR ruling OR appeal OR ban) sourcelang:english`, mode: 'artlist', maxrecords: '12', format: 'json', sort: 'datedesc', enddatetime: `${cutoff.replace(/-/g, '')}235959` }).toString();
  try {
    let data: unknown;
    try { data = await fetchJson(url.href, { signal, timeoutMs: 20000 }); }
    catch (error) {
      signal.throwIfAborted();
      if (error instanceof HttpError && error.status !== 429 && error.status < 500) throw error;
      await abortableDelay(5500, signal); data = await fetchJson(url.href, { signal, timeoutMs: 20000 });
    }
    const rows = arrayField(data, 'articles'); const records: PublicRecord[] = [];
    for (const item of rows) {
      const title = clean(item.title, 240); const seen = typeof item.seendate === 'string' ? item.seendate : '';
      const indexed = artifactDate(`${seen.slice(0, 4)}-${seen.slice(4, 6)}-${seen.slice(6, 8)}`);
      if (!title || !indexed || !eligibleByCutoff(indexed, cutoff) || !mentionsEntity(title, name) || !safePublicUrl(item.url)) continue;
      records.push({ id: `NEWS-${records.length + 1}`, kind: 'news', title, url: item.url, published: indexed, retrieved: now(), authority: clean(item.domain, 120) || 'News outlet', claim: '', excerpt: `Indexed by GDELT on ${indexed}; this is not a verified publication date. ${clean(item.domain, 120)} reporting is a lead for a primary artifact, never operative evidence.`, scoreable: false, named: true, codes: [] });
    }
    return { records: rank(records, 6, 0), gaps: records.length ? [] : ['No returned English-language news lead named this organization before the cutoff. Index coverage and historical windows are limited.'], consulted: [url.href], outcomes: [{ registry: 'news', status: records.length ? 'searched' : 'no-match' }] };
  } catch { signal.throwIfAborted(); return { records: [], gaps: ['The news index was unavailable or rate-limited; news coverage is incomplete.'], consulted: [], outcomes: [{ registry: 'news', status: 'unavailable' }] }; }
}

export type ArchiveLookup = { status: 'found' | 'no-match' | 'unavailable'; snapshot: { url: string; captured: string } | null };
export async function lookupArchivedSnapshot(url: string, cutoff: string, signal: AbortSignal): Promise<ArchiveLookup> {
  if (!safePublicUrl(url) || !isCalendarDate(cutoff)) return { status: 'no-match', snapshot: null };
  try {
    const stamp = `${cutoff.replace(/-/g, '')}235959`;
    const endpoint = new URL('https://archive.org/wayback/available');
    endpoint.search = new URLSearchParams({ url, timestamp: stamp }).toString();
    const data = await fetchJson(endpoint.href, { signal, timeoutMs: 14000 });
    if (!isObject(data) || !isObject(data.archived_snapshots)) throw new Error('Unexpected archive response.');
    const closest = data.archived_snapshots.closest;
    if (!isObject(closest) || closest.available !== true || closest.status !== '200') return { status: 'no-match', snapshot: null };
    const parsed = parseArchiveUrl(closest.url);
    if (!parsed || parsed.timestamp !== closest.timestamp || parsed.timestamp > stamp || !sameResource(parsed.original, url)) return { status: 'no-match', snapshot: null };
    return { status: 'found', snapshot: { url: (closest.url as string).replace(/^http:/, 'https:'), captured: parsed.captured } };
  } catch { signal.throwIfAborted(); return { status: 'unavailable', snapshot: null }; }
}
export async function findArchivedSnapshot(url: string, cutoff: string, signal: AbortSignal): Promise<{ url: string; captured: string } | null> { return (await lookupArchivedSnapshot(url, cutoff, signal)).snapshot; }

export async function searchPublicRegistries(name: string, cutoff: string, signal: AbortSignal, onRegistry?: (registry: RegistryName) => void): Promise<RegistrySearch> {
  const searches: [RegistryName, Promise<RegistrySearch>][] = [['courts', searchCourtRecords(name, cutoff, signal)], ['regulatory', searchRegulatoryRecords(name, cutoff, signal)], ['legislative', searchLegislativeRecords(name, cutoff, signal)], ['news', searchNewsRecords(name, cutoff, signal)]];
  const results = await Promise.allSettled(searches.map(async ([registry, promise]) => { const result = await promise; signal.throwIfAborted(); onRegistry?.(registry); return result; }));
  signal.throwIfAborted();
  const records: PublicRecord[] = []; const gaps: string[] = []; const consulted: string[] = []; const outcomes: RegistryOutcome[] = []; const seen = new Set<string>();
  for (const [i, settled] of results.entries()) {
    const registry = searches[i][0];
    if (settled.status !== 'fulfilled') { gaps.push(`${registryLabels[registry].label}: the index could not be reached.`); outcomes.push({ registry, status: 'unavailable' }); continue; }
    const result = settled.value;
    for (const record of result.records) { const key = canonicalUrl(record.url); if (!seen.has(key)) { seen.add(key); records.push(record); } }
    gaps.push(...result.gaps.map(gap => `${registryLabels[registry].label}: ${gap}`)); consulted.push(...result.consulted); outcomes.push(...(result.outcomes || []));
  }
  return { records, gaps, consulted, outcomes };
}
