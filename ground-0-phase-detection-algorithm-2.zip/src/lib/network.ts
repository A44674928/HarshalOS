export class HttpError extends Error {
  status: number;
  constructor(status: number, message = `The public service returned HTTP ${status}.`) { super(message); this.name = 'HttpError'; this.status = status; }
}
export type JsonRequestOptions = Omit<RequestInit, 'signal'> & { signal: AbortSignal; timeoutMs?: number };

/** Keep cancellation and the timeout active until the body has finished, not just until headers arrive. */
export async function fetchJson<T = unknown>(url: string, options: JsonRequestOptions): Promise<T> {
  const { signal, timeoutMs = 18000, ...init } = options;
  signal.throwIfAborted();
  const controller = new AbortController();
  const cancel = () => controller.abort(signal.reason);
  signal.addEventListener('abort', cancel, { once: true });
  const deadline = new Error('The public service took too long to return a complete response. Retry or continue manually.');
  deadline.name = 'TimeoutError';
  const timer = setTimeout(() => controller.abort(deadline), timeoutMs);
  let removeAbortListener = () => {};
  const interrupted = new Promise<never>((_, reject) => {
    const rejectAbort = () => reject(controller.signal.reason || new DOMException('Request canceled.', 'AbortError'));
    controller.signal.addEventListener('abort', rejectAbort, { once: true });
    removeAbortListener = () => controller.signal.removeEventListener('abort', rejectAbort);
  });
  const read = async (): Promise<T> => {
    const headers = new Headers(init.headers); if (!headers.has('Accept')) headers.set('Accept', 'application/json');
    const response = await fetch(url, { ...init, headers, signal: controller.signal, credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (!response.ok) {
      let message = `The public service returned HTTP ${response.status}.`;
      if (response.headers.get('content-type')?.includes('application/json')) {
        try { const body = await response.json(); if (typeof body?.error === 'string') message = body.error; } catch { controller.signal.throwIfAborted(); }
      }
      throw new HttpError(response.status, message);
    }
    try { const data = await response.json(); controller.signal.throwIfAborted(); return data as T; }
    catch (error) { controller.signal.throwIfAborted(); if (error instanceof SyntaxError) throw new Error('The public service did not return valid JSON. No result was inferred from this response.'); throw error; }
  };
  try { return await Promise.race([read(), interrupted]); }
  finally { clearTimeout(timer); signal.removeEventListener('abort', cancel); removeAbortListener(); }
}

export function abortableDelay(milliseconds: number, signal: AbortSignal): Promise<void> {
  signal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const stop = () => { clearTimeout(timer); signal.removeEventListener('abort', stop); reject(signal.reason || new DOMException('Request canceled.', 'AbortError')); };
    const timer = setTimeout(() => { signal.removeEventListener('abort', stop); resolve(); }, milliseconds);
    signal.addEventListener('abort', stop, { once: true });
  });
}
