import { chromium } from 'playwright';
import assert from 'node:assert/strict';

const base = process.env.TEST_URL || 'http://localhost:5173';
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const pageErrors = [];
page.on('pageerror', error => pageErrors.push(error.message));
await page.goto(base, { waitUntil: 'networkidle' });

const engine = await page.evaluate(async () => {
  const e = await import('/src/lib/engine.ts');
  const record = async vector => {
    const input = e.newInput('1.0'); input.name = 'Evidence fixture'; input.cutoff = '2026-09-12';
    input.answers = vector.map(value => ({ value, source: 'https://example.org/policy', date: '2026-01-01', notes: 'A synthetic dated artifact for regression testing only.', gap: '' }));
    return e.createAudit(input, []);
  };
  const nab = await record([false, true, false, true, false]);
  const cwo = await record([false, true, false, false, false]);
  const sovereign = await record([true, false, true, false, true]);
  const unanswered = await record([null, null, null, null, null]);
  const badB4 = e.newInput('1.1'); badB4.name = 'Unsubstantiated appeal fixture'; badB4.cutoff = '2026-09-12';
  badB4.answers[3] = { value: true, source: 'https://example.org/appeal', date: '2026-01-01', notes: 'A route exists but an operative stay is not demonstrated.', gap: '' };
  const b4 = await e.createAudit(badB4, []);
  const news = e.newInput('1.1'); news.name = 'News-only fixture'; news.cutoff = '2026-09-12';
  news.answers[0] = { value: true, source: 'https://news.example/article', date: '2026-01-01', notes: 'A synthetic news lead only.', gap: '' };
  news.automation = { method: 'web-research', provider: 'Fixture', reviewRequired: true, requestedName: news.name, generatedAt: '2026-09-12T00:00:00Z', sources: [{ id: 'NEWS', title: 'News fixture', url: news.answers[0].source, published: '2026-01-01', retrieved: '2026-09-12T00:00:00Z', excerpt: news.answers[0].notes, codes: [], kind: 'news', dateBasis: 'indexed' }] };
  const newsRecord = await e.createAudit(news, []);
  return { nab: { phase: nab.phase, working: nab.workingBadge.phase, filled: nab.workingBadge.filled, formal: nab.badge }, cwo: cwo.workingBadge, sovereign: sovereign.workingBadge, unanswered: unanswered.workingBadge, b4: b4.workingBadge, news: { badge: newsRecord.workingBadge, scored: newsRecord.report.Activator_Vector[0].Scored_Answer }, badDate: e.beforeCutoff('2026-02-30', '2026-09-12'), cutoffDay: e.beforeCutoff('2026-09-12T23:59:59.999Z', '2026-09-12'), formattedInvalid: e.formatDate('garbage') };
});
assert.equal(engine.nab.working, 'NAB', 'NAB must not display CWO');
assert.equal(engine.nab.filled, 5);
assert.equal(engine.nab.formal, 'Unissued');
assert.equal(engine.cwo.phase, 'CWO'); assert.equal(engine.cwo.assumed, false);
assert.equal(engine.sovereign.phase, 'GSRB'); assert.equal(engine.sovereign.disproved, true);
assert.equal(engine.unanswered.filled, 0, 'citation fields alone must not fill unanswered questions');
assert.equal(engine.b4.filled, 0, 'an unsupported B4 YES cannot fill a badge segment');
assert.equal(engine.news.badge.filled, 0); assert.equal(engine.news.scored, 'NO');
assert.equal(engine.badDate, false); assert.equal(engine.cutoffDay, true); assert.equal(engine.formattedInvalid, 'Invalid date');
console.log('PASS: badge precedence, unanswered arcs, unsupported appeal/news evidence, and calendar dates.');

const constraints = await page.evaluate(async () => {
  const { preparePublicInput } = await import('/src/lib/automatic.ts');
  const { mentionsEntity } = await import('/src/lib/sources.ts');
  const org = { name: 'Example Council', identifier: 'FIXTURE', description: 'Synthetic identity.', website: 'https://example.org/', articleUrl: 'https://example.org/identity', pageId: 1 };
  const neutral = { id: 'COURT-1', kind: 'court', title: 'Example Council v. State (opinion)', url: 'https://www.courtlistener.com/opinion/1/fixture/', published: '2026-01-01', retrieved: '2026-09-12T00:00:00Z', authority: 'District Court', scoreable: true, named: true, codes: [], claim: 'A routine scheduling order was entered.', excerpt: 'A routine scheduling order. Read the full record to establish whether an order overrode, stayed, or reversed a decision of this entity.' };
  const score = claim => preparePublicInput(org, [], [{ ...neutral, claim }], '1.1', '2026-09-12').input.constraints.map(a => a.value);
  return { neutral: score(neutral.claim), denied: score('The court denied the motion to vacate the decision of Example Council.'), requested: score('The court was asked to vacate the policy of Example Council.'), unrelated: score('The court reversed the State decision while Example Council appeared as an observer.'), operative: score('The court vacated the decision of Example Council and enjoined further enforcement.'), partialName: mentionsEntity('The Metadata Company', 'Meta') };
});
assert.deepEqual(constraints.neutral, [false, false, false, false]);
assert.equal(constraints.denied[0], false); assert.equal(constraints.requested[0], false); assert.equal(constraints.unrelated[0], false);
assert.equal(constraints.operative[0], true); assert.equal(constraints.operative[3], true);
assert.equal(constraints.partialName, false, 'partial word matches are not party matches');
console.log('PASS: generated court guidance, denied/requested relief, and unrelated party actions cannot activate C1/C4.');

const network = await page.evaluate(async () => {
  const { fetchJson, abortableDelay } = await import('/src/lib/network.ts');
  const original = window.fetch;
  let timeoutName = ''; let elapsed = 0;
  try {
    window.fetch = async () => ({ ok: true, headers: new Headers({ 'Content-Type': 'application/json' }), json: () => new Promise(() => {}) });
    const start = performance.now();
    try { await fetchJson('https://example.org/slow-body', { signal: new AbortController().signal, timeoutMs: 40 }); } catch (error) { timeoutName = error.name; }
    elapsed = performance.now() - start;
  } finally { window.fetch = original; }
  const cancel = new AbortController(); const start = performance.now();
  const delay = abortableDelay(5500, cancel.signal).catch(error => error.name);
  cancel.abort(); const name = await delay;
  return { timeoutName, elapsed, cancelName: name, cancelMs: performance.now() - start };
});
assert.equal(network.timeoutName, 'TimeoutError'); assert.ok(network.elapsed < 1000);
assert.equal(network.cancelName, 'AbortError'); assert.ok(network.cancelMs < 100);
console.log('PASS: timeout remains active through response-body decoding and cancellation interrupts retry backoff.');

const archive = await page.evaluate(async () => {
  const { readWithArchive, policyLinks, preparePublicInput } = await import('/src/lib/automatic.ts');
  const { parseArchiveUrl } = await import('/src/lib/validation.ts');
  const oldFetch = window.fetch; const urls = [];
  const liveUrl = 'https://example.org/'; const capturedUrl = 'https://web.archive.org/web/20260110000000/https://example.org/';
  try {
    window.fetch = async url => {
      urls.push(String(url));
      if (String(url).startsWith('https://archive.org/')) return Response.json({ archived_snapshots: { closest: { available: true, status: '200', timestamp: '20260110000000', url: capturedUrl } } });
      if (String(url).includes('web.archive.org/web/')) return Response.json({ data: { title: 'Archive fixture', url: liveUrl, content: 'This old homepage has no policy links. The archive fixture preserves a version before the cutoff without asserting an effective or publication date. A long synthetic paragraph makes it readable.', httpStatus: 200 } });
      return Response.json({ data: { title: 'Live fixture', url: liveUrl, content: 'Effective: May 1, 2026. Current website navigation lists [Terms of Use](https://example.org/terms). These links should still be discoverable even when the historical homepage has no links. This is a synthetic fixture.', httpStatus: 200 } });
    };
    const document = await readWithArchive(liveUrl, liveUrl, '2026-01-15', new AbortController().signal);
    const org = { name: 'Example Council', identifier: 'FIXTURE', description: 'Fixture.', website: liveUrl, articleUrl: 'https://example.org/identity', pageId: 1 };
    const prepared = preparePublicInput(org, [document], [], '1.0', '2026-01-15');
    return { url: document.url, original: document.liveUrl, published: document.published, captured: document.archived, links: policyLinks(document.liveContent || document.content, liveUrl), source: prepared.sources[0], urls, fakeArchive: parseArchiveUrl('https://evil.example/path?site=web.archive.org'), rewritten: policyLinks('[Terms](https://web.archive.org/web/20260110000000/https://example.org/terms)', liveUrl) };
  } finally { window.fetch = oldFetch; }
});
assert.equal(archive.url, 'https://web.archive.org/web/20260110000000/https://example.org/', 'the original full capture URL must be preserved');
assert.equal(archive.published, null, 'capture time must not be invented as a publication date');
assert.equal(archive.captured, '2026-01-10'); assert.equal(archive.source.dateBasis, 'archive-capture');
assert.deepEqual(archive.links, ['https://example.org/terms']); assert.deepEqual(archive.rewritten, ['https://example.org/terms']);
assert.equal(archive.fakeArchive, null);
console.log('PASS: capture URL/date provenance and live policy-link discovery survive archive fallback.');

const progress = await page.evaluate(async () => {
  const { automaticAudit } = await import('/src/lib/automatic.ts'); const { createAudit, today } = await import('/src/lib/engine.ts');
  const original = window.fetch; const requests = []; const marks = [];
  const day = today();
  try {
    window.fetch = async url => {
      const target = String(url); requests.push(target);
      if (target.includes('en.wikipedia.org')) return Response.json({ query: { pages: [{ pageid: 1, title: 'Example Council', index: 1, extract: 'A synthetic organization fixture, not a real audit.', fullurl: 'https://en.wikipedia.org/wiki/Example_Council', pageprops: { wikibase_item: 'Q1' } }] } });
      if (target.includes('wikidata.org')) return Response.json({ entities: { Q1: { labels: { en: { value: 'Example Council' } }, claims: { P856: [{ mainsnak: { datavalue: { value: 'https://example.org/' } } }] } } } });
      if (target.includes('courtlistener.com')) return Response.json({ results: [] });
      if (target.includes('federalregister.gov')) return Response.json({ results: [] });
      if (target.includes('govtrack.us')) return Response.json({ objects: [] });
      if (target.includes('gdeltproject.org')) return Response.json({ articles: [{ title: 'Example Council coverage', seendate: day.replace(/-/g, '') + 'T230000Z', url: 'https://news.example/fixture', domain: 'news.example' }] });
      if (target.includes('r.jina.ai')) { await new Promise(resolve => setTimeout(resolve, 80)); return Response.json({ data: { title: 'Fixture terms', url: 'https://example.org/', content: `Effective: January 1, 2026. We may terminate access to services for breach of these terms. These are synthetic terms used to test concurrent progress, not real organizational evidence.`, httpStatus: 200 } }); }
      return Response.json({ archived_snapshots: {} });
    };
    const result = await automaticAudit({ name: 'Example Council', version: '1.0', cutoff: day, existing: [], availability: { enabled: false, provider: 'fixture' }, signal: new AbortController().signal, onProgress: p => marks.push(p.completed) });
    const review = await createAudit({ ...result.input, automation: { ...result.input.automation, reviewRequired: false } }, []);
    return { marks, requests, coverageCount: result.coverage.length, savedCoverageCount: review.report.Registry_Coverage.length, warningsCount: review.report.Research_Limits.length, inputCoverageCount: review.input.automation.coverage.length, newsEvidenceCode: review.evidence.find(e => e.url === 'https://news.example/fixture').codes, sources: result.sources.length };
  } finally { window.fetch = original; }
});
assert.ok(progress.marks.every((value, i) => i === 0 || value >= progress.marks[i - 1]), 'parallel searches cannot move progress backward');
assert.equal(progress.coverageCount, 6); assert.equal(progress.savedCoverageCount, 6); assert.equal(progress.inputCoverageCount, 6); assert.ok(progress.warningsCount > 0);
assert.ok(progress.newsEvidenceCode.includes('NEWS LEAD — NEVER SCORED'));
assert.ok(progress.requests.some(url => url.includes('govtrack') && url.includes('introduced_date__lte')));
assert.ok(progress.requests.some(url => url.includes('gdelt') && url.includes('235959')));
console.log('PASS: monotonic progress, inclusive cutoff query, and registry provenance survive manual regeneration.');

// Real UI regression: a pre-working-badge record must open rather than crash.
const legacy = await page.evaluate(async () => {
  const e = await import('/src/lib/engine.ts'); const input = e.newInput(); input.name = 'Legacy saved audit';
  const record = await e.createAudit(input, []); delete record.workingBadge;
  record.answers = [record.answers[0]]; record.input.constraints = null; record.createdAt = 'not-a-date';
  // The oldest records did not retain a form snapshot at all.
  delete record.input; return record;
});
const legacyContext = await browser.newContext();
await legacyContext.addInitScript(record => { localStorage.setItem('ground-0-audits-v1', JSON.stringify([record])); localStorage.setItem('ground-0-evidence-v1', '{"unexpected":"object"}'); }, legacy);
const old = await legacyContext.newPage(); old.on('pageerror', error => pageErrors.push(error.message));
await old.goto(base, { waitUntil: 'networkidle' });
await old.locator('.nav-link').filter({ hasText: 'Phase audits' }).click();
await old.getByRole('button', { name: 'View audit for Legacy saved audit', exact: true }).click();
await old.locator('.detail-working-badge').waitFor();
assert.ok((await old.locator('.detail-working-badge').innerText()).includes('CWO'));
assert.ok(await old.getByRole('button', { name: 'Continue audit', exact: true }).isVisible(), 'the oldest audit can be resumed without a preexisting form snapshot');
assert.equal(await old.evaluate(() => JSON.parse(localStorage.getItem('ground-0-audits-v1'))[0].input.constraints.length), 4);
assert.ok(await old.evaluate(() => !!localStorage.getItem('ground-0-audits-v1-recovery')), 'the original legacy record is preserved');
await old.keyboard.press('Control+k'); assert.equal(await old.getByRole('dialog').count(), 1, 'workspace search cannot stack behind an existing dialog');
await old.getByRole('button', { name: 'Close audit details', exact: true }).click();
await old.locator('.nav-link').filter({ hasText: 'Evidence library' }).click();
assert.ok(await old.getByRole('heading', { name: 'Evidence, not inference.', exact: true }).isVisible());
assert.deepEqual(pageErrors, []);
console.log('PASS: older/incomplete stored audits and malformed evidence storage recover without a crash.');
await browser.close();
