import assert from 'node:assert/strict';
import { makeServer, researchOrganization } from '../server/research.mjs';

const originalKey = process.env.OPENAI_API_KEY;
const server = makeServer();
try {
  delete process.env.OPENAI_API_KEY;
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const status = await (await fetch(`${base}/api/research/status`)).json();
  assert.equal(status.enabled, false); assert.equal(status.keyInBrowser, false);
  const send = data => fetch(`${base}/api/research`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
  for (const malformed of [null, [], {}, { name: 'Fixture council', version: '1.0', cutoff: '2026-02-30' }]) {
    const response = await send(malformed); assert.equal(response.status, 400, 'malformed input and impossible calendar dates return 400, not a server exception');
  }
  const missingKey = await send({ name: 'Fixture council', version: '1.1', cutoff: '2026-09-12' });
  assert.equal(missingKey.status, 503);
  const wrongOrigin = await fetch(`${base}/api/research`, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://other.example' }, body: '{}' });
  assert.equal(wrongOrigin.status, 403);

  process.env.OPENAI_API_KEY = 'fixture-server-only-key';
  const newsUrl = 'https://news.example/report'; const officialUrl = 'https://example.org/terms'; const invalidDateUrl = 'https://example.org/impossible-date';
  const quote = 'We may terminate access to services for a breach of these terms.';
  const validAnswer = { value: true, source: officialUrl, date: '2026-01-01', notes: quote, gap: '' };
  const draft = { organization: { name: 'Fixture council', identifier: 'FIXTURE', description: 'Synthetic server fixture only.', website: 'https://example.org/' },
    answers: [{ ...validAnswer, source: newsUrl }, validAnswer, { ...validAnswer, source: invalidDateUrl, date: '2026-02-30' }, { ...validAnswer, value: false }, validAnswer],
    constraints: Array.from({ length: 4 }, () => ({ value: false, source: '', date: '', notes: '', gap: 'The synthetic outcome record is not demonstrated.' })), b4: {}, c2: {}, external: {},
    sources: [{ title: 'News fixture', url: newsUrl, published: '2026-01-01', excerpt: quote, codes: [], kind: 'news' }, { title: 'Official fixture', url: officialUrl, published: '2026-01-01', excerpt: quote, codes: [], kind: 'official' }, { title: 'Invalid date fixture', url: invalidDateUrl, published: '2026-02-30', excerpt: quote, codes: [], kind: 'court' }], warnings: [] };
  let calls = 0;
  const fakeFetch = async (url, options) => {
    if (url === 'https://api.openai.com/v1/responses') {
      calls++; const body = JSON.parse(options.body); assert.equal(body.store, false); assert.equal(options.headers.Authorization, 'Bearer fixture-server-only-key');
      if (calls === 1) return Response.json({ status: 'completed', output: [{ type: 'web_search_call', action: { sources: [newsUrl, officialUrl, invalidDateUrl].map(url => ({ url })) } }, { type: 'message', content: [{ type: 'output_text', text: 'Synthetic source research only; not a real audit.', annotations: [] }] }] });
      const kinds = body.text.format.schema.properties.sources.items.properties.kind.enum;
      assert.ok(kinds.includes('news') && kinds.includes('court'), 'structured research retains real source categories');
      return Response.json({ status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify(draft) }] }] });
    }
    return Response.json({ data: { title: 'Synthetic source', url: url.replace('https://r.jina.ai/', ''), content: `Effective: ${url.includes('impossible-date') ? 'February 30, 2026' : 'January 1, 2026'}\n${quote}`, httpStatus: 200 } });
  };
  const research = await researchOrganization({ name: 'Fixture council', version: '1.1', cutoff: '2026-09-12' }, new AbortController().signal, fakeFetch);
  assert.equal(research.answers[0].value, false, 'a verified quotation in a news article is still not primary scoring evidence');
  assert.equal(research.answers[0].source, ''); assert.equal(research.answers[1].value, true);
  assert.equal(research.answers[2].value, false, 'impossible publication dates are not rolled into March');
  assert.equal(research.sources.find(s => s.url === invalidDateUrl).published, null);
  assert.equal(research.sources.find(s => s.url === newsUrl).kind, 'news');
  assert.ok(!JSON.stringify(research).includes('fixture-server-only-key'));
  console.log('PASS: server request validation, missing credentials, origin guard, source taxonomy, news exclusion, and strict dates.');
} finally {
  if (originalKey === undefined) delete process.env.OPENAI_API_KEY; else process.env.OPENAI_API_KEY = originalKey;
  server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
}
